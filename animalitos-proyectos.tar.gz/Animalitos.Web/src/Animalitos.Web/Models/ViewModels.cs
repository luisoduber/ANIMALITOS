using System.ComponentModel.DataAnnotations;

namespace Animalitos.Web.Models;

public sealed record ErrorViewModel(string Mensaje, string? RequestId);

public sealed class LoginViewModel
{
    [Required(ErrorMessage = "Ingrese el nombre del usuario.")]
    [Display(Name = "Usuario")]
    public string Usuario { get; set; } = string.Empty;

    [Required(ErrorMessage = "Ingrese la clave del usuario.")]
    [MinLength(8, ErrorMessage = "La clave debe contener minimo 8 caracteres.")]
    [DataType(DataType.Password)]
    [Display(Name = "Clave")]
    public string Clave { get; set; } = string.Empty;

    /// <summary>Recordar solo el nombre de usuario (la clave nunca se guarda en el equipo).</summary>
    public bool RecordarUsuario { get; set; }

    public string? ReturnUrl { get; set; }

    public string? Mensaje { get; set; }
}

public sealed class CambiarClaveViewModel
{
    [Required(ErrorMessage = "Ingrese su clave actual.")]
    [DataType(DataType.Password)]
    public string ClaveActual { get; set; } = string.Empty;

    [Required(ErrorMessage = "Ingrese la clave nueva.")]
    [MinLength(8, ErrorMessage = "La clave nueva debe tener minimo 8 caracteres.")]
    [DataType(DataType.Password)]
    public string ClaveNueva { get; set; } = string.Empty;

    [Required(ErrorMessage = "Repita la clave nueva.")]
    [Compare(nameof(ClaveNueva), ErrorMessage = "La clave nueva y su confirmacion no coinciden.")]
    [DataType(DataType.Password)]
    public string ConfirmarClave { get; set; } = string.Empty;
}

/// <summary>Modulo del menu principal.</summary>
public sealed record ModuloMenu(string Nombre, string Descripcion, string Icono, string ColorIcono, string? Url, bool Disponible = true);
