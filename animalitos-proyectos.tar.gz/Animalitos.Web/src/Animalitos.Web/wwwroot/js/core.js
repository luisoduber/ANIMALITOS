/* ============================================================
   Animalitos Web - utilidades comunes (fetch, modales, toasts,
   formato de montos, tablas genericas y reloj del servidor).
   ============================================================ */
'use strict';

window.App = (() => {
  const csrf = document.querySelector('meta[name="csrf-token"]')?.content ?? '';
  const fmtMonto = new Intl.NumberFormat('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  class ApiError extends Error {
    constructor(mensaje, status, codigo) {
      super(mensaje);
      this.status = status;
      this.codigo = codigo;
    }
  }

  // ---------------------------------------------------------------- Formato
  const monto = (v) => fmtMonto.format(Number(v) || 0);

  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /** Interpreta "10", "10,5", "10.50", "1.000,50", "1.000" (miles) -> numero. */
  function parseMonto(texto) {
    let t = String(texto ?? '').trim().replace(/\s/g, '');
    if (!t) return NaN;
    const punto = t.lastIndexOf('.');
    const coma = t.lastIndexOf(',');
    if (punto >= 0 && coma >= 0) {
      t = coma > punto ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
    } else if (coma >= 0) {
      t = t.replace(/\./g, '').replace(',', '.');
    } else if (punto >= 0 && (t.match(/\./g) || []).length === 1 && t.length - punto - 1 === 3) {
      t = t.replace('.', ''); // "1.000" = mil
    } else if ((t.match(/\./g) || []).length > 1) {
      t = t.replace(/\./g, '');
    }
    const n = Number(t);
    return Number.isFinite(n) ? Math.round(n * 100) / 100 : NaN;
  }

  /** Codigo de jugada: "7" -> "07"; "0" y "00" se respetan (Delfin y Ballena). */
  function normalizarCodigo(c) {
    const t = String(c ?? '').trim();
    return t.length === 1 && t !== '0' ? t.padStart(2, '0') : t;
  }

  /** "14:05:00" -> "02:05 PM" */
  function hora12(hhmmss) {
    const [h, m] = String(hhmmss ?? '').split(':').map(Number);
    if (!Number.isFinite(h)) return hhmmss ?? '';
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${String(h12).padStart(2, '0')}:${String(m || 0).padStart(2, '0')} ${ampm}`;
  }

  const hoyISO = () => {
    const d = Reloj.ahora();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  // ---------------------------------------------------------------- Ocupado
  let ocupados = 0;
  function ocupado(activo, texto) {
    const overlay = document.getElementById('busy-overlay');
    const barra = document.getElementById('progress-bar');
    ocupados = Math.max(0, ocupados + (activo ? 1 : -1));
    if (overlay) {
      overlay.classList.toggle('show', ocupados > 0);
      const t = overlay.querySelector('.busy-text');
      if (t && texto) t.textContent = texto;
      if (t && ocupados === 0) t.textContent = 'Procesando...';
    }
    if (barra) barra.style.width = ocupados > 0 ? '70%' : '0';
  }

  // ---------------------------------------------------------------- Fetch
  async function request(method, url, body, { ocupar = true, texto } = {}) {
    const opts = {
      method,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest', Accept: 'application/json' }
    };
    if (method !== 'GET') opts.headers.RequestVerificationToken = csrf;
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }

    if (ocupar) ocupado(true, texto);
    let respuesta;
    try {
      respuesta = await fetch(url, opts);
    } catch {
      throw new ApiError('No hay comunicacion con el servidor. Verifique su conexion.', 0);
    } finally {
      if (ocupar) ocupado(false);
    }

    const tipo = respuesta.headers.get('content-type') || '';
    const datos = tipo.includes('application/json') ? await respuesta.json().catch(() => null) : null;

    if (respuesta.status === 401) {
      window.location.href = datos?.redirigir || '/cuenta/login';
      throw new ApiError(datos?.mensaje || 'Su sesion expiro.', 401);
    }
    if (!respuesta.ok) {
      throw new ApiError(datos?.mensaje || datos?.detail || 'No fue posible completar la operacion.', respuesta.status, datos?.codigo);
    }
    return datos;
  }

  const get = (url, o) => request('GET', url, undefined, o);
  const post = (url, body, o) => request('POST', url, body ?? {}, o);

  const qs = (obj) => {
    const p = new URLSearchParams();
    Object.entries(obj).forEach(([k, v]) => { if (v !== null && v !== undefined && v !== '') p.append(k, v); });
    const s = p.toString();
    return s ? `?${s}` : '';
  };

  // ---------------------------------------------------------------- Modal
  let modalResolver = null;

  function modalAbierto() {
    return document.getElementById('modal')?.classList.contains('show') ?? false;
  }

  /**
   * Muestra un modal. botones: [{ texto, valor, clase, icono, principal }]
   * Devuelve una promesa con el valor del boton pulsado (null si se cierra).
   */
  function modal({ titulo = '', icono = 'ti-info-circle', html = '', botones = [{ texto: 'Aceptar', valor: true, clase: 'btn-primary', principal: true }], grande = false } = {}) {
    const cont = document.getElementById('modal');
    if (!cont) return Promise.resolve(null);
    if (modalResolver) modalResolver(null);

    cont.querySelector('.modal-glass').classList.toggle('modal-lg', grande);
    cont.querySelector('.modal-title').innerHTML = `<i class="ti ${esc(icono)}"></i> ${esc(titulo)}`;
    cont.querySelector('.modal-body').innerHTML = html;
    const pie = cont.querySelector('.modal-footer');
    pie.innerHTML = '';
    botones.forEach((b, i) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `btn-glass ${b.clase || ''}`;
      btn.innerHTML = `${b.icono ? `<i class="ti ${esc(b.icono)}"></i>` : ''}${esc(b.texto)}`;
      btn.dataset.indice = String(i);
      btn.addEventListener('click', () => cerrarModal(b.valor));
      pie.appendChild(btn);
    });

    cont.classList.add('show');
    const principal = [...pie.querySelectorAll('button')].find((_, i) => botones[i].principal) || pie.querySelector('button:last-child');
    const primerCampo = cont.querySelector('.modal-body input, .modal-body select');
    setTimeout(() => (primerCampo || principal)?.focus(), 30);

    return new Promise((resolve) => { modalResolver = resolve; });
  }

  function cerrarModal(valor = null) {
    const cont = document.getElementById('modal');
    cont?.classList.remove('show');
    const r = modalResolver;
    modalResolver = null;
    if (r) r(valor);
  }

  const iconoTipo = { ok: 'ti-circle-check', error: 'ti-circle-x', warn: 'ti-alert-triangle', info: 'ti-info-circle' };

  function alerta(mensaje, { titulo = 'Verifique', tipo = 'warn' } = {}) {
    const lista = Array.isArray(mensaje) ? mensaje : [mensaje];
    const html = lista.length > 1
      ? `<ul class="modal-lista">${lista.map((m) => `<li>${esc(m)}</li>`).join('')}</ul>`
      : `<p>${esc(lista[0])}</p>`;
    return modal({ titulo, icono: iconoTipo[tipo] || iconoTipo.info, html });
  }

  function confirmar(mensaje, titulo = 'Confirme') {
    return modal({
      titulo,
      icono: 'ti-help-circle',
      html: `<p>${esc(mensaje)}</p>`,
      botones: [
        { texto: 'Cancelar', valor: false },
        { texto: 'Aceptar', valor: true, clase: 'btn-primary', principal: true }
      ]
    }).then((v) => v === true);
  }

  function toast(mensaje, tipo = 'info', ms = 4500) {
    const pila = document.getElementById('toasts');
    if (!pila) return;
    const t = document.createElement('div');
    t.className = `toast toast-${tipo}`;
    t.innerHTML = `<i class="ti ${iconoTipo[tipo] || iconoTipo.info}"></i><span>${esc(mensaje)}</span>`;
    pila.appendChild(t);
    setTimeout(() => t.remove(), ms);
  }

  /** Muestra el error de una operacion (ApiError u otro). */
  function error(e, titulo = 'Verifique') {
    console.error(e);
    return alerta(e?.message || 'Ocurrio un error inesperado.', { titulo, tipo: 'error' });
  }

  // ---------------------------------------------------------------- Tablas genericas
  const titulo = (col) => String(col).replace(/^prm/, '').replace(/_/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').trim().toUpperCase();

  function valorCelda(v) {
    if (v === null || v === undefined) return '';
    if (typeof v === 'number') return Number.isInteger(v) ? String(v) : monto(v);
    const s = String(v);
    const fecha = s.match(/^(\d{4})-(\d{2})-(\d{2})T00:00:00$/);
    if (fecha) return `${fecha[3]}/${fecha[2]}/${fecha[1]}`;
    const fechaHora = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (fechaHora) return `${fechaHora[3]}/${fechaHora[2]}/${fechaHora[1]} ${fechaHora[4]}:${fechaHora[5]}`;
    return s;
  }

  /**
   * Dibuja un TablaDto { columnas, filas } en el contenedor.
   * opciones: ocultarIds (oculta columnas id*), alClic(fila, columnas), vacio
   */
  function tabla(contenedor, datos, { ocultarIds = true, alClic = null, vacio = 'Sin registros.' } = {}) {
    const cols = datos?.columnas ?? [];
    const filas = datos?.filas ?? [];
    const visibles = cols.map((c, i) => ({ c, i })).filter(({ c }) => !(ocultarIds && /^id/i.test(c)));

    const thead = `<thead><tr>${visibles.map(({ c }) => `<th>${esc(titulo(c))}</th>`).join('')}</tr></thead>`;
    const tbody = filas.length === 0
      ? `<tbody><tr><td class="tabla-vacia" colspan="${Math.max(visibles.length, 1)}">${esc(vacio)}</td></tr></tbody>`
      : `<tbody>${filas.map((f, n) => `<tr data-fila="${n}" class="${alClic ? 'clickable' : ''}">${visibles
          .map(({ i }) => `<td class="${typeof f[i] === 'number' ? 'num' : ''}">${esc(valorCelda(f[i]))}</td>`).join('')}</tr>`).join('')}</tbody>`;

    contenedor.innerHTML = `<div class="table-responsive"><table class="glass-table">${thead}${tbody}</table></div>`;
    if (alClic) {
      contenedor.querySelectorAll('tbody tr[data-fila]').forEach((tr) =>
        tr.addEventListener('click', () => alClic(filas[Number(tr.dataset.fila)], cols)));
    }
  }

  /** Llena un <select> con opciones [{valor, texto}] */
  function opciones(select, items, { vacio } = {}) {
    select.innerHTML = (vacio !== undefined ? `<option value="">${esc(vacio)}</option>` : '') +
      items.map((o) => `<option value="${esc(o.valor)}">${esc(o.texto)}</option>`).join('');
  }

  /** Convierte un TablaDto en opciones usando nombres de columna candidatos. */
  function opcionesDesdeTabla(datos, colValor, colTexto) {
    const cols = (datos?.columnas ?? []).map((c) => c.toLowerCase());
    const iv = Math.max(0, cols.indexOf(colValor.toLowerCase()));
    const it = cols.indexOf(colTexto.toLowerCase()) >= 0 ? cols.indexOf(colTexto.toLowerCase()) : Math.min(1, cols.length - 1);
    return (datos?.filas ?? []).map((f) => ({ valor: f[iv], texto: f[it] }));
  }

  // ---------------------------------------------------------------- Vista de ticket (texto)
  function ticketTexto(t, { ancho = 42 } = {}) {
    const linea = '='.repeat(ancho);
    const L = [];
    L.push(`Taquilla: ${t.taquilla ?? ''}`);
    if (t.estado) L.push(`Status: ${String(t.estado).toLowerCase()}`);
    L.push(`Ticket: ${t.numeroTicket}${t.serial ? `  Serial: ${t.serial}` : ''}`);
    L.push(`Fecha: ${t.fecha}  Hora: ${t.hora}`);
    L.push(linea);
    (t.grupos ?? []).forEach((g) => {
      L.push(`${g.loteria}  ${g.sorteo}`.trim());
      for (let i = 0; i < g.jugadas.length; i += 2) {
        const celda = (j) => `${String(j.codigo).padEnd(3)}${String(j.producto).padEnd(4)}${monto(j.monto).padStart(9)}   `;
        L.push((celda(g.jugadas[i]) + (g.jugadas[i + 1] ? celda(g.jugadas[i + 1]) : '')).trimEnd());
      }
      L.push('');
    });
    (t.tripletas ?? []).forEach((tr) => {
      L.push(`TRIPLETA: ${tr.loteria}`);
      if (tr.desde) L.push(`Desde: ${tr.desde}`);
      if (tr.hasta) L.push(`Hasta: ${tr.hasta}`);
      L.push((tr.productos ?? []).join(' '));
      L.push(`Monto jugando: ${monto(tr.monto)} ${t.divisa ?? ''}`);
      L.push('');
    });
    L.push(linea);
    L.push(`Monto total ticket: ${monto(t.montoTicket ?? t.total)}`);
    if (t.montoPagado) L.push(`Monto pagado: ${monto(t.montoPagado)}`);
    if ((t.tripletas ?? []).length > 0) L.push(`Valido por ${t.sorteosTripleta} sorteos descritos.`);
    else L.push(`Ticket caduca: ${t.diasCaducidad} dias.`);
    if (t.nota) L.push(`Nota: ${t.nota}`);
    return L.join('\n');
  }

  // ---------------------------------------------------------------- Reloj del servidor
  const Reloj = (() => {
    let desfase = 0; // ms: hora del servidor - hora del equipo
    let sincronizado = false;

    /** "2026-09-11T14:05:03" (hora local del servidor, sin zona) -> Date local con esos componentes. */
    function parse(iso) {
      const m = String(iso ?? '').match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})/);
      if (!m) return null;
      return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]);
    }

    /** Sincroniza con la hora del servidor compensando la mitad del tiempo de ida y vuelta. */
    function sincronizar(horaServidorIso, inicioMs, finMs) {
      const servidor = parse(horaServidorIso);
      if (!servidor) return;
      const medio = inicioMs + (finMs - inicioMs) / 2;
      desfase = servidor.getTime() - medio;
      sincronizado = true;
    }

    const ahora = () => new Date(Date.now() + desfase);

    function texto(d = ahora()) {
      let h = d.getHours();
      const ampm = h >= 12 ? 'PM' : 'AM';
      h = h % 12 === 0 ? 12 : h % 12;
      return `${String(h).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')} ${ampm}`;
    }

    /** Fecha/hora de cierre de un sorteo de hoy ("HH:mm:ss"). */
    function cierre(hhmmss) {
      const [h, m, s] = String(hhmmss).split(':').map(Number);
      const d = ahora();
      return new Date(d.getFullYear(), d.getMonth(), d.getDate(), h || 0, m || 0, s || 0);
    }

    return { parse, sincronizar, ahora, texto, cierre, get sincronizado() { return sincronizado; } };
  })();

  // ---------------------------------------------------------------- Inicializacion comun
  document.addEventListener('DOMContentLoaded', () => {
    const cont = document.getElementById('modal');
    cont?.querySelector('.modal-close')?.addEventListener('click', () => cerrarModal(null));
    cont?.addEventListener('mousedown', (e) => { if (e.target === cont) cerrarModal(null); });

    document.addEventListener('keydown', (e) => {
      if (!modalAbierto()) return;
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation(); // Evita que la pantalla de venta interprete el Esc como "imprimir".
        cerrarModal(null);
      } else if (e.key === 'Enter' && !(e.target instanceof HTMLTextAreaElement) &&
                 !(e.target instanceof HTMLButtonElement)) {
        const principal = cont.querySelector('.modal-footer .btn-primary') || cont.querySelector('.modal-footer button:last-child');
        if (principal && !(e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement)) {
          e.preventDefault();
          e.stopPropagation();
          principal.click();
        }
      }
    }, true);
  });

  return {
    ApiError, monto, esc, parseMonto, normalizarCodigo, hora12, hoyISO,
    ocupado, get, post, qs, modal, cerrarModal, modalAbierto, alerta, confirmar, toast, error,
    tabla, opciones, opcionesDesdeTabla, ticketTexto, Reloj
  };
})();
