/* ============================================================
   Impresion de tickets
   1) QZ Tray (recomendado): envia ESC/POS en crudo a la impresora
      termica configurada, sin dialogos (con certificado firmado).
   2) Respaldo: impresion del navegador con formato de 58/80 mm.
      Con Chrome/Edge en modo --kiosk-printing tambien es silenciosa.
   ============================================================ */
'use strict';

window.Impresion = (() => {
  const CLAVE_MODO = 'animalitos.modoImpresion';
  let seguridadConfigurada = false;

  const modo = () => {
    try { return localStorage.getItem(CLAVE_MODO) || 'qz'; } catch { return 'qz'; }
  };

  const guardarModo = (m) => {
    try { localStorage.setItem(CLAVE_MODO, m); } catch { /* sin almacenamiento local */ }
  };

  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content ?? '';

  function qzDisponible() {
    return typeof window.qz !== 'undefined' && window.qz?.websocket;
  }

  function configurarSeguridad() {
    if (seguridadConfigurada || !qzDisponible()) return;
    const qz = window.qz;

    qz.security.setCertificatePromise((resolve) => {
      fetch('/impresora/qz/certificado', { credentials: 'same-origin', cache: 'no-store' })
        .then((r) => (r.ok ? r.text() : ''))
        .then(resolve)
        .catch(() => resolve(''));
    });

    qz.security.setSignatureAlgorithm('SHA512');
    qz.security.setSignaturePromise((aFirmar) => (resolve, reject) => {
      fetch('/impresora/qz/firmar', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'text/plain', RequestVerificationToken: csrf(), 'X-Requested-With': 'XMLHttpRequest' },
        body: aFirmar
      })
        .then((r) => (r.status === 204 ? '' : r.ok ? r.text() : Promise.reject(new Error('Firma rechazada'))))
        .then(resolve)
        .catch(reject);
    });

    seguridadConfigurada = true;
  }

  async function conectarQz() {
    if (!qzDisponible()) throw new Error('QZ Tray no esta cargado en la pagina.');
    configurarSeguridad();
    if (!window.qz.websocket.isActive()) {
      await window.qz.websocket.connect({ retries: 1, delay: 1 });
    }
    return window.qz;
  }

  async function imprimirQz(documento) {
    const qz = await conectarQz();
    const impresora = documento.impresora || (await qz.printers.getDefault());
    if (!impresora) throw new Error('No hay impresora configurada ni predeterminada.');
    const config = qz.configs.create(impresora);
    await qz.print(config, [{ type: 'raw', format: 'command', flavor: 'base64', data: documento.escPosBase64 }]);
  }

  /** Impresion con el dialogo del navegador (o silenciosa con --kiosk-printing). */
  function imprimirNavegador(documento) {
    return new Promise((resolve) => {
      const anchoMm = documento.angosto ? 58 : 80;
      const fuentePx = documento.angosto ? 11 : 12;
      const lineas = (documento.lineas ?? []).map((l) => {
        const clases = [l.n ? 'b' : '', l.g ? 'g' : ''].join(' ').trim();
        return `<div class="${clases}">${window.App.esc(l.t) || '&nbsp;'}</div>`;
      }).join('');

      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Ticket</title><style>
        @page { size: ${anchoMm}mm auto; margin: 0; }
        html, body { margin: 0; padding: 0; background: #fff; color: #000; }
        body { width: ${anchoMm - 6}mm; padding: 2mm 3mm; font-family: 'Courier New', Consolas, monospace; font-size: ${fuentePx}px; line-height: 1.25; }
        div { white-space: pre; overflow: hidden; }
        .b { font-weight: 700; }
        .g { font-size: 1.35em; }
      </style></head><body>${lineas}</body></html>`;

      const iframe = document.createElement('iframe');
      iframe.setAttribute('aria-hidden', 'true');
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = '0';
      document.body.appendChild(iframe);

      const doc = iframe.contentDocument || iframe.contentWindow.document;
      doc.open();
      doc.write(html);
      doc.close();

      setTimeout(() => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } finally {
          setTimeout(() => { iframe.remove(); resolve(); }, 1000);
        }
      }, 150);
    });
  }

  /** Imprime un DocumentoImpresion { impresora, columnas, angosto, escPosBase64, lineas }. */
  async function imprimir(documento) {
    if (!documento) return;
    if (modo() === 'qz') {
      try {
        await imprimirQz(documento);
        return;
      } catch (e) {
        console.warn('QZ Tray no disponible, se usa la impresion del navegador.', e);
        window.App.toast('QZ Tray no respondio. Se usara la impresion del navegador.', 'warn', 6000);
      }
    }
    await imprimirNavegador(documento);
  }

  async function listarImpresoras() {
    const qz = await conectarQz();
    const lista = await qz.printers.find();
    return Array.isArray(lista) ? lista : [lista];
  }

  async function impresoraPredeterminada() {
    const qz = await conectarQz();
    return qz.printers.getDefault();
  }

  return { imprimir, imprimirNavegador, listarImpresoras, impresoraPredeterminada, modo, guardarModo, conectarQz };
})();
