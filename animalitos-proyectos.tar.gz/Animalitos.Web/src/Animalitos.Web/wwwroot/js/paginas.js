/* ============================================================
   Paginas de consulta: tickets, cuadre, ventas por loteria,
   resultados, impresora y proceso de resultados (admin).
   Cada vista marca su contenedor con data-pagina="...".
   ============================================================ */
'use strict';

(() => {
  const { App } = window;
  const $ = (sel, raiz = document) => raiz.querySelector(sel);
  const $$ = (sel, raiz = document) => [...raiz.querySelectorAll(sel)];

  const indiceColumna = (columnas, patrones, porDefecto) => {
    for (const p of patrones) {
      const i = columnas.findIndex((c) => p.test(c));
      if (i >= 0) return i;
    }
    return porDefecto;
  };

  async function verTicket(numero, serial) {
    try {
      const t = await App.get(`/tickets/ticket${App.qs({ numero, serial })}`);
      await App.modal({ titulo: `Ticket ${t.numeroTicket}`, icono: 'ti-receipt', html: `<div class="ticket-preview">${App.esc(App.ticketTexto(t))}</div>` });
    } catch (e) { App.error(e); }
  }

  // ================================================================ Inicio (modulos en construccion)
  function inicio() {
    $$('[data-construccion]').forEach((b) => b.addEventListener('click', () =>
      App.alerta(`El modulo "${b.dataset.construccion}" ya esta disponible en la API y su pantalla se entrega en la fase 2 de la migracion.`, { titulo: 'Modulo en construccion', tipo: 'info' })));
  }

  // ================================================================ Tickets (movimientos)
  async function tickets() {
    const desde = $('#f-desde');
    const hasta = $('#f-hasta');
    const estado = $('#f-estado');
    desde.value = hasta.value = App.hoyISO();

    try {
      const estados = await App.get('/tickets/estados', { ocupar: false });
      const lista = App.opcionesDesdeTabla(estados, 'id_status_ticket', 'nmb_status_ticket');
      const tieneCero = lista.some((o) => String(o.valor) === '0');
      App.opciones(estado, lista, tieneCero ? {} : { vacio: 'Todos' });
    } catch { App.opciones(estado, [], { vacio: 'Todos' }); }

    const pintar = (datos) => {
      App.tabla($('#tabla-tickets'), datos.tickets, {
        ocultarIds: false,
        vacio: 'No hay tickets para los filtros seleccionados.',
        alClic: (fila, cols) => {
          const iNro = indiceColumna(cols, [/^nro_?ticket$/i, /ticket/i], 2);
          const iSer = indiceColumna(cols, [/serial/i], 3);
          verTicket(String(fila[iNro] ?? ''), String(fila[iSer] ?? ''));
        }
      });
      $('#m-cantidad').textContent = datos.totales.cantidadTickets;
      $('#m-entradas').textContent = App.monto(datos.totales.entradas);
      $('#m-salidas').textContent = App.monto(datos.totales.salidas);
      $('#m-caja').textContent = App.monto(datos.totales.totalCaja);
    };

    const filtros = () => {
      if (desde.value && hasta.value && desde.value > hasta.value) {
        App.alerta('Fecha inicial no debe ser mayor a fecha final.');
        return null;
      }
      return { desde: desde.value, hasta: hasta.value, idEstado: estado.value || 0 };
    };

    $('#btn-buscar').addEventListener('click', async () => {
      const f = filtros();
      if (!f) return;
      try { pintar(await App.get(`/tickets/datos${App.qs(f)}`)); } catch (e) { App.error(e); }
    });

    $('#btn-imprimir-cuadre').addEventListener('click', async () => {
      const f = filtros();
      if (!f) return;
      try {
        const r = await App.post('/tickets/imprimir-cuadre', {
          desde: f.desde || null,
          hasta: f.hasta || null,
          idEstado: Number(f.idEstado) || null,
          estado: estado.selectedOptions[0]?.textContent || 'Todos'
        });
        await window.Impresion.imprimir(r.impresion);
      } catch (e) { App.error(e); }
    });

    try { pintar(await App.get('/tickets/datos')); } catch (e) { App.error(e); }
  }

  // ================================================================ Cuadre
  async function cuadre() {
    const desde = $('#f-desde');
    const hasta = $('#f-hasta');
    desde.value = hasta.value = App.hoyISO();

    const pintar = (d) => {
      App.tabla($('#tabla-cuadre'), d.detalle, { vacio: 'Sin movimientos.' });
      $('#m-entradas').textContent = App.monto(d.resumen.entradas);
      $('#m-salidas').textContent = App.monto(d.resumen.salidas);
      $('#m-taquilla').textContent = App.monto(d.resumen.taquilla);
      $('#m-utilidad').textContent = App.monto(d.resumen.utilidad);
    };

    $('#btn-buscar').addEventListener('click', async () => {
      if (desde.value > hasta.value) return App.alerta('Fecha inicial no debe ser mayor a fecha final.');
      try { pintar(await App.get(`/reportes/cuadre/datos${App.qs({ desde: desde.value, hasta: hasta.value })}`)); } catch (e) { App.error(e); }
    });

    try { pintar(await App.get('/reportes/cuadre/datos')); } catch (e) { App.error(e); }
  }

  // ================================================================ Ventas por loteria
  async function ventasLoteria() {
    const desde = $('#f-desde');
    const hasta = $('#f-hasta');
    const loteria = $('#f-loteria');
    desde.value = hasta.value = App.hoyISO();

    try {
      const tabla = await App.get('/reportes/ventas/loterias', { ocupar: false });
      App.opciones(loteria, App.opcionesDesdeTabla(tabla, 'idLot', 'nombLot').filter((o) => String(o.valor) !== '0'), { vacio: 'Todas' });
    } catch { App.opciones(loteria, [], { vacio: 'Todas' }); }

    const fila = (titulo, d, clase) => `<tr>
        <td class="font-semibold text-tx-3">${App.esc(titulo)}</td>
        <td class="num ${clase}">${App.monto(d.total)}</td>
        <td class="num">${App.monto(d.animalitos)}</td>
        <td class="num">${App.monto(d.tripletas)}</td>
      </tr>`;

    const consultar = async () => {
      if (desde.value > hasta.value) return App.alerta('Fecha inicial no debe ser mayor a fecha final...');
      try {
        const r = await App.get(`/reportes/ventas/datos${App.qs({
          modo: loteria.value ? 'loteria' : 'taquilla',
          idLoteria: loteria.value || null,
          desde: desde.value,
          hasta: hasta.value
        })}`);
        $('#tabla-ventas').innerHTML =
          fila('Ventas', r.ventas, 'col-monto-pos') +
          fila('Premios', r.premios, 'col-monto-neg') +
          fila('Tickets anulados', r.anulados, 'metric-gold') +
          fila('Utilidad', r.utilidad, 'metric-blue');
      } catch (e) { App.error(e); }
    };

    $('#btn-buscar').addEventListener('click', consultar);
    loteria.addEventListener('change', consultar);
    consultar();
  }

  // ================================================================ Resultados
  async function resultados() {
    const loteria = $('#f-loteria');
    const fecha = $('#f-fecha');
    fecha.value = App.hoyISO();
    fecha.max = App.hoyISO();

    try {
      const lista = await App.get('/resultados/loterias', { ocupar: false });
      App.opciones(loteria, lista.map((l) => ({ valor: l.idLoteria, texto: l.nombre })), { vacio: 'Todas (hoy)' });
    } catch { App.opciones(loteria, [], { vacio: 'Todas (hoy)' }); }

    const buscar = async () => {
      if (fecha.value > App.hoyISO()) return App.alerta('La fecha no debe ser mayor a la fecha actual.');
      try {
        const datos = await App.get(`/resultados/datos${App.qs({ idLoteria: loteria.value || null, fecha: loteria.value ? fecha.value : null })}`);
        App.tabla($('#tabla-resultados'), datos, { vacio: 'No hay resultados.' });
      } catch (e) { App.error(e); }
    };

    $('#btn-buscar').addEventListener('click', buscar);
    loteria.addEventListener('change', buscar);
    buscar();
  }

  // ================================================================ Impresora
  async function impresora() {
    const { Impresion } = window;
    const nombre = $('#imp-nombre');
    const ancho = $('#imp-ancho');
    const letra = $('#imp-letra');
    const estadoQz = $('#imp-estado-qz');

    const pintarModo = () => $$('[data-modo-imp]').forEach((b) =>
      b.classList.toggle('active-all', b.dataset.modoImp === Impresion.modo()));

    $$('[data-modo-imp]').forEach((b) => b.addEventListener('click', () => { Impresion.guardarModo(b.dataset.modoImp); pintarModo(); }));
    pintarModo();

    try {
      const d = await App.get('/impresora/configuracion');
      const anchos = App.opcionesDesdeTabla(d.anchos, 'nomb_ancho_ticket', 'nomb_ancho_ticket').map((o) => ({ valor: o.texto, texto: o.texto }));
      const letras = App.opcionesDesdeTabla(d.letras, 'num_letra', 'num_letra').map((o) => ({ valor: o.texto, texto: o.texto }));
      App.opciones(ancho, anchos.length ? anchos : [{ valor: '58', texto: '58 mm' }, { valor: '80', texto: '80 mm' }]);
      App.opciones(letra, letras.length ? letras : [{ valor: '7', texto: '7' }, { valor: '8', texto: '8' }]);
      nombre.value = d.configuracion.nombreImpresora || '';
      if (d.configuracion.anchoTicket) ancho.value = d.configuracion.anchoTicket;
      if (d.configuracion.tamanoLetra) letra.value = d.configuracion.tamanoLetra;
      $('#imp-firma').textContent = d.firmaHabilitada
        ? 'Firma de QZ Tray configurada en el servidor: la impresion puede ser silenciosa.'
        : 'Firma de QZ Tray no configurada: QZ Tray pedira permiso la primera vez (marque "Recordar").';
    } catch (e) { App.error(e); }

    $('#btn-detectar').addEventListener('click', async () => {
      estadoQz.textContent = 'Buscando impresoras con QZ Tray...';
      try {
        const lista = await Impresion.listarImpresoras();
        $('#imp-lista').innerHTML = lista.map((p) => `<option value="${App.esc(p)}"></option>`).join('');
        if (!nombre.value) nombre.value = (await Impresion.impresoraPredeterminada()) || '';
        estadoQz.textContent = `QZ Tray conectado: ${lista.length} impresora(s) encontradas.`;
      } catch (e) {
        estadoQz.textContent = 'QZ Tray no esta disponible en este equipo. Instalelo o use la impresion del navegador.';
        console.warn(e);
      }
    });

    $('#btn-guardar-imp').addEventListener('click', async () => {
      if (!nombre.value.trim()) return App.alerta('Indique el nombre de la impresora.').then(() => nombre.focus());
      try {
        const r = await App.post('/impresora/guardar', {
          nombreImpresora: nombre.value.trim(),
          anchoTicket: ancho.value,
          tamanoLetra: letra.value
        });
        App.toast(r.mensaje, 'ok');
        await Impresion.imprimir(r.impresion);
      } catch (e) { App.error(e); }
    });
  }

  // ================================================================ Proceso de resultados (admin)
  async function adminResultados() {
    const log = $('#log-proceso');
    const selLoteria = $('#man-loteria');
    const fecha = $('#man-fecha');
    const codigo = $('#man-codigo');
    const tipoTicket = $('#f-tipo-ticket');
    let sorteoElegido = null;
    let automatico = false;
    let temporizador = null;

    fecha.value = App.hoyISO();
    fecha.max = App.hoyISO();

    const registrar = (texto, tipo = '') => {
      if (log.querySelector('.text-tx-5')) log.innerHTML = '';
      const hora = new Date().toLocaleTimeString('es-VE');
      const div = document.createElement('div');
      div.className = tipo === 'error' ? 'text-alerta-claro' : tipo === 'ok' ? 'text-av-5' : '';
      div.textContent = `[${hora}] ${texto}`;
      log.prepend(div);
      while (log.children.length > 200) log.lastChild.remove();
    };

    const pintarResumen = (r) => {
      $('#m-jugadas').textContent = r.jugadas.procesadas;
      $('#m-ganadoras').textContent = r.jugadas.ganadoras;
      $('#m-perdedoras').textContent = r.jugadas.perdedoras;
      $('#m-errores').textContent = r.jugadas.conError;
      r.resultados.forEach((x) => registrar(`${x.loteria}: ${x.codigo} ${x.animal} (${x.fuente})${x.nuevo ? '' : ' - ya registrado'}`, 'ok'));
      r.mensajes.forEach((m) => registrar(m));
      registrar(`Jugadas procesadas: ${r.jugadas.procesadas} · Ganadoras: ${r.jugadas.ganadoras} · Perdedoras: ${r.jugadas.perdedoras}`);
    };

    const cargarPendientes = async () => {
      try {
        const datos = await App.get(`/admin/resultados/pendientes${App.qs({ idTipoTicket: tipoTicket.value || null })}`, { ocupar: false });
        $('#cant-pendientes').textContent = datos.filas.length;
        App.tabla($('#tabla-pendientes'), datos, { ocultarIds: true, vacio: 'No hay jugadas pendientes.' });
      } catch (e) { $('#tabla-pendientes').innerHTML = `<p class="field-error">${App.esc(e.message)}</p>`; }
    };

    const pintarSorteos = (lista) => {
      const cont = $('#man-sorteos');
      sorteoElegido = null;
      if (!lista.length) { cont.innerHTML = '<p class="tabla-vacia">No hay sorteos.</p>'; return; }
      cont.innerHTML = `<div class="flex flex-col gap-1">${lista.map((s, i) => `
          <div class="sorteo-row" data-i="${i}" tabindex="0">
            <input type="radio" name="sorteo-manual" class="glass-check" tabindex="-1">
            <div class="sorteo-nombre">${App.esc(s.loteria)}<span class="col-sub">${App.esc(s.sorteo)} · codigo max ${s.codigoMaximo}</span></div>
            <div class="sorteo-hora">#${s.idSorteo}</div>
          </div>`).join('')}</div>`;
      $$('.sorteo-row', cont).forEach((fila) => fila.addEventListener('click', () => {
        $$('.sorteo-row', cont).forEach((f) => { f.classList.remove('selected'); f.querySelector('input').checked = false; });
        fila.classList.add('selected');
        fila.querySelector('input').checked = true;
        sorteoElegido = lista[Number(fila.dataset.i)];
        codigo.focus();
      }));
    };

    async function procesarAutomatico(ocupar) {
      try {
        registrar('Buscando resultados...');
        const r = await App.post('/admin/resultados/automatico', {}, { ocupar, texto: 'Buscando resultados y procesando jugadas...' });
        pintarResumen(r);
        cargarPendientes();
        return r.proximaEjecucionMs;
      } catch (e) {
        registrar(e.message, 'error');
        if (ocupar) App.error(e);
        return 60_000;
      }
    }

    function programar(ms) {
      clearTimeout(temporizador);
      if (!automatico) return;
      const espera = Math.max(15_000, Number(ms) || 60_000);
      $('#auto-estado').textContent = `Modo automatico activo. Proxima ejecucion en ${Math.round(espera / 1000)} s.`;
      temporizador = setTimeout(async () => programar(await procesarAutomatico(false)), espera);
    }

    $('#btn-procesar').addEventListener('click', () => procesarAutomatico(true));

    $('#btn-auto').addEventListener('click', async () => {
      automatico = !automatico;
      const b = $('#btn-auto');
      b.innerHTML = automatico ? '<i class="ti ti-player-stop"></i> Detener modo automatico' : '<i class="ti ti-refresh"></i> Iniciar modo automatico';
      b.classList.toggle('btn-danger', automatico);
      b.classList.toggle('btn-success', !automatico);
      if (automatico) {
        registrar('Modo automatico iniciado.');
        programar(await procesarAutomatico(false));
      } else {
        clearTimeout(temporizador);
        $('#auto-estado').textContent = 'Modo automatico detenido.';
        registrar('Modo automatico detenido.');
      }
    });

    selLoteria.addEventListener('change', async () => {
      try {
        pintarSorteos(await App.get(`/admin/resultados/sorteos${App.qs({ idLoteria: selLoteria.value || null })}`, { ocupar: false }));
      } catch (e) { App.error(e); }
    });

    codigo.addEventListener('keydown', (e) => {
      if (e.key.length === 1 && !/\d/.test(e.key)) e.preventDefault();
      if (e.key === 'Enter') { e.preventDefault(); $('#btn-manual').click(); }
    });

    $('#btn-manual').addEventListener('click', async () => {
      if (!sorteoElegido) return App.alerta('Seleccione el sorteo.');
      const cod = App.normalizarCodigo(codigo.value);
      if (!cod) return App.alerta('Ingrese codigo...').then(() => codigo.focus());
      if (Number(cod) > sorteoElegido.codigoMaximo) return App.alerta('Codigo invalido...').then(() => codigo.focus());
      if (fecha.value > App.hoyISO()) return App.alerta('La fecha no debe ser mayor a la fecha actual.');

      const ok = await App.confirmar(
        `Realmente desea procesar el resultado "${cod}" para la loteria "${sorteoElegido.loteria.toUpperCase()}" del "${sorteoElegido.sorteo.toUpperCase()}" (${fecha.value})?`,
        'Resultado manual');
      if (!ok) return;

      try {
        const r = await App.post('/admin/resultados/manual', {
          idLoteria: sorteoElegido.idLoteria,
          idSorteo: sorteoElegido.idSorteo,
          codigo: cod,
          fecha: fecha.value
        }, { texto: 'Procesando jugadas del sorteo...' });
        pintarResumen(r);
        codigo.value = '';
        cargarPendientes();
        App.toast('Resultado procesado.', 'ok');
      } catch (e) { App.error(e); }
    });

    tipoTicket.addEventListener('change', cargarPendientes);

    try {
      const d = await App.get('/admin/resultados/datos');
      App.opciones(selLoteria, d.loterias.filter((l) => l.idLoteria > 0).map((l) => ({ valor: l.idLoteria, texto: l.nombre })), { vacio: 'Sorteos pendientes de todas' });
      App.opciones(tipoTicket, App.opcionesDesdeTabla(d.tiposTicket, 'idTipTck', 'nombTipTckLar').filter((o) => String(o.valor) !== '0'), { vacio: 'Todos los tipos de ticket' });
      pintarSorteos(d.sorteos);
      registrar(`Intervalo automatico configurado: ${Math.round(d.intervalo.minimoMs / 1000)} - ${Math.round(d.intervalo.maximoMs / 1000)} s.`);
    } catch (e) { App.error(e); }

    cargarPendientes();

    window.addEventListener('beforeunload', (e) => {
      if (automatico) { e.preventDefault(); e.returnValue = ''; }
    });
  }

  // ================================================================ Arranque
  const paginas = {
    tickets,
    cuadre,
    'ventas-loteria': ventasLoteria,
    resultados,
    impresora,
    'admin-resultados': adminResultados
  };

  document.addEventListener('DOMContentLoaded', () => {
    inicio();
    const pagina = document.querySelector('[data-pagina]')?.dataset.pagina;
    if (pagina && paginas[pagina]) paginas[pagina]();
  });
})();
