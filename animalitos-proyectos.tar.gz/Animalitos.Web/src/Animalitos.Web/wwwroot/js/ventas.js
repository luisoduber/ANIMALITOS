/* ============================================================
   Pantalla de venta (antes frm_ventas + frmTrip).

   Reloj interno: se sincroniza con la hora de cierre del servidor al
   cargar y cada minuto. Cada segundo se revisan los sorteos y las
   jugadas montadas: al llegar la hora del sorteo se retiran de la
   pantalla (medida de seguridad del sistema original). La API vuelve a
   validar el cierre al vender, asi que una pantalla manipulada no
   puede vender un sorteo cerrado.
   ============================================================ */
'use strict';

(() => {
  const { App, Impresion } = window;
  const $ = (sel, raiz = document) => raiz.querySelector(sel);
  const $$ = (sel, raiz = document) => [...raiz.querySelectorAll(sel)];

  const INTERVALO_CONTROL_MS = 60_000;   // Igual que tmpProceso del WinForms.
  const MINUTOS_PROXIMO = 5;             // Sorteos por cerrar se resaltan.

  const S = {
    usuario: null,
    limites: null,
    parametros: null,
    divisa: '',
    loterias: [],
    sorteos: [],
    productos: new Map(),        // "idLot|codigo" -> { nombre, abrev }
    loteriasConProductos: new Set(),
    seleccion: new Set(),        // "idLot|idSort"
    jugadas: [],
    loteriasTrip: [],
    seleccionTrip: new Set(),    // idLot
    tripletas: [],
    modo: 'animalitos',
    filtroLoteria: '',
    enviando: false
  };

  const clave = (idLoteria, idSorteo) => `${idLoteria}|${idSorteo}`;
  const topeJugada = () => Number(S.limites?.montoMaxJugada) || 0;
  const topeTripleta = () => Number(S.limites?.montoMaxTripleta) || 0;
  const topeTicket = () => Number(S.limites?.montoMaxTicket) || 0;
  const minimoJugada = () => Number(S.limites?.montoMinJugada) || 0;

  // ================================================================ Carga inicial
  async function cargar() {
    const inicio = Date.now();
    const datos = await App.get('/ventas/estado', { texto: 'Cargando sorteos...' });
    App.Reloj.sincronizar(datos.hora.horaCierre, inicio, Date.now());

    S.usuario = datos.usuario;
    S.limites = datos.usuario.limites;
    S.divisa = (datos.usuario.divisa || '').toUpperCase();
    S.parametros = datos.parametros;
    S.loterias = datos.loterias;
    S.sorteos = ordenarSorteos(datos.sorteos);
    S.loteriasTrip = datos.loteriasTripleta;

    S.productos.clear();
    S.loteriasConProductos.clear();
    datos.productos.forEach((p) => {
      const codigo = App.normalizarCodigo(p.codigo);
      S.productos.set(`${p.idLoteria}|${codigo}`, { nombre: (p.nombre || '').toUpperCase(), abrev: (p.abreviatura || '').toUpperCase() });
      S.loteriasConProductos.add(p.idLoteria);
    });

    $('#lbl-divisa').textContent = S.divisa;
    $('#lbl-limites').textContent =
      `Min ${App.monto(minimoJugada())} · Max jugada ${App.monto(topeJugada())} · Max ticket ${App.monto(topeTicket())}`;

    App.opciones($('#filtro-loteria'), S.loterias.map((l) => ({ valor: l.idLoteria, texto: l.nombre })), { vacio: 'Todas las loterias' });

    retirarVencidos(false);
    pintarSorteos();
    pintarLoteriasTrip();
    pintarJugadas();
    pintarTripletas();
    pintarTotales(datos.totales);
    $('#nav-clock')?.removeAttribute('hidden');
    $('#txt-codigo').focus();
  }

  function ordenarSorteos(lista) {
    return [...lista].sort((a, b) => a.horaSorteo.localeCompare(b.horaSorteo) || a.nombreLoteria.localeCompare(b.nombreLoteria));
  }

  // ================================================================ Reloj y cierre de sorteos
  function tick() {
    const reloj = $('[data-reloj]');
    if (reloj) reloj.textContent = App.Reloj.texto();
    retirarVencidos(true);
  }

  /** Retira los sorteos y las jugadas cuya hora ya llego (antes: work_proc_sorteos). */
  function retirarVencidos(avisar) {
    const ahora = App.Reloj.ahora();
    const vencido = (hora) => ahora >= App.Reloj.cierre(hora);

    const antes = S.sorteos.length;
    S.sorteos = S.sorteos.filter((s) => !vencido(s.horaSorteo));
    const sorteosRetirados = antes - S.sorteos.length;

    const vigentes = new Set(S.sorteos.map((s) => clave(s.idLoteria, s.idSorteo)));
    [...S.seleccion].forEach((k) => { if (!vigentes.has(k)) S.seleccion.delete(k); });

    const jugadasAntes = S.jugadas.length;
    S.jugadas = S.jugadas.filter((j) => !vencido(j.horaSorteo));
    const jugadasRetiradas = jugadasAntes - S.jugadas.length;

    if (sorteosRetirados > 0) pintarSorteos();
    if (jugadasRetiradas > 0) {
      pintarJugadas();
      if (avisar) {
        App.toast(`Se retiraron ${jugadasRetiradas} jugada(s) de sorteos que ya cerraron.`, 'warn', 7000);
      }
    }

    // Resalta los sorteos que cierran pronto.
    if (!avisar || sorteosRetirados > 0) return;
    const limite = new Date(ahora.getTime() + MINUTOS_PROXIMO * 60_000);
    $$('#lista-sorteos .sorteo-row').forEach((fila) => {
      fila.classList.toggle('proximo', App.Reloj.cierre(fila.dataset.hora) <= limite);
    });
  }

  /** Control de cada minuto: estado de la taquilla y resincronizacion del reloj. */
  async function control() {
    try {
      const inicio = Date.now();
      const r = await App.get('/ventas/control', { ocupar: false });
      App.Reloj.sincronizar(r.hora.horaCierre, inicio, Date.now());
      if (!r.estado.activa) {
        await App.alerta('Usuario inactivo. Contacte con el administrador del sistema.', { tipo: 'error' });
        $('#form-salir')?.submit();
      }
    } catch (e) {
      if (e.status === 403) {
        await App.alerta(e.message, { tipo: 'error' });
        $('#form-salir')?.submit();
      }
      // Errores de red: se reintenta en el siguiente minuto; el reloj sigue corriendo localmente.
    }
  }

  // ================================================================ Sorteos (animalitos)
  function pintarSorteos() {
    const cont = $('#lista-sorteos');
    const lista = S.filtroLoteria ? S.sorteos.filter((s) => String(s.idLoteria) === S.filtroLoteria) : S.sorteos;
    $('#cant-seleccion').textContent = S.seleccion.size;

    if (lista.length === 0) {
      cont.innerHTML = '<p class="tabla-vacia">No hay sorteos abiertos.</p>';
      return;
    }

    const limite = new Date(App.Reloj.ahora().getTime() + MINUTOS_PROXIMO * 60_000);
    cont.innerHTML = lista.map((s) => {
      const k = clave(s.idLoteria, s.idSorteo);
      const sel = S.seleccion.has(k);
      const proximo = App.Reloj.cierre(s.horaSorteo) <= limite;
      return `<div class="sorteo-row ${sel ? 'selected' : ''} ${proximo ? 'proximo' : ''}" data-clave="${k}" data-hora="${App.esc(s.horaSorteo)}" role="checkbox" aria-checked="${sel}" tabindex="0">
          <input type="checkbox" class="glass-check" tabindex="-1" ${sel ? 'checked' : ''}>
          <div>
            <div class="sorteo-nombre"><span class="sorteo-ab">${App.esc(s.abreviaturaLoteria)}</span>${App.esc(s.nombreLoteria)}</div>
            ${s.nombreSorteo ? `<div class="col-sub">${App.esc(s.nombreSorteo)}</div>` : ''}
          </div>
          <div class="sorteo-hora">${App.hora12(s.horaSorteo)}</div>
        </div>`;
    }).join('');
  }

  function alternarSorteo(k) {
    if (S.seleccion.has(k)) S.seleccion.delete(k); else S.seleccion.add(k);
    const fila = $(`#lista-sorteos .sorteo-row[data-clave="${k}"]`);
    if (fila) {
      const sel = S.seleccion.has(k);
      fila.classList.toggle('selected', sel);
      fila.setAttribute('aria-checked', String(sel));
      fila.querySelector('input').checked = sel;
    }
    $('#cant-seleccion').textContent = S.seleccion.size;
    previsualizarProducto();
  }

  async function filtrarLoteria(valor) {
    S.filtroLoteria = valor;
    try {
      const lista = await App.get(`/ventas/sorteos${App.qs({ idLoteria: valor || null })}`, { ocupar: false });
      const nuevos = new Map(S.sorteos.map((s) => [clave(s.idLoteria, s.idSorteo), s]));
      lista.forEach((s) => nuevos.set(clave(s.idLoteria, s.idSorteo), s));
      S.sorteos = ordenarSorteos([...nuevos.values()]);
      retirarVencidos(false);
    } catch (e) {
      App.error(e);
    }
    pintarSorteos();
  }

  async function recargarSorteos() {
    try {
      const lista = await App.get('/ventas/sorteos', { ocupar: false });
      S.sorteos = ordenarSorteos(lista);
      retirarVencidos(false);
      pintarSorteos();
    } catch (e) {
      App.error(e);
    }
  }

  function sorteosSeleccionados() {
    return S.sorteos.filter((s) => S.seleccion.has(clave(s.idLoteria, s.idSorteo)));
  }

  function previsualizarProducto() {
    const cod = App.normalizarCodigo($('#txt-codigo').value);
    const s = sorteosSeleccionados()[0];
    const p = s && cod ? S.productos.get(`${s.idLoteria}|${cod}`) : null;
    $('#producto-preview').textContent = p ? `${cod} - ${p.nombre}` : '';
  }

  // ================================================================ Jugadas (animalitos)
  function agregarJugada() {
    const txtCodigo = $('#txt-codigo');
    const txtMonto = $('#txt-monto');
    const seleccionados = sorteosSeleccionados();

    if (seleccionados.length === 0) return App.alerta('Elija una loteria y sorteo.').then(() => txtCodigo.focus());
    if (!txtCodigo.value.trim()) return App.alerta('Ingrese un codigo.').then(() => txtCodigo.focus());
    if (!/^\d{1,2}$/.test(txtCodigo.value.trim())) return App.alerta('El codigo debe ser numerico (1 o 2 digitos).').then(() => txtCodigo.focus());

    const codigo = App.normalizarCodigo(txtCodigo.value);
    const monto = App.parseMonto(txtMonto.value);
    if (!Number.isFinite(monto) || monto <= 0) return App.alerta('Ingrese un monto.').then(() => txtMonto.focus());
    if (monto < minimoJugada()) return App.alerta(`El monto minimo de la jugada debe ser: ${App.monto(minimoJugada())}`).then(() => txtMonto.focus());
    if (topeJugada() > 0 && monto > topeJugada()) return App.alerta(`El maximo por jugada debe ser: ${App.monto(topeJugada())}`).then(() => txtMonto.focus());

    const avisos = [];
    for (const s of seleccionados) {
      if (Number(codigo) > s.codigoMaximo) {
        avisos.push(`Codigo "${codigo}" invalido para la loteria "${s.nombreLoteria.toUpperCase()}".`);
        continue;
      }

      const producto = S.productos.get(`${s.idLoteria}|${codigo}`);
      if (!producto && S.loteriasConProductos.has(s.idLoteria)) {
        avisos.push(`El codigo "${codigo}" no existe en la loteria "${s.nombreLoteria.toUpperCase()}".`);
        continue;
      }

      const existente = S.jugadas.find((j) => j.idLoteria === s.idLoteria && j.idSorteo === s.idSorteo && j.codigo === codigo);
      const total = totalJugadas();

      if (existente) {
        const nuevo = topeJugada() > 0 ? Math.min(existente.monto + monto, topeJugada()) : existente.monto + monto;
        if (topeTicket() > 0 && total - existente.monto + nuevo > topeTicket()) {
          avisos.push(`El maximo por ticket es de: ${App.monto(topeTicket())}`);
          break;
        }
        existente.monto = nuevo;
        continue;
      }

      if (topeTicket() > 0 && total + monto > topeTicket()) {
        avisos.push(`El maximo por ticket es de: ${App.monto(topeTicket())}`);
        break;
      }

      S.jugadas.push({
        idLoteria: s.idLoteria,
        idSorteo: s.idSorteo,
        nombreLoteria: s.nombreLoteria,
        abrev: s.abreviaturaLoteria,
        horaSorteo: s.horaSorteo,
        codigo,
        producto: producto?.abrev || '',
        productoNombre: producto?.nombre || '',
        monto
      });
    }

    ordenarJugadas();
    pintarJugadas();
    txtCodigo.value = '';
    $('#producto-preview').textContent = '';

    if (avisos.length) {
      App.alerta([...new Set(avisos)]).then(() => txtCodigo.focus());
    } else {
      txtCodigo.focus();
    }
  }

  function ordenarJugadas() {
    S.jugadas.sort((a, b) => b.horaSorteo.localeCompare(a.horaSorteo) || a.idSorteo - b.idSorteo || a.codigo.localeCompare(b.codigo));
  }

  const totalJugadas = () => S.jugadas.reduce((t, j) => t + j.monto, 0);

  function pintarJugadas() {
    const cuerpo = $('#tabla-jugadas tbody');
    if (S.jugadas.length === 0) {
      cuerpo.innerHTML = '<tr><td class="tabla-vacia" colspan="6">Sin jugadas. Seleccione sorteos, ingrese codigo y monto, y pulse Enter.</td></tr>';
    } else {
      cuerpo.innerHTML = S.jugadas.map((j, i) => `
        <tr class="clickable" data-indice="${i}" title="Clic para eliminar">
          <td><span class="sorteo-ab">${App.esc(j.abrev)}</span></td>
          <td class="col-sub">${App.hora12(j.horaSorteo)}</td>
          <td class="col-ticket">${App.esc(j.codigo)}</td>
          <td>${App.esc(j.productoNombre || j.producto)}</td>
          <td class="num col-monto-pos">${App.monto(j.monto)}</td>
          <td class="num"><i class="ti ti-x"></i></td>
        </tr>`).join('');
    }
    $('#total-jugado').textContent = App.monto(totalJugadas());
    $('#cant-jugadas').textContent = S.jugadas.length;
  }

  // ================================================================ Tripletas
  function pintarLoteriasTrip() {
    const cont = $('#lista-loterias-trip');
    if (S.loteriasTrip.length === 0) {
      cont.innerHTML = '<p class="tabla-vacia">No hay loterias con tripletas habilitadas.</p>';
      return;
    }
    cont.innerHTML = S.loteriasTrip.map((l) => {
      const sel = S.seleccionTrip.has(l.idLoteria);
      return `<div class="sorteo-row ${sel ? 'selected' : ''}" data-loteria="${l.idLoteria}" role="checkbox" aria-checked="${sel}" tabindex="0">
          <input type="checkbox" class="glass-check" tabindex="-1" ${sel ? 'checked' : ''}>
          <div class="sorteo-nombre"><span class="sorteo-ab">${App.esc(l.abreviatura)}</span>${App.esc(l.nombre)}</div>
          <div class="col-sub">00-${l.codigoMaximo}</div>
        </div>`;
    }).join('');
  }

  function alternarLoteriaTrip(id) {
    if (S.seleccionTrip.has(id)) S.seleccionTrip.delete(id); else S.seleccionTrip.add(id);
    pintarLoteriasTrip();
  }

  function agregarTripleta() {
    const campos = [$('#trip-c1'), $('#trip-c2'), $('#trip-c3')];
    const txtMonto = $('#trip-monto');
    const loterias = S.loteriasTrip.filter((l) => S.seleccionTrip.has(l.idLoteria));

    if (loterias.length === 0) return App.alerta('No se ha seleccionado ninguna loteria.');
    const vacio = campos.find((c) => !c.value.trim());
    if (vacio) return App.alerta('Ingrese un codigo.').then(() => vacio.focus());
    const invalido = campos.find((c) => !/^\d{1,2}$/.test(c.value.trim()));
    if (invalido) return App.alerta('Los codigos deben ser numericos (1 o 2 digitos).').then(() => invalido.focus());

    const codigos = campos.map((c) => App.normalizarCodigo(c.value));
    campos.forEach((c, i) => { c.value = codigos[i]; });

    if (codigos[0] === codigos[1]) return App.alerta(`El codigo "${codigos[0]}" del campo 1 es igual al del campo 2. Cambie la seleccion de los animalitos.`).then(() => campos[1].focus());
    if (codigos[0] === codigos[2]) return App.alerta(`El codigo "${codigos[0]}" del campo 1 es igual al del campo 3. Cambie la seleccion de los animalitos.`).then(() => campos[2].focus());
    if (codigos[1] === codigos[2]) return App.alerta(`El codigo "${codigos[1]}" del campo 2 es igual al del campo 3. Cambie la seleccion de los animalitos.`).then(() => campos[2].focus());

    const monto = App.parseMonto(txtMonto.value);
    if (!Number.isFinite(monto) || monto <= 0) return App.alerta('Ingrese un monto.').then(() => txtMonto.focus());
    if (monto < minimoJugada()) return App.alerta(`El monto minimo de la tripleta debe ser: ${App.monto(minimoJugada())}`).then(() => txtMonto.focus());
    if (topeTripleta() > 0 && monto > topeTripleta()) return App.alerta(`El maximo por tripleta debe ser: ${App.monto(topeTripleta())}`).then(() => txtMonto.focus());

    const avisos = [];
    for (const l of loterias) {
      const fuera = codigos.find((c) => Number(c) > l.codigoMaximo);
      if (fuera) {
        avisos.push(`Codigo "${fuera}" invalido para la loteria "${l.nombre.toUpperCase()}".`);
        continue;
      }

      const productos = codigos.map((c) => S.productos.get(`${l.idLoteria}|${c}`));
      if (productos.some((p) => !p) && S.loteriasConProductos.has(l.idLoteria)) {
        avisos.push(`Uno de los codigos no existe en la loteria "${l.nombre.toUpperCase()}".`);
        continue;
      }

      const existente = S.tripletas.find((t) => t.idLoteria === l.idLoteria && t.codigos.join('|') === codigos.join('|'));
      if (existente) {
        const suma = existente.monto + monto;
        if (topeTripleta() > 0 && suma > topeTripleta()) {
          avisos.push(`El monto maximo por tripleta es de: ${App.monto(topeTripleta())} para la loteria "${l.nombre.toUpperCase()}".`);
        }
        existente.monto = topeTripleta() > 0 ? Math.min(suma, topeTripleta()) : suma;
        continue;
      }

      S.tripletas.push({
        idLoteria: l.idLoteria,
        nombreLoteria: l.nombre,
        abrev: l.abreviatura,
        codigos,
        productos: productos.map((p) => p?.nombre || ''),
        monto
      });
    }

    S.tripletas.sort((a, b) => b.idLoteria - a.idLoteria);
    pintarTripletas();
    campos.forEach((c) => { c.value = ''; });
    if (avisos.length) App.alerta([...new Set(avisos)]).then(() => campos[0].focus());
    else campos[0].focus();
  }

  const totalTripletas = () => S.tripletas.reduce((t, x) => t + x.monto, 0);

  function pintarTripletas() {
    const cuerpo = $('#tabla-tripletas tbody');
    if (S.tripletas.length === 0) {
      cuerpo.innerHTML = '<tr><td class="tabla-vacia" colspan="4">Sin tripletas. Seleccione loterias, ingrese 3 codigos y el monto.</td></tr>';
    } else {
      cuerpo.innerHTML = S.tripletas.map((t, i) => `
        <tr class="clickable" data-indice="${i}" title="Clic para eliminar">
          <td><span class="sorteo-ab">${App.esc(t.abrev)}</span>${App.esc(t.nombreLoteria)}</td>
          <td>${t.codigos.map((c, n) => `<span class="col-ticket">${App.esc(c)}</span> ${App.esc(t.productos[n])}`).join(' · ')}</td>
          <td class="num col-monto-pos">${App.monto(t.monto)}</td>
          <td class="num"><i class="ti ti-x"></i></td>
        </tr>`).join('');
    }
    $('#total-tripletas').textContent = App.monto(totalTripletas());
    $('#cant-tripletas').textContent = S.tripletas.length;
  }

  // ================================================================ Venta / impresion
  async function imprimirTicket() {
    if (S.enviando) return;
    const esTripleta = S.modo === 'tripletas';
    if (esTripleta ? S.tripletas.length === 0 : S.jugadas.length === 0) return;

    retirarVencidos(true);
    if (!esTripleta && S.jugadas.length === 0) {
      return App.alerta('Sorteos cerrados, jugadas no procesadas.');
    }

    S.enviando = true;
    try {
      const datos = esTripleta
        ? await App.post('/ventas/vender-tripletas', {
            tripletas: S.tripletas.map((t) => ({ idLoteria: t.idLoteria, codigo1: t.codigos[0], codigo2: t.codigos[1], codigo3: t.codigos[2], monto: t.monto }))
          }, { texto: 'Procesando ticket...' })
        : await App.post('/ventas/vender', {
            jugadas: S.jugadas.map((j) => ({ idLoteria: j.idLoteria, idSorteo: j.idSorteo, codigo: j.codigo, monto: j.monto }))
          }, { texto: 'Procesando ticket...' });

      const r = datos.resultado;

      // Igual que el original: tras procesar se limpian las jugadas y la seleccion de sorteos.
      if (esTripleta) {
        S.tripletas = [];
        S.seleccionTrip.clear();
        pintarTripletas();
        pintarLoteriasTrip();
      } else {
        S.jugadas = [];
        S.seleccion.clear();
        pintarJugadas();
        pintarSorteos();
      }

      if (r.procesado && datos.impresion) {
        $('#lbl-ultimo-ticket').textContent = r.ticket.numeroTicket;
        App.toast(`Ticket ${r.ticket.numeroTicket} registrado. Total ${App.monto(r.ticket.total)}`, 'ok');
        try {
          await Impresion.imprimir(datos.impresion);
        } catch (e) {
          App.alerta(`El ticket ${r.ticket.numeroTicket} se registro pero no se pudo imprimir. Use "Reimprimir". (${e.message})`, { tipo: 'error' });
        }
      }

      if (r.mensajes?.length) {
        await App.alerta(r.mensajes, { titulo: r.procesado ? 'Ticket procesado con observaciones' : 'Ticket no procesado', tipo: r.procesado ? 'warn' : 'error' });
      }

      if (r.haySorteosCerrados) await recargarSorteos();
    } catch (e) {
      if (e.status === 0) {
        await App.alerta('No se pudo confirmar la venta por falta de comunicacion. Revise "Ultimo ticket" en el panel antes de reintentar para no duplicar el ticket.', { tipo: 'error' });
      } else {
        await App.error(e);
      }
    } finally {
      S.enviando = false;
      refrescarTotales();
      (esTripleta ? $('#trip-c1') : $('#txt-codigo')).focus();
    }
  }

  // ================================================================ Totales
  function pintarTotales(t) {
    if (!t) return;
    $('#tot-ventas').textContent = App.monto(t.ventas);
    $('#tot-animalitos').textContent = App.monto(t.ventasAnimalitos);
    $('#tot-tripletas').textContent = App.monto(t.ventasTripletas);
    $('#tot-pagados').textContent = App.monto(t.pagados);
    $('#tot-anulados').textContent = App.monto(t.anulados);
    $('#tot-caja').textContent = App.monto(t.totalCaja);
    $('#lbl-ultimo-ticket').textContent = t.ultimoTicket || '-';
  }

  async function refrescarTotales() {
    try {
      pintarTotales(await App.get('/ventas/totales', { ocupar: false }));
    } catch { /* se reintenta en la siguiente operacion */ }
  }

  // ================================================================ Operaciones de ticket
  function datosTicket({ requiereSerial = true } = {}) {
    const numero = $('#txt-nro-ticket').value.trim();
    const serial = $('#txt-serial').value.trim();
    if (!numero) {
      App.alerta('Ingrese Nro. ticket.').then(() => $('#txt-nro-ticket').focus());
      return null;
    }
    if (requiereSerial && !serial) {
      App.alerta('Ingrese Nro. serial.').then(() => $('#txt-serial').focus());
      return null;
    }
    return { numero, serial };
  }

  function limpiarTicket() {
    $('#txt-nro-ticket').value = '';
    $('#txt-serial').value = '';
  }

  async function pagar() {
    const d = datosTicket();
    if (!d) return;
    try {
      const r = await App.post('/ventas/pagar', d);
      await App.alerta(r.mensaje, { titulo: 'Transaccion exitosa', tipo: 'ok' });
      limpiarTicket();
      refrescarTotales();
    } catch (e) { App.error(e); }
  }

  async function anular() {
    const d = datosTicket();
    if (!d) return;
    if (!(await App.confirmar(`Desea anular el ticket Nro. ${d.numero}?`, 'Anular ticket'))) return;
    try {
      const r = await App.post('/ventas/anular', d);
      await App.alerta(r.mensaje, { titulo: 'Transaccion exitosa', tipo: 'ok' });
      limpiarTicket();
      refrescarTotales();
    } catch (e) { App.error(e); }
  }

  async function verificar() {
    const d = datosTicket();
    if (!d) return;
    try {
      const t = await App.get(`/ventas/ticket${App.qs(d)}`);
      await App.modal({ titulo: `Ticket ${t.numeroTicket}`, icono: 'ti-receipt', html: `<div class="ticket-preview">${App.esc(App.ticketTexto(t))}</div>` });
    } catch (e) { App.error(e); }
  }

  async function repetir() {
    const numero = $('#txt-nro-ticket').value.trim();
    if (!numero) return App.alerta('Ingrese Nro. ticket a repetir.').then(() => $('#txt-nro-ticket').focus());
    if (Number(numero) === 0) return App.alerta('Ingrese Nro. ticket diferente de cero.');
    const sorteos = sorteosSeleccionados();
    if (sorteos.length === 0) return App.alerta('Elija una loteria y sorteo.');

    try {
      const jugadas = await App.post('/ventas/repetir', {
        numeroTicket: numero,
        sorteos: sorteos.map((s) => ({ idLoteria: s.idLoteria, idSorteo: s.idSorteo }))
      });

      S.jugadas = jugadas.map((j) => {
        const p = S.productos.get(`${j.idLoteria}|${App.normalizarCodigo(j.codigo)}`);
        return {
          idLoteria: j.idLoteria,
          idSorteo: j.idSorteo,
          nombreLoteria: j.nombreLoteria,
          abrev: j.abreviaturaLoteria,
          horaSorteo: j.horaSorteo,
          codigo: App.normalizarCodigo(j.codigo),
          producto: p?.abrev || String(j.producto || '').slice(0, 3).toUpperCase(),
          productoNombre: p?.nombre || String(j.producto || '').toUpperCase(),
          monto: Number(j.monto) || 0
        };
      });
      ordenarJugadas();
      retirarVencidos(false);
      pintarJugadas();
      App.toast(`Se cargaron ${S.jugadas.length} jugada(s) del ticket ${numero}.`, 'info');
    } catch (e) { App.error(e); }
  }

  async function reimprimir() {
    try {
      const r = await App.post('/ventas/reimprimir', {}, { texto: 'Preparando reimpresion...' });
      await Impresion.imprimir(r.impresion);
      App.toast(`Ticket ${r.ticket.numeroTicket} reimpreso.`, 'ok');
    } catch (e) { App.error(e); }
  }

  async function verResultados() {
    let loterias = [];
    try { loterias = await App.get('/resultados/loterias', { ocupar: false }); } catch { /* opcional */ }

    const html = `
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
        <div class="sm:col-span-2">
          <label class="field-label" for="res-loteria">Loteria</label>
          <select id="res-loteria" class="glass-select">
            <option value="">Todas (hoy)</option>
            ${loterias.map((l) => `<option value="${l.idLoteria}">${App.esc(l.nombre)}</option>`).join('')}
          </select>
        </div>
        <div>
          <label class="field-label" for="res-fecha">Fecha</label>
          <input id="res-fecha" type="date" class="glass-input" value="${App.hoyISO()}" max="${App.hoyISO()}">
        </div>
      </div>
      <div id="res-tabla" class="max-h-[50vh] overflow-y-auto"></div>`;

    const promesa = App.modal({ titulo: 'Resultados', icono: 'ti-trophy', html, grande: true, botones: [{ texto: 'Cerrar', valor: null, principal: true }] });
    const cargarResultados = async () => {
      try {
        const idLoteria = $('#res-loteria').value;
        const datos = await App.get(`/ventas/resultados${App.qs({ idLoteria, fecha: idLoteria ? $('#res-fecha').value : null })}`, { ocupar: false });
        App.tabla($('#res-tabla'), datos, { vacio: 'No hay resultados.' });
      } catch (e) { $('#res-tabla').innerHTML = `<p class="field-error">${App.esc(e.message)}</p>`; }
    };
    $('#res-loteria').addEventListener('change', cargarResultados);
    $('#res-fecha').addEventListener('change', cargarResultados);
    cargarResultados();
    await promesa;
  }

  // ================================================================ Modo (animalitos | tripletas)
  function cambiarModo(modo) {
    S.modo = modo;
    $$('[data-modo]').forEach((b) => b.classList.toggle('active', b.dataset.modo === modo));
    $$('[data-panel]').forEach((p) => { p.hidden = p.dataset.panel !== modo; });
    (modo === 'tripletas' ? $('#trip-c1') : $('#txt-codigo')).focus();
  }

  // ================================================================ Eventos
  function soloDigitos(e) {
    if (e.key.length === 1 && !/\d/.test(e.key) && !e.ctrlKey && !e.metaKey) e.preventDefault();
  }

  function enlazarEventos() {
    // Sorteos
    $('#lista-sorteos').addEventListener('click', (e) => {
      const fila = e.target.closest('.sorteo-row');
      if (fila) alternarSorteo(fila.dataset.clave);
    });
    $('#lista-sorteos').addEventListener('keydown', (e) => {
      const fila = e.target.closest('.sorteo-row');
      if (fila && (e.key === ' ' || e.key === 'Enter')) { e.preventDefault(); alternarSorteo(fila.dataset.clave); }
    });
    $('#filtro-loteria').addEventListener('change', (e) => filtrarLoteria(e.target.value));
    $('#btn-todos').addEventListener('click', () => {
      const visibles = S.filtroLoteria ? S.sorteos.filter((s) => String(s.idLoteria) === S.filtroLoteria) : S.sorteos;
      visibles.forEach((s) => S.seleccion.add(clave(s.idLoteria, s.idSorteo)));
      pintarSorteos();
    });
    $('#btn-ninguno').addEventListener('click', () => { S.seleccion.clear(); pintarSorteos(); });
    $('#btn-actualizar').addEventListener('click', recargarSorteos);

    // Codigo y monto: Enter en codigo pasa al monto; Enter en monto agrega la jugada.
    const txtCodigo = $('#txt-codigo');
    const txtMonto = $('#txt-monto');
    txtCodigo.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); if (txtCodigo.value.trim()) { txtMonto.focus(); txtMonto.select(); } }
      else soloDigitos(e);
    });
    txtCodigo.addEventListener('input', previsualizarProducto);
    txtMonto.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); agregarJugada(); }
    });
    txtMonto.addEventListener('blur', () => {
      const v = App.parseMonto(txtMonto.value);
      if (Number.isFinite(v) && v > 0) txtMonto.value = App.monto(v);
    });
    $('#btn-agregar').addEventListener('click', agregarJugada);

    $('#tabla-jugadas tbody').addEventListener('click', (e) => {
      const fila = e.target.closest('tr[data-indice]');
      if (!fila) return;
      S.jugadas.splice(Number(fila.dataset.indice), 1);
      pintarJugadas();
      txtCodigo.focus();
    });
    $('#btn-limpiar').addEventListener('click', async () => {
      if (S.jugadas.length && await App.confirmar('Desea eliminar todas las jugadas montadas?')) { S.jugadas = []; pintarJugadas(); }
    });

    // Tripletas
    $('#lista-loterias-trip').addEventListener('click', (e) => {
      const fila = e.target.closest('.sorteo-row');
      if (fila) alternarLoteriaTrip(Number(fila.dataset.loteria));
    });
    const tripCampos = ['#trip-c1', '#trip-c2', '#trip-c3', '#trip-monto'].map((s) => $(s));
    tripCampos.forEach((campo, i) => {
      campo.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          if (i < 3) { if (campo.value.trim()) tripCampos[i + 1].focus(); }
          else agregarTripleta();
        } else if (e.key === 'Backspace' && i > 0 && i < 3 && !campo.value) {
          tripCampos[i - 1].focus();
        } else if (i < 3) {
          soloDigitos(e);
        }
      });
    });
    $('#trip-monto').addEventListener('blur', (e) => {
      const v = App.parseMonto(e.target.value);
      if (Number.isFinite(v) && v > 0) e.target.value = App.monto(v);
    });
    $('#btn-agregar-trip').addEventListener('click', agregarTripleta);
    $('#tabla-tripletas tbody').addEventListener('click', (e) => {
      const fila = e.target.closest('tr[data-indice]');
      if (!fila) return;
      S.tripletas.splice(Number(fila.dataset.indice), 1);
      pintarTripletas();
    });

    // Botones
    $$('[data-modo]').forEach((b) => b.addEventListener('click', () => cambiarModo(b.dataset.modo)));
    $$('[data-accion="imprimir"]').forEach((b) => b.addEventListener('click', imprimirTicket));
    $('#btn-pagar').addEventListener('click', pagar);
    $('#btn-anular').addEventListener('click', anular);
    $('#btn-verificar').addEventListener('click', verificar);
    $('#btn-repetir').addEventListener('click', repetir);
    $('#btn-reimprimir').addEventListener('click', reimprimir);
    $('#btn-resultados').addEventListener('click', verResultados);
    ['#txt-nro-ticket', '#txt-serial'].forEach((s) => $(s).addEventListener('keydown', soloDigitos));

    // Atajos: "+" o Esc imprimen el ticket (igual que el sistema original).
    document.addEventListener('keydown', (e) => {
      if (App.modalAbierto()) return;
      const enTicket = e.target.closest?.('#panel-ticket');
      if ((e.key === '+' || e.key === 'Add') && !enTicket) {
        e.preventDefault();
        imprimirTicket();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        imprimirTicket();
      } else if (e.key === 'F2') {
        e.preventDefault();
        cambiarModo(S.modo === 'animalitos' ? 'tripletas' : 'animalitos');
      }
    });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') { refrescarTotales(); control(); }
    });

    window.addEventListener('beforeunload', (e) => {
      if (S.jugadas.length || S.tripletas.length) { e.preventDefault(); e.returnValue = ''; }
    });
  }

  // ================================================================ Inicio
  document.addEventListener('DOMContentLoaded', async () => {
    enlazarEventos();
    try {
      await cargar();
    } catch (e) {
      await App.error(e, 'No se pudo cargar la pantalla de venta');
      return;
    }
    setInterval(tick, 1000);
    setInterval(control, INTERVALO_CONTROL_MS);
    tick();
  });
})();
