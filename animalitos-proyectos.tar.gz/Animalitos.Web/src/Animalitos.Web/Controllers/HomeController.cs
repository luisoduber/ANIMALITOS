using System.Diagnostics;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

public sealed class HomeController : Controller
{
    /// <summary>Menu de modulos (antes frmMenOpe). La taquilla va directo a la venta.</summary>
    public IActionResult Index()
    {
        if (User.EsTaquilla())
        {
            return RedirectToAction("Index", "Ventas");
        }

        var modulos = new List<ModuloMenu>
        {
            new("Ventas", "Venta de animalitos y tripletas", "ti-cash-register", "mc-icon-blue", Url.Action("Index", "Ventas")),
            new("Procesar resultados", "Resultados automaticos y manuales", "ti-trophy", "mc-icon-amber", Url.Action("Index", "AdminResultados")),
            new("Resultados", "Consulta de resultados por loteria", "ti-list-numbers", "mc-icon-teal", Url.Action("Index", "Resultados")),
            new("Movimientos", "Tickets de la taquilla y cuadre", "ti-ticket", "mc-icon-indigo", Url.Action("Index", "Tickets")),
            new("Cuadre", "Totales de venta por fecha", "ti-report-money", "mc-icon-green", Url.Action("Cuadre", "Reportes")),
            new("Ventas por loteria", "Ventas, premios y utilidad", "ti-chart-bar", "mc-icon-orange", Url.Action("Ventas", "Reportes")),
            new("Cambiar clave", "Actualice su clave de acceso", "ti-key", "mc-icon-blue", Url.Action("CambiarClave", "Cuenta")),
            new("Impresora", "Configuracion y prueba de impresion", "ti-printer", "mc-icon-teal", Url.Action("Index", "Impresora")),

            // Modulos administrativos: la API ya los expone; las pantallas se construyen en la fase 2.
            new("Cuadre grupos", "Cuadre general por grupo y divisa", "ti-building-bank", "mc-icon-green", null, false),
            new("Cuadre taquillas", "Cuadre por taquilla y divisa", "ti-calculator", "mc-icon-green", null, false),
            new("Anular ticket", "Anulacion administrativa", "ti-ticket-off", "mc-icon-orange", null, false),
            new("Ticket taquillas", "Jugadas por taquilla y sorteo", "ti-zoom-check", "mc-icon-indigo", null, false),
            new("Grupos / usuarios", "Administracion de grupos y taquillas", "ti-users-group", "mc-icon-blue", null, false),
            new("Control ventas", "Cupos y bloqueo de productos", "ti-adjustments", "mc-icon-amber", null, false),
            new("Limitar taquilla", "Cupo maximo por taquilla", "ti-lock-dollar", "mc-icon-orange", null, false),
            new("Control sorteos", "Bloqueo de sorteos", "ti-clock-cancel", "mc-icon-teal", null, false),
            new("Limitar loterias", "Estado y montos por loteria", "ti-lock", "mc-icon-indigo", null, false)
        };

        return View(modulos);
    }

    [AllowAnonymous]
    [Route("home/error")]
    public IActionResult Error()
        => View(new ErrorViewModel("Ocurrio un error inesperado.", Activity.Current?.Id ?? HttpContext.TraceIdentifier));
}
