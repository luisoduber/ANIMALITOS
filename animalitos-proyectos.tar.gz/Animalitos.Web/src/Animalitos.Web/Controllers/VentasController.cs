using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Infrastructure.Printing;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

public sealed record OperacionTicketRequest(string Numero, string Serial);

/// <summary>
/// Pantalla de venta (antes frm_ventas + frmTrip). La pagina carga los datos con /ventas/estado y
/// el JS mantiene el reloj interno sincronizado con el servidor para retirar los sorteos y las
/// jugadas cuando llega su hora. Toda operacion pasa por la API, que vuelve a validar el cierre.
/// </summary>
[Route("ventas")]
public sealed class VentasController(AnimalitosApiClient api, TicketRenderer renderer) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();

    /// <summary>Datos iniciales de la pantalla (equivale a work_inicia_frm del WinForms).</summary>
    [HttpGet("estado")]
    public async Task<IActionResult> Estado(CancellationToken ct)
    {
        var perfilTask = api.PerfilAsync(ct);
        var horaTask = api.HoraAsync(ct);
        var parametrosTask = api.ParametrosAsync(ct);
        var loteriasTask = api.LoteriasAsync(ct);
        var sorteosTask = api.SorteosVentaAsync(null, ct);
        var productosTask = api.ProductosAsync(ct);
        var totalesTask = api.TotalesDiaAsync(ct);
        var tripletasTask = api.LoteriasTripletaAsync(ct);

        await Task.WhenAll(perfilTask, horaTask, parametrosTask, loteriasTask, sorteosTask, productosTask, totalesTask, tripletasTask);

        return Json(new
        {
            usuario = perfilTask.Result,
            hora = horaTask.Result,
            parametros = parametrosTask.Result,
            loterias = loteriasTask.Result,
            sorteos = sorteosTask.Result,
            productos = productosTask.Result,
            totales = totalesTask.Result,
            loteriasTripleta = tripletasTask.Result
        });
    }

    /// <summary>
    /// Verificacion periodica (cada minuto): estado de la taquilla y hora del servidor para
    /// resincronizar el reloj interno. Si la taquilla fue inactivada la API responde 403 y el
    /// filtro de errores cierra la sesion.
    /// </summary>
    [HttpGet("control")]
    public async Task<IActionResult> Control(CancellationToken ct)
    {
        var estadoTask = api.EstadoTaquillaAsync(ct);
        var horaTask = api.HoraAsync(ct);
        await Task.WhenAll(estadoTask, horaTask);
        return Json(new { estado = estadoTask.Result, hora = horaTask.Result });
    }

    [HttpGet("sorteos")]
    public async Task<IActionResult> Sorteos(int? idLoteria, CancellationToken ct)
        => Json(await api.SorteosVentaAsync(idLoteria, ct));

    [HttpGet("totales")]
    public async Task<IActionResult> Totales(CancellationToken ct)
        => Json(await api.TotalesDiaAsync(ct));

    [HttpPost("vender")]
    public async Task<IActionResult> Vender([FromBody] VentaAnimalitosRequest request, CancellationToken ct)
    {
        var resultado = await api.VenderAnimalitosAsync(request, ct);
        var impresion = resultado.Ticket is null ? null : renderer.Ticket(resultado.Ticket, User.Impresora());
        return Json(new { resultado, impresion });
    }

    [HttpPost("vender-tripletas")]
    public async Task<IActionResult> VenderTripletas([FromBody] VentaTripletasRequest request, CancellationToken ct)
    {
        var resultado = await api.VenderTripletasAsync(request, ct);
        var impresion = resultado.Ticket is null ? null : renderer.Ticket(resultado.Ticket, User.Impresora());
        return Json(new { resultado, impresion });
    }

    [HttpPost("repetir")]
    public async Task<IActionResult> Repetir([FromBody] RepetirTicketRequest request, CancellationToken ct)
        => Json(await api.RepetirAsync(request, ct));

    [HttpPost("reimprimir")]
    public async Task<IActionResult> Reimprimir(CancellationToken ct)
    {
        var ticket = await api.ReimprimirAsync(ct);
        return Json(new { ticket, impresion = renderer.Ticket(ticket, User.Impresora()) });
    }

    [HttpPost("pagar")]
    public async Task<IActionResult> Pagar([FromBody] OperacionTicketRequest request, CancellationToken ct)
        => Json(await api.PagarAsync(request.Numero, request.Serial, ct));

    [HttpPost("anular")]
    public async Task<IActionResult> Anular([FromBody] OperacionTicketRequest request, CancellationToken ct)
        => Json(await api.AnularAsync(request.Numero, request.Serial, ct));

    [HttpGet("ticket")]
    public async Task<IActionResult> Ticket(string numero, string serial, CancellationToken ct)
        => Json(await api.TicketAsync(numero, serial, ct));

    [HttpGet("resultados")]
    public async Task<IActionResult> Resultados(int? idLoteria, DateOnly? fecha, CancellationToken ct)
        => Json(await api.ResultadosAsync(idLoteria, fecha, ct));
}
