using System.Text;
using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Infrastructure.Printing;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

/// <summary>
/// Configuracion de impresora (antes frm_config_impresora) y firma de solicitudes para QZ Tray.
/// La lista de impresoras instaladas la obtiene el navegador desde QZ Tray.
/// </summary>
[Route("impresora")]
public sealed class ImpresoraController(AnimalitosApiClient api, TicketRenderer renderer, QzSigningService qz) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();

    [HttpGet("configuracion")]
    public async Task<IActionResult> Configuracion(CancellationToken ct)
    {
        var configTask = api.ImpresoraAsync(ct);
        var anchosTask = api.AnchosTicketAsync(ct);
        var letrasTask = api.TamanosLetraAsync(ct);
        await Task.WhenAll(configTask, anchosTask, letrasTask);

        return Json(new
        {
            configuracion = configTask.Result,
            anchos = anchosTask.Result,
            letras = letrasTask.Result,
            firmaHabilitada = qz.Habilitado
        });
    }

    [HttpPost("guardar")]
    public async Task<IActionResult> Guardar([FromBody] ConfiguracionImpresoraRequest request, CancellationToken ct)
    {
        await api.GuardarImpresoraAsync(request, ct);

        // Se actualiza la sesion para que los siguientes tickets usen la nueva configuracion.
        var principal = SesionClaims.ConImpresora(User, request.NombreImpresora, request.AnchoTicket, request.TamanoLetra);
        var auth = await HttpContext.AuthenticateAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, auth.Properties);

        var hora = await api.HoraAsync(ct);
        var prueba = renderer.Prueba(
            new ConfigImpresoraDto(request.NombreImpresora, request.AnchoTicket, request.TamanoLetra),
            User.Nick(), hora.FechaHoraServidor);

        return Json(new { mensaje = "Configuracion guardada.", impresion = prueba });
    }

    /// <summary>Certificado publico para QZ Tray (vacio si no se configuro la firma).</summary>
    [HttpGet("qz/certificado")]
    public IActionResult Certificado() => Content(qz.Certificado ?? string.Empty, "text/plain", Encoding.UTF8);

    /// <summary>Firma SHA512 del mensaje que QZ Tray solicita antes de imprimir.</summary>
    [HttpPost("qz/firmar")]
    public async Task<IActionResult> Firmar()
    {
        using var reader = new StreamReader(Request.Body, Encoding.UTF8);
        var mensaje = await reader.ReadToEndAsync();
        if (string.IsNullOrEmpty(mensaje) || mensaje.Length > 10_000)
        {
            return BadRequest();
        }

        var firma = qz.Firmar(mensaje);
        return firma is null ? NoContent() : Content(firma, "text/plain", Encoding.UTF8);
    }
}
