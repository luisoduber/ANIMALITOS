using System.Globalization;
using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Infrastructure.Printing;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

public sealed record ImprimirCuadreRequest(DateOnly? Desde, DateOnly? Hasta, int? IdEstado, string? Estado);

/// <summary>Movimientos de tickets de la taquilla (antes frm_verf_status_ticket).</summary>
[Route("tickets")]
public sealed class TicketsController(AnimalitosApiClient api, TicketRenderer renderer) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();

    [HttpGet("estados")]
    public async Task<IActionResult> Estados(CancellationToken ct)
        => Json(await api.CatalogoAsync("estados-ticket", ct));

    [HttpGet("datos")]
    public async Task<IActionResult> Datos(DateOnly? desde, DateOnly? hasta, int? idEstado, CancellationToken ct)
        => Json(await api.MovimientosAsync(desde, hasta, idEstado, ct));

    [HttpGet("ticket")]
    public async Task<IActionResult> Ticket(string numero, string serial, CancellationToken ct)
        => Json(await api.TicketAsync(numero, serial, ct));

    [HttpPost("imprimir-cuadre")]
    public async Task<IActionResult> ImprimirCuadre([FromBody] ImprimirCuadreRequest request, CancellationToken ct)
    {
        var movimientos = await api.MovimientosAsync(request.Desde, request.Hasta, request.IdEstado, ct);
        var hora = await api.HoraAsync(ct);
        var desde = (request.Desde ?? DateOnly.FromDateTime(hora.FechaHoraServidor)).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
        var hasta = (request.Hasta ?? DateOnly.FromDateTime(hora.FechaHoraServidor)).ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);

        var documento = renderer.Cuadre(
            User.Impresora(), User.Nick(), User.Divisa(), desde, hasta,
            string.IsNullOrWhiteSpace(request.Estado) ? "TODOS" : request.Estado, movimientos.Totales, hora.FechaHoraServidor);

        return Json(new { impresion = documento });
    }
}

/// <summary>Cuadre y ventas de la taquilla (antes frm_totales_venta_taq y frmVentLot).</summary>
[Route("reportes")]
public sealed class ReportesController(AnimalitosApiClient api) : Controller
{
    [HttpGet("cuadre")]
    public IActionResult Cuadre() => View();

    [HttpGet("cuadre/datos")]
    public async Task<IActionResult> CuadreDatos(DateOnly? desde, DateOnly? hasta, CancellationToken ct)
        => Json(await api.TotalesTaquillaAsync(desde, hasta, ct));

    [HttpGet("ventas")]
    public IActionResult Ventas() => View();

    [HttpGet("ventas/loterias")]
    public async Task<IActionResult> VentasLoterias(CancellationToken ct)
        => Json(await api.LoteriasVentasAsync(ct));

    [HttpGet("ventas/datos")]
    public async Task<IActionResult> VentasDatos(string? modo, int? idLoteria, DateOnly? desde, DateOnly? hasta, CancellationToken ct)
        => Json(await api.ResumenVentasAsync(string.IsNullOrEmpty(modo) ? "taquilla" : modo, idLoteria, desde, hasta, ct));
}

/// <summary>Consulta de resultados (antes frm_result_lot).</summary>
[Route("resultados")]
public sealed class ResultadosController(AnimalitosApiClient api) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();

    [HttpGet("loterias")]
    public async Task<IActionResult> Loterias(CancellationToken ct)
        => Json(await api.LoteriasResultadosAsync(ct));

    [HttpGet("datos")]
    public async Task<IActionResult> Datos(int? idLoteria, DateOnly? fecha, CancellationToken ct)
        => Json(await api.ResultadosAsync(idLoteria, fecha, ct));
}
