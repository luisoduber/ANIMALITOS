using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

/// <summary>
/// Inicio y cierre de sesion, cambio de clave. En la version web no se verifica la MAC del
/// equipo. "Recordar" solo guarda el nombre de usuario (el WinForms guardaba tambien la clave).
/// </summary>
[Route("cuenta")]
public sealed class CuentaController(AnimalitosApiClient api, ILogger<CuentaController> logger) : Controller
{
    private const string CookieUsuario = "animalitos.usuario";

    [AllowAnonymous]
    [HttpGet("login")]
    public IActionResult Login(string? returnUrl = null, string? mensaje = null)
    {
        if (User.Identity?.IsAuthenticated == true)
        {
            return RedirigirInicio(returnUrl);
        }

        var recordado = Request.Cookies[CookieUsuario];
        return View(new LoginViewModel
        {
            Usuario = recordado ?? string.Empty,
            RecordarUsuario = !string.IsNullOrEmpty(recordado),
            ReturnUrl = returnUrl,
            Mensaje = mensaje
        });
    }

    [AllowAnonymous]
    [HttpPost("login")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        LoginResponse login;
        try
        {
            login = await api.LoginAsync(new LoginRequest(model.Usuario.Trim(), model.Clave), ct);
        }
        catch (ApiException ex)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            model.Clave = string.Empty;
            return View(model);
        }

        var principal = SesionClaims.CrearPrincipal(login);
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            principal,
            new AuthenticationProperties
            {
                IsPersistent = false,
                ExpiresUtc = login.ExpiraEn,
                AllowRefresh = false
            });

        if (model.RecordarUsuario)
        {
            Response.Cookies.Append(CookieUsuario, login.Usuario.Nick, new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict,
                Expires = DateTimeOffset.UtcNow.AddDays(90)
            });
        }
        else
        {
            Response.Cookies.Delete(CookieUsuario);
        }

        logger.LogInformation("Sesion web iniciada por {Usuario}", login.Usuario.Nick);

        // Igual que el sistema original: la taquilla entra directo a la pantalla de venta.
        return login.Usuario.IdPerfil == Perfiles.Taquilla
            ? RedirectToAction("Index", "Ventas")
            : RedirigirInicio(model.ReturnUrl);
    }

    [HttpPost("salir")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Salir()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [HttpGet("cambiar-clave")]
    public IActionResult CambiarClave() => View(new CambiarClaveViewModel());

    [HttpPost("cambiar-clave")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CambiarClave(CambiarClaveViewModel model, CancellationToken ct)
    {
        if (!ModelState.IsValid)
        {
            return View(model);
        }

        try
        {
            await api.CambiarClaveAsync(new CambiarClaveRequest(model.ClaveActual, model.ClaveNueva, model.ConfirmarClave), ct);
        }
        catch (ApiException ex) when (!ex.EsNoAutorizado && !ex.EsUsuarioInactivo)
        {
            ModelState.AddModelError(string.Empty, ex.Message);
            return View(new CambiarClaveViewModel());
        }

        TempData["Exito"] = "Su clave fue cambiada exitosamente.";
        return RedirectToAction(nameof(CambiarClave));
    }

    [AllowAnonymous]
    [HttpGet("acceso-denegado")]
    public IActionResult AccesoDenegado() => View();

    private IActionResult RedirigirInicio(string? returnUrl)
        => !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction("Index", "Home");
}
