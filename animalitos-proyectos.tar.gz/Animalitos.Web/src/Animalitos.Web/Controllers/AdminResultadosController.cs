using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Animalitos.Web.Controllers;

/// <summary>
/// Procesamiento de resultados (antes frm_proc_result_loteria). El modo automatico se ejecuta
/// en la API; esta pantalla lo dispara y, si se deja abierta en "automatico", lo repite con el
/// intervalo aleatorio configurado en la BD (spTmpProcRs), igual que el timer del WinForms.
/// </summary>
[Route("admin/resultados")]
[Authorize(Policy = Perfiles.PoliticaAdmin)]
public sealed class AdminResultadosController(AnimalitosApiClient api) : Controller
{
    [HttpGet("")]
    public IActionResult Index() => View();

    [HttpGet("datos")]
    public async Task<IActionResult> Datos(CancellationToken ct)
    {
        var loteriasTask = api.LoteriasGrupoAsync(User.IdGrupo(), ct);
        var tiposTask = api.CatalogoAsync("tipos-ticket", ct);
        var intervaloTask = api.IntervaloProcesoAsync(ct);
        var sorteosTask = api.SorteosProcesoAsync(null, ct);
        await Task.WhenAll(loteriasTask, tiposTask, intervaloTask, sorteosTask);

        return Json(new
        {
            loterias = loteriasTask.Result,
            tiposTicket = tiposTask.Result,
            intervalo = intervaloTask.Result,
            sorteos = sorteosTask.Result
        });
    }

    [HttpGet("sorteos")]
    public async Task<IActionResult> Sorteos(int? idLoteria, CancellationToken ct)
        => Json(await api.SorteosProcesoAsync(idLoteria, ct));

    [HttpGet("pendientes")]
    public async Task<IActionResult> Pendientes(int? idTipoTicket, CancellationToken ct)
        => Json(await api.JugadasPendientesAsync(idTipoTicket, ct));

    [HttpPost("automatico")]
    public async Task<IActionResult> Automatico(CancellationToken ct)
        => Json(await api.ProcesarResultadosAutomaticoAsync(ct));

    [HttpPost("manual")]
    public async Task<IActionResult> Manual([FromBody] ProcesoManualRequest request, CancellationToken ct)
        => Json(await api.ProcesarResultadoManualAsync(request, ct));
}
