using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Infrastructure.Auth;
using Animalitos.Web.Infrastructure.Printing;
using Animalitos.Web.Infrastructure.Web;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.Http.Resilience;
using Microsoft.Extensions.Options;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ------------------------------------------------------------------ Logging
builder.Services.AddSerilog((services, logger) => logger
    .ReadFrom.Configuration(builder.Configuration)
    .ReadFrom.Services(services)
    .Enrich.FromLogContext());

// ------------------------------------------------------------------ Opciones
builder.Services.AddOptions<ApiOptions>()
    .Bind(builder.Configuration.GetSection(ApiOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.Configure<ImpresionOptions>(builder.Configuration.GetSection(ImpresionOptions.SectionName));
builder.Services.Configure<QzOptions>(builder.Configuration.GetSection(QzOptions.SectionName));

// ------------------------------------------------------------------ Cliente de la API (patron BFF)
builder.Services.AddHttpContextAccessor();
builder.Services.AddTransient<ApiAuthHandler>();
builder.Services
    .AddHttpClient<AnimalitosApiClient>((sp, client) =>
    {
        var o = sp.GetRequiredService<IOptions<ApiOptions>>().Value;
        client.BaseAddress = new Uri(o.BaseUrl.EndsWith('/') ? o.BaseUrl : o.BaseUrl + "/");
        client.Timeout = Timeout.InfiniteTimeSpan; // Los tiempos los controla el handler de resiliencia.
    })
    .AddHttpMessageHandler<ApiAuthHandler>()
    .AddStandardResilienceHandler(options =>
    {
        var timeout = TimeSpan.FromSeconds(builder.Configuration.GetValue($"{ApiOptions.SectionName}:TimeoutSegundos", 90));

        // Nunca se reintenta un POST/PUT: reintentar una venta podria duplicar el ticket.
        options.Retry.DisableForUnsafeHttpMethods();
        options.Retry.MaxRetryAttempts = 2;
        options.AttemptTimeout.Timeout = timeout;
        options.TotalRequestTimeout.Timeout = timeout * 2 + TimeSpan.FromSeconds(10);
        options.CircuitBreaker.SamplingDuration = timeout * 2 + TimeSpan.FromSeconds(5);
    });

// ------------------------------------------------------------------ Autenticacion por cookie
builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/cuenta/login";
        options.LogoutPath = "/cuenta/salir";
        options.AccessDeniedPath = "/cuenta/acceso-denegado";
        options.Cookie.Name = "animalitos.sesion";
        options.Cookie.HttpOnly = true;
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.Strict;
        options.SlidingExpiration = false;
        options.ExpireTimeSpan = TimeSpan.FromHours(12);
        options.Events.OnRedirectToLogin = context =>
        {
            if (context.Request.EsAjax())
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                return context.Response.WriteAsJsonAsync(new { mensaje = "Su sesion expiro.", redirigir = "/cuenta/login" });
            }

            context.Response.Redirect(context.RedirectUri);
            return Task.CompletedTask;
        };
        options.Events.OnRedirectToAccessDenied = context =>
        {
            if (context.Request.EsAjax())
            {
                context.Response.StatusCode = StatusCodes.Status403Forbidden;
                return context.Response.WriteAsJsonAsync(new { mensaje = "No tiene permisos para esta operacion." });
            }

            context.Response.Redirect(context.RedirectUri);
            return Task.CompletedTask;
        };
    });

builder.Services.AddAuthorizationBuilder()
    .AddPolicy(Perfiles.PoliticaAdmin, policy => policy.RequireRole(Perfiles.RolAdminGrupo, Perfiles.RolSuperAdmin));

builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "RequestVerificationToken";
    options.Cookie.Name = "animalitos.af";
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Strict;
});

builder.Services.AddControllersWithViews(options =>
{
    options.Filters.Add(new AuthorizeFilter());                    // Todo requiere sesion salvo [AllowAnonymous].
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute()); // CSRF en POST/PUT/DELETE.
    options.Filters.Add<ApiExceptionFilter>();
});

builder.Services.AddSingleton<TicketRenderer>();
builder.Services.AddSingleton<QzSigningService>();
builder.Services.AddHealthChecks();

var app = builder.Build();

// ------------------------------------------------------------------ Pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/home/error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseSerilogRequestLogging();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();
app.MapHealthChecks("/health");
app.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();

app.Run();
