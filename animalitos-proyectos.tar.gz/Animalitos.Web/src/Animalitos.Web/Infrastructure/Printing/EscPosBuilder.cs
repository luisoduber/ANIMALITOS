using System.Globalization;
using System.Text;

namespace Animalitos.Web.Infrastructure.Printing;

public enum Alineacion : byte
{
    Izquierda = 0,
    Centro = 1,
    Derecha = 2
}

/// <summary>
/// Constructor de comandos ESC/POS (estandar de impresoras termicas Epson, Bixolon, Xprinter,
/// 3nStar, etc.). Los bytes resultantes se envian en crudo a la impresora con QZ Tray, igual
/// que hacia RawPrinterHelper (winspool) en el sistema WinForms.
/// </summary>
public sealed class EscPosBuilder
{
    private const byte Esc = 0x1B;
    private const byte Gs = 0x1D;
    private const byte Lf = 0x0A;

    private readonly MemoryStream _buffer = new();

    public EscPosBuilder Inicializar() => Raw(Esc, (byte)'@');

    /// <summary>Fuente A (12x24, normal) o B (9x17, mas columnas).</summary>
    public EscPosBuilder FuenteB(bool activa) => Raw(Esc, (byte)'M', (byte)(activa ? 1 : 0));

    public EscPosBuilder Alinear(Alineacion alineacion) => Raw(Esc, (byte)'a', (byte)alineacion);

    public EscPosBuilder Negrita(bool activa) => Raw(Esc, (byte)'E', (byte)(activa ? 1 : 0));

    /// <summary>GS ! n: doble alto (bit 0) y/o doble ancho (bit 4).</summary>
    public EscPosBuilder Tamano(bool dobleAlto, bool dobleAncho)
        => Raw(Gs, (byte)'!', (byte)((dobleAncho ? 0x10 : 0x00) | (dobleAlto ? 0x01 : 0x00)));

    public EscPosBuilder Texto(string texto)
    {
        var bytes = Encoding.ASCII.GetBytes(TextoTicket.AAscii(texto));
        _buffer.Write(bytes, 0, bytes.Length);
        return this;
    }

    public EscPosBuilder Linea(string texto = "") => Texto(texto).Raw(Lf);

    /// <summary>ESC d n: avanza n lineas.</summary>
    public EscPosBuilder Avanzar(int lineas) => Raw(Esc, (byte)'d', (byte)Math.Clamp(lineas, 0, 255));

    /// <summary>GS V 66 0: avanza y hace corte parcial.</summary>
    public EscPosBuilder Cortar() => Raw(Gs, (byte)'V', 66, 0);

    /// <summary>ESC p 0: pulso para abrir la gaveta de dinero.</summary>
    public EscPosBuilder AbrirGaveta() => Raw(Esc, (byte)'p', 0, 25, 250);

    public byte[] ToArray() => _buffer.ToArray();

    private EscPosBuilder Raw(params byte[] bytes)
    {
        _buffer.Write(bytes, 0, bytes.Length);
        return this;
    }
}

/// <summary>Utilidades de texto para tickets de ancho fijo.</summary>
public static class TextoTicket
{
    private static readonly NumberFormatInfo FormatoMonto = new()
    {
        NumberDecimalSeparator = ",",
        NumberGroupSeparator = ".",
        NumberDecimalDigits = 2
    };

    public static string Monto(decimal monto) => monto.ToString("N2", FormatoMonto);

    /// <summary>
    /// Convierte a ASCII (quita acentos, n con tilde => n) para que el ticket se vea igual en
    /// cualquier modelo de impresora termica sin configurar paginas de codigos.
    /// </summary>
    public static string AAscii(string? texto)
    {
        if (string.IsNullOrEmpty(texto))
        {
            return string.Empty;
        }

        var normalizado = texto.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(normalizado.Length);
        foreach (var c in normalizado)
        {
            var categoria = CharUnicodeInfo.GetUnicodeCategory(c);
            if (categoria == UnicodeCategory.NonSpacingMark)
            {
                continue;
            }

            sb.Append(c is >= ' ' and <= '~' ? c : c switch
            {
                '\u00A0' => ' ',
                '¿' => '?',
                '¡' => '!',
                _ => '?'
            });
        }

        return sb.ToString();
    }

    public static string Centrar(string texto, int ancho)
    {
        texto = Recortar(texto, ancho);
        var izquierda = (ancho - texto.Length) / 2;
        return new string(' ', Math.Max(0, izquierda)) + texto;
    }

    public static string Extremos(string izquierda, string derecha, int ancho)
    {
        var espacio = ancho - izquierda.Length - derecha.Length;
        if (espacio < 1)
        {
            return Recortar(izquierda, Math.Max(0, ancho - derecha.Length - 1)) + " " + derecha;
        }

        return izquierda + new string(' ', espacio) + derecha;
    }

    public static string Recortar(string texto, int ancho) => texto.Length <= ancho ? texto : texto[..ancho];

    /// <summary>Divide un texto largo en lineas del ancho indicado respetando palabras.</summary>
    public static IEnumerable<string> Envolver(string? texto, int ancho)
    {
        if (string.IsNullOrWhiteSpace(texto))
        {
            yield break;
        }

        var linea = new StringBuilder();
        foreach (var palabra in texto.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            var p = palabra;
            while (p.Length > ancho)
            {
                if (linea.Length > 0)
                {
                    yield return linea.ToString();
                    linea.Clear();
                }

                yield return p[..ancho];
                p = p[ancho..];
            }

            if (linea.Length > 0 && linea.Length + 1 + p.Length > ancho)
            {
                yield return linea.ToString();
                linea.Clear();
            }

            if (linea.Length > 0)
            {
                linea.Append(' ');
            }

            linea.Append(p);
        }

        if (linea.Length > 0)
        {
            yield return linea.ToString();
        }
    }
}
