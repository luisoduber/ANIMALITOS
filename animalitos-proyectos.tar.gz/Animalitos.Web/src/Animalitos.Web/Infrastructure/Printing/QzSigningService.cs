using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;

namespace Animalitos.Web.Infrastructure.Printing;

public sealed class QzOptions
{
    public const string SectionName = "QzTray";

    /// <summary>Ruta del certificado publico (PEM) que se entrega a QZ Tray.</summary>
    public string? CertificadoPath { get; set; }

    /// <summary>Ruta de la clave privada (PEM, PKCS#8) con la que se firman las solicitudes.</summary>
    public string? ClavePrivadaPath { get; set; }
}

/// <summary>
/// Firma de mensajes para QZ Tray (impresion silenciosa). QZ Tray exige que cada solicitud venga
/// firmada con SHA512 por el certificado del sitio; la clave privada vive solo en el servidor.
/// Sin certificado configurado, QZ Tray funciona igual pero pide confirmacion al usuario.
/// </summary>
public sealed class QzSigningService(IOptions<QzOptions> options, IWebHostEnvironment env, ILogger<QzSigningService> logger)
{
    private readonly Lazy<string?> _certificado = new(() => Leer(options.Value.CertificadoPath, env, logger));
    private readonly Lazy<string?> _clavePrivada = new(() => Leer(options.Value.ClavePrivadaPath, env, logger));

    public bool Habilitado => !string.IsNullOrEmpty(_certificado.Value) && !string.IsNullOrEmpty(_clavePrivada.Value);

    public string? Certificado => _certificado.Value;

    public string? Firmar(string mensaje)
    {
        if (!Habilitado)
        {
            return null;
        }

        using var rsa = RSA.Create();
        rsa.ImportFromPem(_clavePrivada.Value);
        var firma = rsa.SignData(Encoding.UTF8.GetBytes(mensaje), HashAlgorithmName.SHA512, RSASignaturePadding.Pkcs1);
        return Convert.ToBase64String(firma);
    }

    private static string? Leer(string? ruta, IWebHostEnvironment env, ILogger logger)
    {
        if (string.IsNullOrWhiteSpace(ruta))
        {
            return null;
        }

        var completa = Path.IsPathRooted(ruta) ? ruta : Path.Combine(env.ContentRootPath, ruta);
        if (!File.Exists(completa))
        {
            logger.LogWarning("No se encontro el archivo de QZ Tray {Ruta}; la impresion pedira confirmacion.", completa);
            return null;
        }

        return File.ReadAllText(completa);
    }
}
