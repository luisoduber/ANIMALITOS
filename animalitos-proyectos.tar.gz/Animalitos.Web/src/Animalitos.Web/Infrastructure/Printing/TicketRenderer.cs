using System.Text.RegularExpressions;
using Animalitos.Web.Infrastructure.Api;
using Microsoft.Extensions.Options;

namespace Animalitos.Web.Infrastructure.Printing;

public sealed class ImpresionOptions
{
    public const string SectionName = "Impresion";

    /// <summary>Lineas opcionales al inicio del ticket (nombre de la agencia, RIF, etc.).</summary>
    public string[] Encabezado { get; set; } = [];

    /// <summary>Lineas opcionales al final del ticket.</summary>
    public string[] PieDePagina { get; set; } = [];

    public int LineasAvanceFinal { get; set; } = 4;

    public bool CortarPapel { get; set; } = true;

    public bool AbrirGaveta { get; set; }

    /// <summary>0 = automatico segun ancho de ticket y tamano de letra del usuario.</summary>
    public int ColumnasForzadas { get; set; }
}

/// <summary>Linea de ticket con formato (se usa tanto para ESC/POS como para la vista HTML).</summary>
public sealed record LineaTicket(string T, string A = "i", bool N = false, bool G = false);

/// <summary>Documento listo para imprimir: ESC/POS en base64 + lineas para la impresion del navegador.</summary>
public sealed record DocumentoImpresion(string Impresora, int Columnas, bool Angosto, string EscPosBase64, IReadOnlyList<LineaTicket> Lineas);

/// <summary>
/// Arma el ticket con el mismo contenido del sistema original (frm_rpt_ticket_venta y
/// frmTckTrip): cabecera, jugadas agrupadas por sorteo (2 por linea), total y caducidad.
/// </summary>
public sealed partial class TicketRenderer(IOptions<ImpresionOptions> options)
{
    public DocumentoImpresion Ticket(TicketImpresionDto t, ConfigImpresoraDto impresora)
    {
        var (columnas, fuenteB, angosto) = Columnas(impresora);
        var o = options.Value;
        var lineas = new List<LineaTicket>();
        var separador = new string('=', columnas);

        foreach (var e in o.Encabezado.Where(e => !string.IsNullOrWhiteSpace(e)))
        {
            lineas.Add(new LineaTicket(TextoTicket.Centrar(e, columnas), "c", true));
        }

        lineas.Add(new LineaTicket($"Taquilla:{t.Taquilla}"));
        lineas.Add(new LineaTicket($"Divisa:{t.Divisa}"));
        lineas.Add(new LineaTicket($"Fecha:{t.Fecha}  Hora:{t.Hora}"));
        lineas.Add(new LineaTicket($"Ticket:{t.NumeroTicket}  Serial:{t.Serial}", N: true));
        if (t.Reimpresion)
        {
            lineas.Add(new LineaTicket(TextoTicket.Centrar("*** REIMPRESION ***", columnas), "c", true));
        }

        lineas.Add(new LineaTicket(separador));

        if (string.Equals(t.Tipo, TicketImpresionDto.TipoTripleta, StringComparison.OrdinalIgnoreCase))
        {
            foreach (var trip in t.Tripletas)
            {
                lineas.Add(new LineaTicket($"TRIPLETA: {trip.Loteria}", N: true));
                AgregarEnvuelto(lineas, $"DESDE: {trip.Desde}", columnas);
                AgregarEnvuelto(lineas, $"HASTA: {trip.Hasta}", columnas);
                AgregarEnvuelto(lineas, string.Join(' ', trip.Productos), columnas);
                lineas.Add(new LineaTicket($"MONTO JUGANDO: {TextoTicket.Monto(trip.Monto)} {t.Divisa}"));
                lineas.Add(new LineaTicket(string.Empty));
            }

            lineas.Add(new LineaTicket(separador));
            lineas.Add(new LineaTicket($"Total venta: {TextoTicket.Monto(t.Total)} {t.Divisa}", N: true, G: true));
            lineas.Add(new LineaTicket($"Valido por: {t.SorteosTripleta} sorteos descritos."));
        }
        else
        {
            var celda = columnas / 2;
            foreach (var grupo in t.Grupos)
            {
                var titulo = string.IsNullOrWhiteSpace(grupo.Sorteo) ? grupo.Loteria : $"{grupo.Loteria} {grupo.Sorteo}";
                lineas.Add(new LineaTicket(TextoTicket.Centrar(titulo, columnas), "c", true));

                for (var i = 0; i < grupo.Jugadas.Count; i += 2)
                {
                    var izquierda = Celda(grupo.Jugadas[i], celda);
                    var derecha = i + 1 < grupo.Jugadas.Count ? Celda(grupo.Jugadas[i + 1], celda) : string.Empty;
                    lineas.Add(new LineaTicket((izquierda + derecha).TrimEnd()));
                }
            }

            lineas.Add(new LineaTicket(separador));
            lineas.Add(new LineaTicket($"Total venta: {TextoTicket.Monto(t.Total)} {t.Divisa}", N: true, G: true));
            lineas.Add(new LineaTicket($"REVISE TICKET. CADUCA: {t.DiasCaducidad} DIAS."));
        }

        foreach (var linea in TextoTicket.Envolver(t.Nota, columnas))
        {
            lineas.Add(new LineaTicket(linea));
        }

        foreach (var p in o.PieDePagina.Where(p => !string.IsNullOrWhiteSpace(p)))
        {
            lineas.Add(new LineaTicket(TextoTicket.Centrar(p, columnas), "c"));
        }

        return Documento(impresora, columnas, fuenteB, angosto, lineas);
    }

    /// <summary>Resumen de caja (antes frm_rpt_cuadre_diario).</summary>
    public DocumentoImpresion Cuadre(
        ConfigImpresoraDto impresora, string taquilla, string divisa, string desde, string hasta, string estado,
        TotalesMovimientosDto totales, DateTime generado)
    {
        var (columnas, fuenteB, angosto) = Columnas(impresora);
        var separador = new string('=', columnas);
        var lineas = new List<LineaTicket>
        {
            new(TextoTicket.Centrar("CUADRE DE CAJA", columnas), "c", true, true),
            new($"Taquilla:{taquilla.ToUpperInvariant()}"),
            new($"Divisa:{divisa.ToUpperInvariant()}"),
            new($"Impreso:{generado:dd/MM/yyyy hh:mm tt}"),
            new($"Desde:{desde}  Hasta:{hasta}"),
            new($"Estado:{estado}"),
            new(separador),
            new(TextoTicket.Extremos("Cant. tickets:", totales.CantidadTickets.ToString(System.Globalization.CultureInfo.InvariantCulture), columnas)),
            new(TextoTicket.Extremos("Entradas:", TextoTicket.Monto(totales.Entradas), columnas)),
            new(TextoTicket.Extremos("Salidas:", TextoTicket.Monto(totales.Salidas), columnas)),
            new(separador),
            new(TextoTicket.Extremos("TOTAL CAJA:", TextoTicket.Monto(totales.TotalCaja), columnas), N: true)
        };

        return Documento(impresora, columnas, fuenteB, angosto, lineas);
    }

    /// <summary>Ticket de prueba (antes frm_rpt_imp_prueba).</summary>
    public DocumentoImpresion Prueba(ConfigImpresoraDto impresora, string taquilla, DateTime fecha)
    {
        var (columnas, fuenteB, angosto) = Columnas(impresora);
        var lineas = new List<LineaTicket>
        {
            new(TextoTicket.Centrar("PRUEBA DE IMPRESION", columnas), "c", true, true),
            new($"Taquilla:{taquilla.ToUpperInvariant()}"),
            new($"Impresora:{impresora.Nombre}"),
            new($"Ancho:{impresora.Ancho}  Letra:{impresora.TamanoLetra}  Columnas:{columnas}"),
            new($"Fecha:{fecha:dd/MM/yyyy hh:mm tt}"),
            new(new string('=', columnas)),
            new("0123456789".PadRight(columnas, '-')[..columnas]),
            new(TextoTicket.Extremos("Izquierda", "Derecha", columnas)),
            new(TextoTicket.Centrar("Centro", columnas), "c"),
            new(new string('=', columnas))
        };

        return Documento(impresora, columnas, fuenteB, angosto, lineas);
    }

    private DocumentoImpresion Documento(ConfigImpresoraDto impresora, int columnas, bool fuenteB, bool angosto, List<LineaTicket> lineas)
    {
        var o = options.Value;
        var esc = new EscPosBuilder().Inicializar().FuenteB(fuenteB);

        foreach (var l in lineas)
        {
            esc.Alinear(Alineacion.Izquierda)
               .Negrita(l.N)
               .Tamano(l.G, false)
               .Linea(l.T);
        }

        esc.Negrita(false).Tamano(false, false).Avanzar(o.LineasAvanceFinal);
        if (o.CortarPapel)
        {
            esc.Cortar();
        }

        if (o.AbrirGaveta)
        {
            esc.AbrirGaveta();
        }

        return new DocumentoImpresion(
            impresora.Nombre,
            columnas,
            angosto,
            Convert.ToBase64String(esc.ToArray()),
            lineas.Select(l => l with { T = TextoTicket.AAscii(l.T) }).ToList());
    }

    private static string Celda(TicketJugadaDto j, int ancho)
    {
        var prefijo = $"{j.Codigo,-3}{j.Producto,-4}";
        var monto = TextoTicket.Monto(j.Monto);
        var espacio = Math.Max(1, ancho - prefijo.Length - monto.Length - 1);
        return (prefijo + new string(' ', espacio) + monto + " ").PadRight(ancho);
    }

    private static void AgregarEnvuelto(List<LineaTicket> lineas, string texto, int columnas)
    {
        foreach (var l in TextoTicket.Envolver(texto, columnas))
        {
            lineas.Add(new LineaTicket(l));
        }
    }

    /// <summary>
    /// Columnas segun el ancho del papel y el tamano de letra configurados por el usuario:
    /// 58 mm => 32 (fuente A) / 42 (fuente B); 80 mm => 48 / 64.
    /// </summary>
    private (int Columnas, bool FuenteB, bool Angosto) Columnas(ConfigImpresoraDto impresora)
    {
        var m = Digitos().Match(impresora.Ancho ?? string.Empty);
        var mm = m.Success && int.TryParse(m.Value, out var v) ? v : 58;
        var angosto = mm < 70;
        var fuenteB = int.TryParse(impresora.TamanoLetra, out var letra) && letra is > 0 and <= 7;

        var forzadas = options.Value.ColumnasForzadas;
        if (forzadas > 0)
        {
            return (forzadas, fuenteB, angosto);
        }

        var columnas = angosto ? (fuenteB ? 42 : 32) : (fuenteB ? 64 : 48);
        return (columnas, fuenteB, angosto);
    }

    [GeneratedRegex(@"\d+")]
    private static partial Regex Digitos();
}
