using System.Globalization;
using System.Security.Claims;
using Animalitos.Web.Infrastructure.Api;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace Animalitos.Web.Infrastructure.Auth;

public static class Perfiles
{
    public const int Taquilla = 1;
    public const int AdminGrupo = 2;
    public const int SuperAdmin = 3;

    public const string RolTaquilla = "Taquilla";
    public const string RolAdminGrupo = "AdminGrupo";
    public const string RolSuperAdmin = "SuperAdmin";

    public const string PoliticaAdmin = "Admin";
}

/// <summary>Claims de la cookie de sesion del Web.</summary>
public static class SesionClaims
{
    public const string ApiToken = "api_token";
    public const string ApiTokenExpira = "api_token_exp";
    public const string Perfil = "perfil";
    public const string NombrePerfil = "perfil_nombre";
    public const string Grupo = "grupo";
    public const string Divisa = "divisa";
    public const string Impresora = "imp_nombre";
    public const string AnchoTicket = "imp_ancho";
    public const string TamanoLetra = "imp_letra";

    public static ClaimsPrincipal CrearPrincipal(LoginResponse login)
        => CrearPrincipal(login.AccessToken, login.ExpiraEn, login.Usuario);

    public static ClaimsPrincipal CrearPrincipal(string token, DateTimeOffset expira, UsuarioDto u)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, u.IdUsuario.ToString(CultureInfo.InvariantCulture)),
            new(ClaimTypes.Name, u.Nick),
            new(ClaimTypes.Role, u.Rol),
            new(Perfil, u.IdPerfil.ToString(CultureInfo.InvariantCulture)),
            new(NombrePerfil, u.NombrePerfil),
            new(Grupo, u.IdGrupo.ToString(CultureInfo.InvariantCulture)),
            new(Divisa, u.Divisa),
            new(Impresora, u.Impresora.Nombre),
            new(AnchoTicket, u.Impresora.Ancho),
            new(TamanoLetra, u.Impresora.TamanoLetra),
            new(ApiToken, token),
            new(ApiTokenExpira, expira.ToUnixTimeSeconds().ToString(CultureInfo.InvariantCulture))
        };

        return new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
    }

    /// <summary>Copia la sesion actual reemplazando la configuracion de impresora.</summary>
    public static ClaimsPrincipal ConImpresora(ClaimsPrincipal actual, string nombre, string ancho, string letra)
    {
        var claims = actual.Claims
            .Where(c => c.Type is not (Impresora or AnchoTicket or TamanoLetra))
            .Select(c => new Claim(c.Type, c.Value))
            .ToList();
        claims.Add(new Claim(Impresora, nombre));
        claims.Add(new Claim(AnchoTicket, ancho));
        claims.Add(new Claim(TamanoLetra, letra));
        return new ClaimsPrincipal(new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme));
    }
}

public static class ClaimsPrincipalExtensions
{
    public static string? ApiToken(this ClaimsPrincipal user) => user.FindFirst(SesionClaims.ApiToken)?.Value;

    public static int IdUsuario(this ClaimsPrincipal user) => LeerEntero(user, ClaimTypes.NameIdentifier);

    public static int IdPerfil(this ClaimsPrincipal user) => LeerEntero(user, SesionClaims.Perfil);

    public static int IdGrupo(this ClaimsPrincipal user) => LeerEntero(user, SesionClaims.Grupo);

    public static string Nick(this ClaimsPrincipal user) => user.Identity?.Name ?? string.Empty;

    public static string NombrePerfil(this ClaimsPrincipal user) => user.FindFirst(SesionClaims.NombrePerfil)?.Value ?? string.Empty;

    public static string Divisa(this ClaimsPrincipal user) => user.FindFirst(SesionClaims.Divisa)?.Value ?? string.Empty;

    public static bool EsAdmin(this ClaimsPrincipal user) => user.IdPerfil() is Perfiles.AdminGrupo or Perfiles.SuperAdmin;

    public static bool EsTaquilla(this ClaimsPrincipal user) => user.IdPerfil() == Perfiles.Taquilla;

    public static ConfigImpresoraDto Impresora(this ClaimsPrincipal user) => new(
        user.FindFirst(SesionClaims.Impresora)?.Value ?? string.Empty,
        user.FindFirst(SesionClaims.AnchoTicket)?.Value ?? string.Empty,
        user.FindFirst(SesionClaims.TamanoLetra)?.Value ?? string.Empty);

    private static int LeerEntero(ClaimsPrincipal user, string claim)
        => int.TryParse(user.FindFirst(claim)?.Value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var v) ? v : 0;
}
