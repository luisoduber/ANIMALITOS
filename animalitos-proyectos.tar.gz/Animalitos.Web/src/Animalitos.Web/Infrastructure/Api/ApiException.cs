using System.Net;

namespace Animalitos.Web.Infrastructure.Api;

/// <summary>Error devuelto por la API (se construye a partir del ProblemDetails de la respuesta).</summary>
public sealed class ApiException(HttpStatusCode statusCode, string message, string? code = null) : Exception(message)
{
    public HttpStatusCode StatusCode { get; } = statusCode;

    /// <summary>Codigo corto enviado por la API en ProblemDetails.Extensions["codigo"].</summary>
    public string? Code { get; } = code;

    public bool EsNoAutorizado => StatusCode == HttpStatusCode.Unauthorized;

    public bool EsUsuarioInactivo => Code == "usuario_inactivo";
}
