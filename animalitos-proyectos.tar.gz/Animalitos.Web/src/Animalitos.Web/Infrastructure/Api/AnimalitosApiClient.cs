using System.Globalization;
using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;

namespace Animalitos.Web.Infrastructure.Api;

/// <summary>
/// Cliente tipado de Animalitos.Api. Es el unico punto del proyecto Web que habla con la API
/// (reemplaza a las llamadas directas a MySQL de clsMet y de los formularios).
/// </summary>
public sealed class AnimalitosApiClient(HttpClient http, ILogger<AnimalitosApiClient> logger)
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    // ---------------------------------------------------------------- Autenticacion
    public Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct = default)
        => PostAsync<LoginResponse>("api/auth/login", request, ct);

    public Task<UsuarioDto> PerfilAsync(CancellationToken ct = default)
        => GetAsync<UsuarioDto>("api/auth/me", ct);

    public Task CambiarClaveAsync(CambiarClaveRequest request, CancellationToken ct = default)
        => SendAsync(HttpMethod.Post, "api/auth/cambiar-clave", request, ct);

    // ---------------------------------------------------------------- Sistema
    public Task<HoraServidorDto> HoraAsync(CancellationToken ct = default)
        => GetAsync<HoraServidorDto>("api/sistema/hora", ct);

    public Task<ParametrosGeneralesDto> ParametrosAsync(CancellationToken ct = default)
        => GetAsync<ParametrosGeneralesDto>("api/sistema/parametros", ct);

    public Task<EstadoTaquillaDto> EstadoTaquillaAsync(CancellationToken ct = default)
        => GetAsync<EstadoTaquillaDto>("api/sistema/estado-taquilla", ct);

    // ---------------------------------------------------------------- Catalogo
    public Task<IReadOnlyList<LoteriaDto>> LoteriasAsync(CancellationToken ct = default)
        => GetAsync<IReadOnlyList<LoteriaDto>>("api/catalogo/loterias", ct);

    public Task<IReadOnlyList<LoteriaDto>> LoteriasGrupoAsync(int idGrupo, CancellationToken ct = default)
        => GetAsync<IReadOnlyList<LoteriaDto>>($"api/catalogo/loterias/grupo/{idGrupo}", ct);

    public Task<IReadOnlyList<LoteriaTripletaDto>> LoteriasTripletaAsync(CancellationToken ct = default)
        => GetAsync<IReadOnlyList<LoteriaTripletaDto>>("api/catalogo/loterias/tripletas", ct);

    public Task<IReadOnlyList<LoteriaDto>> LoteriasResultadosAsync(CancellationToken ct = default)
        => GetAsync<IReadOnlyList<LoteriaDto>>("api/catalogo/loterias/resultados", ct);

    public Task<IReadOnlyList<SorteoVentaDto>> SorteosVentaAsync(int? idLoteria, CancellationToken ct = default)
        => GetAsync<IReadOnlyList<SorteoVentaDto>>("api/catalogo/sorteos/venta" + Query(("idLoteria", idLoteria)), ct);

    public Task<IReadOnlyList<ProductoDto>> ProductosAsync(CancellationToken ct = default)
        => GetAsync<IReadOnlyList<ProductoDto>>("api/catalogo/productos", ct);

    public Task<TablaDto> CatalogoAsync(string nombre, CancellationToken ct = default)
        => GetAsync<TablaDto>($"api/catalogo/{Uri.EscapeDataString(nombre)}", ct);

    // ---------------------------------------------------------------- Ventas
    public Task<VentaAnimalitosResultadoDto> VenderAnimalitosAsync(VentaAnimalitosRequest request, CancellationToken ct = default)
        => PostAsync<VentaAnimalitosResultadoDto>("api/ventas/animalitos", request, ct);

    public Task<VentaTripletasResultadoDto> VenderTripletasAsync(VentaTripletasRequest request, CancellationToken ct = default)
        => PostAsync<VentaTripletasResultadoDto>("api/ventas/tripletas", request, ct);

    public Task<TotalesDiaDto> TotalesDiaAsync(CancellationToken ct = default)
        => GetAsync<TotalesDiaDto>("api/ventas/totales-dia", ct);

    public Task<TicketImpresionDto> ReimprimirAsync(CancellationToken ct = default)
        => GetAsync<TicketImpresionDto>("api/ventas/reimprimir", ct);

    public Task<IReadOnlyList<JugadaRepetidaDto>> RepetirAsync(RepetirTicketRequest request, CancellationToken ct = default)
        => PostAsync<IReadOnlyList<JugadaRepetidaDto>>("api/ventas/repetir", request, ct);

    // ---------------------------------------------------------------- Tickets
    public Task<TicketDetalleDto> TicketAsync(string numero, string serial, CancellationToken ct = default)
        => GetAsync<TicketDetalleDto>($"api/tickets/{Uri.EscapeDataString(numero)}" + Query(("serial", serial)), ct);

    public Task<PagoTicketDto> PagarAsync(string numero, string serial, CancellationToken ct = default)
        => PostAsync<PagoTicketDto>($"api/tickets/{Uri.EscapeDataString(numero)}/pagar", new TicketOperacionRequest(serial), ct);

    public Task<AnulacionTicketDto> AnularAsync(string numero, string serial, CancellationToken ct = default)
        => PostAsync<AnulacionTicketDto>($"api/tickets/{Uri.EscapeDataString(numero)}/anular", new TicketOperacionRequest(serial), ct);

    public Task<MovimientosDto> MovimientosAsync(DateOnly? desde, DateOnly? hasta, int? idEstado, CancellationToken ct = default)
        => GetAsync<MovimientosDto>("api/tickets/movimientos" + Query(("desde", desde), ("hasta", hasta), ("idEstado", idEstado)), ct);

    // ---------------------------------------------------------------- Reportes
    public Task<TotalesTaquillaDto> TotalesTaquillaAsync(DateOnly? desde, DateOnly? hasta, CancellationToken ct = default)
        => GetAsync<TotalesTaquillaDto>("api/reportes/totales-taquilla" + Query(("desde", desde), ("hasta", hasta)), ct);

    public Task<ResumenVentasDto> ResumenVentasAsync(string modo, int? idLoteria, DateOnly? desde, DateOnly? hasta, CancellationToken ct = default)
        => GetAsync<ResumenVentasDto>("api/reportes/ventas" + Query(("modo", modo), ("idLoteria", idLoteria), ("desde", desde), ("hasta", hasta)), ct);

    public Task<TablaDto> LoteriasVentasAsync(CancellationToken ct = default)
        => GetAsync<TablaDto>("api/reportes/ventas/loterias", ct);

    // ---------------------------------------------------------------- Resultados
    public Task<TablaDto> ResultadosAsync(int? idLoteria, DateOnly? fecha, CancellationToken ct = default)
        => GetAsync<TablaDto>("api/resultados" + Query(("idLoteria", idLoteria), ("fecha", fecha)), ct);

    public Task<ProcesoResultadosDto> ProcesarResultadosAutomaticoAsync(CancellationToken ct = default)
        => PostAsync<ProcesoResultadosDto>("api/admin/resultados/automatico", new { }, ct);

    public Task<ProcesoResultadosDto> ProcesarResultadoManualAsync(ProcesoManualRequest request, CancellationToken ct = default)
        => PostAsync<ProcesoResultadosDto>("api/admin/resultados/manual", request, ct);

    public Task<IReadOnlyList<SorteoProcesoDto>> SorteosProcesoAsync(int? idLoteria, CancellationToken ct = default)
        => GetAsync<IReadOnlyList<SorteoProcesoDto>>("api/admin/resultados/sorteos" + Query(("idLoteria", idLoteria)), ct);

    public Task<TablaDto> JugadasPendientesAsync(int? idTipoTicket, CancellationToken ct = default)
        => GetAsync<TablaDto>("api/admin/resultados/jugadas-pendientes" + Query(("idTipoTicket", idTipoTicket)), ct);

    public Task<IntervaloProcesoDto> IntervaloProcesoAsync(CancellationToken ct = default)
        => GetAsync<IntervaloProcesoDto>("api/admin/resultados/intervalo", ct);

    // ---------------------------------------------------------------- Impresora
    public Task<ConfiguracionImpresoraDto> ImpresoraAsync(CancellationToken ct = default)
        => GetAsync<ConfiguracionImpresoraDto>("api/impresora", ct);

    public Task GuardarImpresoraAsync(ConfiguracionImpresoraRequest request, CancellationToken ct = default)
        => SendAsync(HttpMethod.Put, "api/impresora", request, ct);

    public Task<TablaDto> AnchosTicketAsync(CancellationToken ct = default)
        => GetAsync<TablaDto>("api/impresora/anchos", ct);

    public Task<TablaDto> TamanosLetraAsync(CancellationToken ct = default)
        => GetAsync<TablaDto>("api/impresora/tamanos-letra", ct);

    // ---------------------------------------------------------------- Infraestructura
    private async Task<T> GetAsync<T>(string url, CancellationToken ct)
    {
        using var response = await http.GetAsync(url, ct);
        return await LeerAsync<T>(response, ct);
    }

    private async Task<T> PostAsync<T>(string url, object body, CancellationToken ct)
    {
        using var response = await http.PostAsJsonAsync(url, body, Json, ct);
        return await LeerAsync<T>(response, ct);
    }

    private async Task SendAsync(HttpMethod method, string url, object body, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(method, url) { Content = JsonContent.Create(body, options: Json) };
        using var response = await http.SendAsync(request, ct);
        if (!response.IsSuccessStatusCode)
        {
            throw await CrearExcepcionAsync(response, ct);
        }
    }

    private async Task<T> LeerAsync<T>(HttpResponseMessage response, CancellationToken ct)
    {
        if (!response.IsSuccessStatusCode)
        {
            throw await CrearExcepcionAsync(response, ct);
        }

        var result = await response.Content.ReadFromJsonAsync<T>(Json, ct);
        return result ?? throw new ApiException(HttpStatusCode.BadGateway, "La API devolvio una respuesta vacia.");
    }

    private async Task<ApiException> CrearExcepcionAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var mensaje = response.StatusCode switch
        {
            HttpStatusCode.Unauthorized => "Su sesion expiro. Inicie sesion nuevamente.",
            HttpStatusCode.Forbidden => "No tiene permisos para realizar esta operacion.",
            HttpStatusCode.TooManyRequests => "Demasiados intentos. Espere un momento e intente de nuevo.",
            _ => "No fue posible completar la operacion."
        };
        string? codigo = null;

        try
        {
            var texto = await response.Content.ReadAsStringAsync(ct);
            if (!string.IsNullOrWhiteSpace(texto) && texto.TrimStart().StartsWith('{'))
            {
                using var doc = JsonDocument.Parse(texto);
                var root = doc.RootElement;
                if (root.TryGetProperty("detail", out var detail) && detail.ValueKind == JsonValueKind.String &&
                    !string.IsNullOrWhiteSpace(detail.GetString()))
                {
                    mensaje = detail.GetString()!;
                }
                else if (root.TryGetProperty("title", out var title) && title.ValueKind == JsonValueKind.String)
                {
                    mensaje = title.GetString() ?? mensaje;
                }

                if (root.TryGetProperty("codigo", out var cod) && cod.ValueKind == JsonValueKind.String)
                {
                    codigo = cod.GetString();
                }
            }
        }
        catch (JsonException)
        {
            // Respuesta no JSON: se usa el mensaje generico.
        }

        if ((int)response.StatusCode >= 500)
        {
            logger.LogError("La API respondio {Status} en {Url}: {Mensaje}",
                (int)response.StatusCode, response.RequestMessage?.RequestUri, mensaje);
        }

        return new ApiException(response.StatusCode, mensaje, codigo);
    }

    private static string Query(params (string Nombre, object? Valor)[] parametros)
    {
        var sb = new StringBuilder();
        foreach (var (nombre, valor) in parametros)
        {
            var texto = valor switch
            {
                null => null,
                DateOnly d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                IFormattable f => f.ToString(null, CultureInfo.InvariantCulture),
                _ => valor.ToString()
            };

            if (string.IsNullOrEmpty(texto))
            {
                continue;
            }

            sb.Append(sb.Length == 0 ? '?' : '&')
              .Append(Uri.EscapeDataString(nombre))
              .Append('=')
              .Append(Uri.EscapeDataString(texto));
        }

        return sb.ToString();
    }
}
