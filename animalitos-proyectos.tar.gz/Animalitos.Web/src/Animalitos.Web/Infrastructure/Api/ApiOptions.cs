using System.ComponentModel.DataAnnotations;

namespace Animalitos.Web.Infrastructure.Api;

public sealed class ApiOptions
{
    public const string SectionName = "Api";

    /// <summary>URL base de Animalitos.Api, ej. https://localhost:7101/</summary>
    [Required, Url]
    public string BaseUrl { get; set; } = "https://localhost:7101/";

    /// <summary>Tiempo maximo de cada intento (segundos). El proceso de resultados puede tardar.</summary>
    [Range(10, 300)]
    public int TimeoutSegundos { get; set; } = 90;
}
