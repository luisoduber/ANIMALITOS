using System.Text.Json;

namespace Animalitos.Web.Infrastructure.Api;

// Contratos de la API Animalitos.Api (copia local: los proyectos son independientes).

// ------------------------------------------------------------------ Autenticacion
public sealed record LoginRequest(string Usuario, string Clave);

public sealed record CambiarClaveRequest(string ClaveActual, string ClaveNueva, string ConfirmarClave);

public sealed record LimitesVentaDto(
    decimal MontoMaxJugada,
    decimal MontoMaxTripleta,
    decimal MontoMaxTicket,
    decimal MontoPorUnidad,
    decimal MontoMultiploJugada,
    decimal MontoMinJugada);

public sealed record ConfigImpresoraDto(string Nombre, string Ancho, string TamanoLetra);

public sealed record UsuarioDto(
    int IdUsuario,
    string Nick,
    int IdPerfil,
    string NombrePerfil,
    string Rol,
    int IdGrupo,
    string Divisa,
    LimitesVentaDto Limites,
    ConfigImpresoraDto Impresora);

public sealed record LoginResponse(string AccessToken, DateTimeOffset ExpiraEn, UsuarioDto Usuario);

// ------------------------------------------------------------------ Sistema
public sealed record ParametrosGeneralesDto(int DiasCaducidadTicket, string NotaTicket, int IdTipoProcesoDatos, int SorteosTripleta);

public sealed record HoraServidorDto(DateTime FechaHoraServidor, DateTime HoraCierre);

public sealed record EstadoTaquillaDto(int IdEstado, bool Activa);

// ------------------------------------------------------------------ Catalogo
public sealed record LoteriaDto(int IdLoteria, string Nombre);

public sealed record LoteriaTripletaDto(int IdLoteria, string Nombre, string Abreviatura, int CodigoMaximo);

public sealed record ProductoDto(int IdLoteria, string Codigo, string Nombre, string Abreviatura);

public sealed record SorteoVentaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreSorteo,
    string HoraSorteo,
    int CodigoMaximo,
    string NombreLoteria,
    string AbreviaturaLoteria);

/// <summary>Tabla generica (columnas + filas) devuelta por los procedimientos sin esquema fijo.</summary>
public sealed record TablaDto(IReadOnlyList<string> Columnas, IReadOnlyList<JsonElement[]> Filas)
{
    public static TablaDto Vacia { get; } = new([], []);
}

// ------------------------------------------------------------------ Ventas
public sealed record JugadaRequest(int IdLoteria, int IdSorteo, string Codigo, decimal Monto);

public sealed record VentaAnimalitosRequest(IReadOnlyList<JugadaRequest> Jugadas);

public sealed record TripletaRequest(int IdLoteria, string Codigo1, string Codigo2, string Codigo3, decimal Monto);

public sealed record VentaTripletasRequest(IReadOnlyList<TripletaRequest> Tripletas);

public sealed record SorteoSeleccionadoRequest(int IdLoteria, int IdSorteo);

public sealed record RepetirTicketRequest(string NumeroTicket, IReadOnlyList<SorteoSeleccionadoRequest> Sorteos);

public sealed record JugadaProcesadaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreLoteria,
    string HoraSorteo,
    string Codigo,
    string Producto,
    decimal MontoSolicitado,
    decimal MontoAceptado,
    string Estado,
    string? Mensaje);

public sealed record TripletaProcesadaDto(
    int IdLoteria,
    string NombreLoteria,
    string Codigo1,
    string Codigo2,
    string Codigo3,
    IReadOnlyList<string> Productos,
    decimal MontoSolicitado,
    decimal MontoAceptado,
    string? SorteoDesde,
    string? SorteoHasta,
    string Estado,
    string? Mensaje);

public sealed record TicketJugadaDto(string Codigo, string Producto, string ProductoNombre, decimal Monto);

public sealed record TicketGrupoDto(int IdLoteria, int IdSorteo, string Loteria, string Sorteo, IReadOnlyList<TicketJugadaDto> Jugadas);

public sealed record TicketTripletaDto(string Loteria, string Desde, string Hasta, IReadOnlyList<string> Productos, decimal Monto);

public sealed record TicketImpresionDto(
    string Tipo,
    string Taquilla,
    string Divisa,
    string NumeroTicket,
    string Serial,
    string Fecha,
    string Hora,
    IReadOnlyList<TicketGrupoDto> Grupos,
    IReadOnlyList<TicketTripletaDto> Tripletas,
    decimal Total,
    int DiasCaducidad,
    int SorteosTripleta,
    string Nota,
    bool Reimpresion)
{
    public const string TipoTripleta = "TRIPLETA";
}

public sealed record VentaAnimalitosResultadoDto(
    bool Procesado,
    TicketImpresionDto? Ticket,
    IReadOnlyList<JugadaProcesadaDto> Jugadas,
    IReadOnlyList<string> Mensajes,
    bool HaySorteosCerrados);

public sealed record VentaTripletasResultadoDto(
    bool Procesado,
    TicketImpresionDto? Ticket,
    IReadOnlyList<TripletaProcesadaDto> Tripletas,
    IReadOnlyList<string> Mensajes);

public sealed record TotalesDiaDto(
    decimal Ventas,
    decimal VentasAnimalitos,
    decimal VentasTripletas,
    decimal Pagados,
    decimal Anulados,
    decimal TotalCaja,
    string UltimoTicket);

public sealed record JugadaRepetidaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreLoteria,
    string AbreviaturaLoteria,
    string HoraSorteo,
    string Codigo,
    string Producto,
    decimal Monto);

// ------------------------------------------------------------------ Tickets
public sealed record TicketOperacionRequest(string Serial);

public sealed record PagoTicketDto(string NumeroTicket, string Serial, decimal MontoPagado, string Mensaje);

public sealed record AnulacionTicketDto(string NumeroTicket, string Mensaje);

public sealed record TicketDetalleDto(
    string NumeroTicket,
    string Serial,
    int TipoTicket,
    string Taquilla,
    string Estado,
    int? IdEstado,
    decimal MontoTicket,
    decimal MontoPagado,
    string Fecha,
    string Hora,
    string Divisa,
    IReadOnlyList<TicketGrupoDto> Grupos,
    IReadOnlyList<TicketTripletaDto> Tripletas,
    int DiasCaducidad,
    int SorteosTripleta,
    string Nota);

public sealed record TotalesMovimientosDto(int CantidadTickets, decimal Entradas, decimal Salidas, decimal TotalCaja);

public sealed record MovimientosDto(TablaDto Tickets, TotalesMovimientosDto Totales);

// ------------------------------------------------------------------ Reportes
public sealed record ResumenTotalesTaquillaDto(decimal Entradas, decimal Salidas, decimal Taquilla, decimal Utilidad);

public sealed record TotalesTaquillaDto(TablaDto Detalle, ResumenTotalesTaquillaDto Resumen);

public sealed record DesgloseDto(decimal Total, decimal Animalitos, decimal Tripletas);

public sealed record ResumenVentasDto(DesgloseDto Ventas, DesgloseDto Premios, DesgloseDto Anulados, DesgloseDto Utilidad);

// ------------------------------------------------------------------ Impresora
public sealed record ConfiguracionImpresoraRequest(string NombreImpresora, string AnchoTicket, string TamanoLetra);

public sealed record ConfiguracionImpresoraDto(string NombreImpresora, string AnchoTicket, string TamanoLetra);

// ------------------------------------------------------------------ Resultados (proceso)
public sealed record ProcesoManualRequest(int IdLoteria, int IdSorteo, string Codigo, DateOnly? Fecha);

public sealed record ResultadoGuardadoDto(int IdLoteria, int IdSorteo, string Loteria, string Codigo, string Animal, string Fuente, bool Nuevo);

public sealed record ResumenJugadasDto(int Procesadas, int Ganadoras, int Perdedoras, int ConError);

public sealed record ProcesoResultadosDto(
    string Fecha,
    int SorteosPendientes,
    IReadOnlyList<ResultadoGuardadoDto> Resultados,
    ResumenJugadasDto Jugadas,
    IReadOnlyList<string> Mensajes,
    int ProximaEjecucionMs);

public sealed record SorteoProcesoDto(int IdLoteria, string Loteria, int CodigoMaximo, int IdSorteo, string Sorteo);

public sealed record IntervaloProcesoDto(int MinimoMs, int MaximoMs);
