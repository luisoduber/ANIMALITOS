using System.Net.Http.Headers;
using Animalitos.Web.Infrastructure.Auth;

namespace Animalitos.Web.Infrastructure.Api;

/// <summary>
/// Agrega el JWT del usuario (guardado cifrado en la cookie de sesion) a cada llamada a la API.
/// El token nunca llega al navegador: el Web actua como BFF (backend for frontend).
/// </summary>
public sealed class ApiAuthHandler(IHttpContextAccessor httpContextAccessor) : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var context = httpContextAccessor.HttpContext;
        if (context is not null)
        {
            var token = context.User.ApiToken();
            if (!string.IsNullOrEmpty(token) && request.Headers.Authorization is null)
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            }

            // IP del cliente para el limite de intentos de login de la API.
            var ip = context.Connection.RemoteIpAddress?.ToString();
            if (!string.IsNullOrEmpty(ip))
            {
                request.Headers.TryAddWithoutValidation("X-Forwarded-For", ip);
            }
        }

        return base.SendAsync(request, cancellationToken);
    }
}
