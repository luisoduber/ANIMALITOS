using System.Net;
using Animalitos.Web.Infrastructure.Api;
using Animalitos.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;

namespace Animalitos.Web.Infrastructure.Web;

public static class HttpRequestExtensions
{
    /// <summary>Solicitudes hechas por fetch() desde el JS del sitio (esperan JSON, no HTML).</summary>
    public static bool EsAjax(this HttpRequest request)
        => string.Equals(request.Headers.XRequestedWith, "XMLHttpRequest", StringComparison.OrdinalIgnoreCase)
           || request.Headers.Accept.ToString().Contains("application/json", StringComparison.OrdinalIgnoreCase);
}

/// <summary>
/// Traduce los errores de la API a respuestas del sitio: JSON {mensaje} para el JS y una vista
/// de error para las paginas. Si la sesion de la API vencio o el usuario fue inactivado, cierra
/// la sesion y envia al login (igual que el sistema original cerraba la aplicacion).
/// </summary>
public sealed class ApiExceptionFilter(IModelMetadataProvider metadataProvider, ILogger<ApiExceptionFilter> logger) : IAsyncExceptionFilter
{
    public async Task OnExceptionAsync(ExceptionContext context)
    {
        var http = context.HttpContext;
        var ajax = http.Request.EsAjax();
        string mensaje;
        int status;

        switch (context.Exception)
        {
            case ApiException api when api.EsNoAutorizado || api.EsUsuarioInactivo:
                await http.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                context.Result = ajax
                    ? new JsonResult(new { mensaje = api.Message, codigo = api.Code, redirigir = "/cuenta/login" }) { StatusCode = StatusCodes.Status401Unauthorized }
                    : new RedirectToActionResult("Login", "Cuenta", new { mensaje = api.Message });
                context.ExceptionHandled = true;
                return;

            case ApiException api:
                mensaje = api.Message;
                status = (int)api.StatusCode;
                break;

            case HttpRequestException or TaskCanceledException:
            case { } ex when ex.GetType().Namespace?.StartsWith("Polly", StringComparison.Ordinal) == true:
                logger.LogError(context.Exception, "Sin comunicacion con la API");
                mensaje = "No hay comunicacion con el servidor. Verifique su conexion e intente de nuevo.";
                status = (int)HttpStatusCode.ServiceUnavailable;
                break;

            default:
                return; // Error no esperado: lo maneja UseExceptionHandler.
        }

        if (ajax)
        {
            context.Result = new JsonResult(new { mensaje }) { StatusCode = status };
        }
        else
        {
            context.Result = new ViewResult
            {
                ViewName = "Error",
                StatusCode = status,
                ViewData = new ViewDataDictionary(metadataProvider, context.ModelState)
                {
                    Model = new ErrorViewModel(mensaje, http.TraceIdentifier)
                }
            };
        }

        context.ExceptionHandled = true;
    }
}

/// <summary>Cabeceras de seguridad (CSP permite la conexion local a QZ Tray por websocket).</summary>
public sealed class SecurityHeadersMiddleware(RequestDelegate next)
{
    private const string Csp =
        "default-src 'self'; " +
        "script-src 'self'; " +
        "style-src 'self' 'unsafe-inline'; " +
        "img-src 'self' data:; " +
        "font-src 'self'; " +
        "connect-src 'self' wss://localhost:* ws://localhost:* wss://127.0.0.1:* ws://127.0.0.1:*; " +
        "frame-src 'self'; " +
        "frame-ancestors 'none'; " +
        "base-uri 'self'; " +
        "form-action 'self'";

    public Task InvokeAsync(HttpContext context)
    {
        var headers = context.Response.Headers;
        headers.ContentSecurityPolicy = Csp;
        headers.XContentTypeOptions = "nosniff";
        headers.XFrameOptions = "DENY";
        headers["Referrer-Policy"] = "no-referrer";
        headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()";
        return next(context);
    }
}
