# Animalitos.Web

Aplicación **ASP.NET Core MVC (.NET 10) + Tailwind CSS v4** que reemplaza a la taquilla WinForms `ventas_loteria`. No se conecta a la base de datos: consume **Animalitos.Api** siguiendo el patrón *BFF*. El navegador solo habla con este sitio y el JWT de la API viaja cifrado dentro de la cookie de sesión, nunca en JavaScript.

## Pantallas incluidas (fase 1)

| Pantalla | Reemplaza a | Ruta |
|---|---|---|
| Login (sin verificación de MAC) | `frm_login` | `/cuenta/login` |
| Menú de módulos (admin) | `frmMenOpe` | `/` |
| **Venta de animalitos y tripletas** | `frm_ventas`, `frmTrip` | `/ventas` |
| Pagar, anular, verificar, repetir y reimprimir ticket | `frm_ventas`, `frm_verf_ticket` | dentro de `/ventas` |
| Movimientos de tickets + imprimir cuadre | `frm_verf_status_ticket`, `frm_rpt_cuadre_diario` | `/tickets` |
| Cuadre de la taquilla | `frm_totales_venta_taq` | `/reportes/cuadre` |
| Ventas por lotería | `frmVentLot` | `/reportes/ventas` |
| Resultados | `frm_result_lot` | `/resultados` |
| Impresora (configuración y prueba) | `frm_config_impresora`, `frm_rpt_imp_prueba` | `/impresora` |
| Procesar resultados (automático y manual) | `frm_proc_result_loteria` | `/admin/resultados` |
| Cambiar clave | `frm_cambio_clave` | `/cuenta/cambiar-clave` |

Los módulos administrativos restantes (grupos/usuarios, cuadres de grupo, límites, bloqueos, control de ventas y sorteos) **ya tienen sus endpoints en la API** y aparecen en el menú marcados como "Fase 2".

## Cómo funciona la seguridad de la pantalla de venta

- Al abrir `/ventas` se obtiene la **hora de cierre del servidor** (`sp_bus_hora_servidor`) y se calcula la diferencia con el reloj del equipo, compensando la latencia de la red. El reloj no depende de la hora del PC.
- **Cada segundo** se retiran de la pantalla los sorteos cuya hora llegó y se borran las jugadas montadas de esos sorteos. El WinForms lo hacía cada minuto.
- **Cada minuto** se consulta el estado de la taquilla (`spVerfStatTaq`) y se vuelve a sincronizar el reloj. Si la taquilla fue inactivada, se cierra la sesión.
- Al vender, **la API vuelve a validar** cada sorteo contra la hora del servidor, así que una pantalla manipulada no puede vender un sorteo cerrado.
- El panel de totales (ventas, animalitos, tripletas, pagados, anulados, caja y último ticket) se actualiza después de cada venta, pago o anulación, y al volver a la pestaña.
- Las ventas **nunca se reintentan automáticamente**. Solo se reintentan las consultas GET, para no duplicar un ticket. Si se pierde la conexión durante una venta, se pide revisar "Último ticket" antes de repetir la operación.

Atajos de teclado (los mismos del sistema anterior): `Enter` en código pasa al monto, `Enter` en monto agrega la jugada, `+` o `Esc` imprimen el ticket, y `F2` cambia entre Animalitos y Tripletas.

## Impresión: QZ Tray + ESC/POS

Se eligió **QZ Tray** (v2.2.x): es gratuito y de código abierto, y es la opción más usada hoy para imprimir desde el navegador en impresoras térmicas. El servidor arma el ticket en **ESC/POS**, el mismo lenguaje que usaba `RawPrinterHelper`/winspool, y QZ Tray lo envía en crudo a la impresora configurada del usuario (`nomb_impresora`). El ancho del papel (58/80 mm) y el tamaño de letra definen las columnas (32/42 o 48/64).

Si QZ Tray no está disponible, el sistema imprime automáticamente con el **navegador**, usando formato de 58/80 mm. Si Chrome o Edge se abren con `--kiosk-printing`, esa impresión también es silenciosa.

### Instalación en cada taquilla

1. Descargue e instale QZ Tray desde https://qz.io/download y déjelo iniciado con Windows.
2. Entre a `/impresora`, pulse **Detectar**, elija la impresora térmica, el ancho y la letra, y luego **Guardar y probar**.
3. La primera vez QZ Tray pide permiso. Marque *Remember this decision* y luego *Allow*.

### Impresión 100 % silenciosa (opcional, recomendado)

QZ Tray acepta un certificado propio (autofirmado) mediante el archivo `override.crt`, sin necesidad de comprarlo:

```bash
# En el servidor Web (una sola vez)
openssl req -x509 -newkey rsa:2048 -sha512 -days 3650 -nodes \
  -keyout private-key.pem -out digital-certificate.txt -subj "/CN=Animalitos Taquilla"
```

- Copie `digital-certificate.txt` y `private-key.pem` a la carpeta `certificados/` del sitio (esa carpeta no se sube a git) y configure:
  ```json
  "QzTray": { "CertificadoPath": "certificados/digital-certificate.txt", "ClavePrivadaPath": "certificados/private-key.pem" }
  ```
- En **cada taquilla**, copie `digital-certificate.txt` como `C:\Program Files\QZ Tray\override.crt` y reinicie QZ Tray.

El sitio firma cada solicitud de impresión con SHA512 (`/impresora/qz/firmar`). La clave privada nunca sale del servidor.

## Configuración

`appsettings.json`:

- `Api:BaseUrl` es la URL de Animalitos.Api (por ejemplo `https://localhost:7101/`).
- `Impresion:Encabezado` y `Impresion:PieDePagina` son líneas opcionales del ticket (nombre de la agencia, RIF, etc.). En la misma sección están `CortarPapel`, `AbrirGaveta` y `LineasAvanceFinal`.

## Estilos (Tailwind CSS v4)

El diseño *Liquid Glass* (paleta Azul San Andrés / Verde Ávila del mockup) está en `Styles/app.css` como tokens `@theme` y componentes (`glass-card`, `btn-glass`, `glass-table`, `metric-card`, etc.). El CSS compilado ya viene en `wwwroot/css/site.css`. Para modificar estilos:

```bash
cd src/Animalitos.Web
npm install          # una vez
npm run css:watch    # durante el desarrollo
npm run css:build    # antes de publicar (tambien se ejecuta en cada build si existe node_modules)
```

También sirve el ejecutable independiente de Tailwind: `tailwindcss.exe -i Styles/app.css -o wwwroot/css/site.css --minify`.

Los íconos (Tabler Icons 3.19) y QZ Tray (`qz-tray.js` 2.2.6) están incluidos localmente en `wwwroot/lib`, sin dependencias de CDN.

## Ejecutar

1. Inicie **Animalitos.Api**. Ver su README: cadena de conexión y `Jwt:ClaveFirma`.
2. Inicie la Web:
   ```bash
   cd src/Animalitos.Web
   dotnet run --launch-profile https   # https://localhost:7201
   ```

## Publicación

```bash
dotnet publish src/Animalitos.Web -c Release -o publish/web
```

- Si hay más de un servidor Web, configure **Data Protection** con almacenamiento compartido de llaves (por ejemplo, una carpeta de red). Si no, las cookies de sesión no serán válidas entre servidores.
- Use HTTPS siempre: las cookies se emiten como `Secure` y `SameSite=Strict`.
