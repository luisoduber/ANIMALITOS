using System.Threading.RateLimiting;
using Animalitos.Api.Features.Admin;
using Animalitos.Api.Features.Auth;
using Animalitos.Api.Features.Catalogo;
using Animalitos.Api.Features.Impresora;
using Animalitos.Api.Features.Reportes;
using Animalitos.Api.Features.Resultados;
using Animalitos.Api.Features.Resultados.Scraping;
using Animalitos.Api.Features.Sistema;
using Animalitos.Api.Features.Tickets;
using Animalitos.Api.Features.Ventas;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Scalar.AspNetCore;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// ------------------------------------------------------------------ Logging
builder.Services.AddSerilog((services, logger) => logger
    .ReadFrom.Configuration(builder.Configuration)
    .ReadFrom.Services(services)
    .Enrich.FromLogContext());

// ------------------------------------------------------------------ Opciones (validadas al iniciar)
builder.Services.AddOptions<DatabaseOptions>()
    .Bind(builder.Configuration.GetSection(DatabaseOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services.AddOptions<JwtOptions>()
    .Bind(builder.Configuration.GetSection(JwtOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services.AddOptions<SecurityOptions>()
    .Bind(builder.Configuration.GetSection(SecurityOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

builder.Services.AddOptions<ResultadosOptions>()
    .Bind(builder.Configuration.GetSection(ResultadosOptions.SectionName))
    .ValidateDataAnnotations()
    .ValidateOnStart();

// ------------------------------------------------------------------ Infraestructura
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<ISqlExecutor, MySqlExecutor>();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();
builder.Services.AddHealthChecks().AddCheck<MySqlHealthCheck>("mysql");
builder.Services.AddOpenApi();

builder.Services.Configure<ForwardedHeadersOptions>(options =>
{
    // El proyecto Web llama a la API de servidor a servidor. Si hay un proxy/IIS delante,
    // agregue sus IP en KnownProxies para confiar en X-Forwarded-For.
    options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
});

// ------------------------------------------------------------------ Autenticacion JWT
var jwt = builder.Configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>() ?? new JwtOptions();
builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.MapInboundClaims = false;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwt.Emisor,
            ValidateAudience = true,
            ValidAudience = jwt.Audiencia,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = TokenService.CrearClave(string.IsNullOrEmpty(jwt.ClaveFirma) ? new string('x', 32) : jwt.ClaveFirma),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1),
            NameClaimType = AppClaims.Name,
            RoleClaimType = AppClaims.Role
        };
    });

builder.Services.AddAuthorizationBuilder()
    .AddPolicy(Politicas.Admin, policy => policy.RequireRole(Perfiles.RolAdminGrupo, Perfiles.RolSuperAdmin))
    .AddPolicy(Politicas.SuperAdmin, policy => policy.RequireRole(Perfiles.RolSuperAdmin))
    // Todo endpoint exige autenticacion salvo los marcados con AllowAnonymous.
    .SetFallbackPolicy(new Microsoft.AspNetCore.Authorization.AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build());

// ------------------------------------------------------------------ Limite de intentos de login
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy(AuthEndpoints.LoginRateLimitPolicy, context =>
    {
        // El Web reenvia la IP del cliente en X-Forwarded-For (ver ForwardedHeaders).
        var clave = context.Connection.RemoteIpAddress?.ToString() ?? "desconocido";
        return RateLimitPartition.GetFixedWindowLimiter(clave, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 30,
            Window = TimeSpan.FromMinutes(1),
            QueueLimit = 0
        });
    });
});

// ------------------------------------------------------------------ Servicios de negocio
builder.Services.AddScoped<UsuarioRepository>();
builder.Services.AddSingleton<PasswordService>();
builder.Services.AddSingleton<LoginAttemptTracker>();
builder.Services.AddSingleton<TokenService>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<SistemaRepository>();
builder.Services.AddScoped<CatalogoRepository>();
builder.Services.AddScoped<VentaAnimalitosService>();
builder.Services.AddScoped<VentaTripletasService>();
builder.Services.AddScoped<VentasConsultasService>();
builder.Services.AddScoped<TicketsService>();
builder.Services.AddScoped<ResultadosService>();
builder.Services.AddScoped<ResultadosScraper>();
builder.Services
    .AddHttpClient<PaginaResultadosClient>(PaginaResultadosClient.HttpClientName, (sp, client) =>
    {
        var o = sp.GetRequiredService<IOptions<ResultadosOptions>>().Value;
        client.Timeout = TimeSpan.FromSeconds(o.TimeoutSegundos);
    });

var app = builder.Build();

// ------------------------------------------------------------------ Pipeline
app.UseForwardedHeaders();
app.UseExceptionHandler();
app.UseStatusCodePages();

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseSerilogRequestLogging();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi().AllowAnonymous();
    app.MapScalarApiReference(options => options.WithTitle("Animalitos API")).AllowAnonymous();
}

app.MapHealthChecks("/health").AllowAnonymous();

app.MapAuthEndpoints();
app.MapSistemaEndpoints();
app.MapCatalogoEndpoints();
app.MapVentasEndpoints();
app.MapTicketsEndpoints();
app.MapReportesEndpoints();
app.MapResultadosEndpoints();
app.MapImpresoraEndpoints();
app.MapAdminEndpoints();

app.Run();

/// <summary>Expuesto para pruebas de integracion (WebApplicationFactory).</summary>
public partial class Program { }
