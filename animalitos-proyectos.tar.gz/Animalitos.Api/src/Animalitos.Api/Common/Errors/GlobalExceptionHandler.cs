using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MySqlConnector;

namespace Animalitos.Api.Common.Errors;

/// <summary>
/// Manejo centralizado de errores: todas las respuestas de error salen como ProblemDetails
/// (RFC 9457). Los detalles internos solo se muestran en Development.
/// </summary>
public sealed class GlobalExceptionHandler(
    IProblemDetailsService problemDetailsService,
    IHostEnvironment environment,
    ILogger<GlobalExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        int status;
        string title;
        string detail;
        string? code = null;

        switch (exception)
        {
            case BusinessRuleException business:
                status = business.StatusCode;
                title = status switch
                {
                    StatusCodes.Status404NotFound => "No encontrado",
                    StatusCodes.Status409Conflict => "Operacion no permitida",
                    StatusCodes.Status403Forbidden => "Acceso denegado",
                    StatusCodes.Status401Unauthorized => "No autorizado",
                    _ => "Solicitud invalida"
                };
                detail = business.Message;
                code = business.Code;
                logger.LogInformation("Regla de negocio: {Mensaje} ({Codigo})", business.Message, business.Code);
                break;

            case BadHttpRequestException badRequest:
                status = badRequest.StatusCode;
                title = "Solicitud invalida";
                detail = environment.IsDevelopment() ? badRequest.Message : "Los datos enviados no son validos.";
                break;

            case MySqlException mysql:
                status = StatusCodes.Status503ServiceUnavailable;
                title = "Error de base de datos";
                detail = environment.IsDevelopment()
                    ? mysql.Message
                    : "No fue posible completar la operacion en la base de datos. Intente nuevamente.";
                logger.LogError(mysql, "Error MySQL ({Numero}) en {Ruta}", mysql.Number, httpContext.Request.Path);
                break;

            case OperationCanceledException when httpContext.RequestAborted.IsCancellationRequested:
                // El cliente cancelo la solicitud: no hay a quien responder.
                return true;

            default:
                status = StatusCodes.Status500InternalServerError;
                title = "Error interno";
                detail = environment.IsDevelopment() ? exception.ToString() : "Ocurrio un error inesperado.";
                logger.LogError(exception, "Error no controlado en {Ruta}", httpContext.Request.Path);
                break;
        }

        httpContext.Response.StatusCode = status;

        var problem = new ProblemDetails
        {
            Status = status,
            Title = title,
            Detail = detail,
            Instance = httpContext.Request.Path
        };

        if (!string.IsNullOrEmpty(code))
        {
            problem.Extensions["codigo"] = code;
        }

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            Exception = exception,
            ProblemDetails = problem
        });
    }
}
