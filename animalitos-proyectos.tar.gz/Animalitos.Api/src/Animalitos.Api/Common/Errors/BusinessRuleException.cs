namespace Animalitos.Api.Common.Errors;

/// <summary>
/// Error de negocio esperado (validaciones, ticket inexistente, sorteo cerrado, etc.).
/// Se traduce a una respuesta ProblemDetails con el codigo HTTP indicado; reemplaza a los
/// MessageBox.Show del sistema original.
/// </summary>
public class BusinessRuleException : Exception
{
    public BusinessRuleException(string message, int statusCode = StatusCodes.Status400BadRequest, string? code = null)
        : base(message)
    {
        StatusCode = statusCode;
        Code = code;
    }

    public int StatusCode { get; }

    /// <summary>Codigo corto opcional para que el cliente reaccione (ej. "usuario_inactivo").</summary>
    public string? Code { get; }

    public static BusinessRuleException NotFound(string message, string? code = null)
        => new(message, StatusCodes.Status404NotFound, code);

    public static BusinessRuleException Conflict(string message, string? code = null)
        => new(message, StatusCodes.Status409Conflict, code);

    public static BusinessRuleException Forbidden(string message, string? code = null)
        => new(message, StatusCodes.Status403Forbidden, code);

    public static BusinessRuleException Unauthorized(string message, string? code = null)
        => new(message, StatusCodes.Status401Unauthorized, code);
}

/// <summary>Validaciones sencillas de entrada.</summary>
public static class Guard
{
    public static void Against(bool condition, string message, string? code = null)
    {
        if (condition)
        {
            throw new BusinessRuleException(message, StatusCodes.Status400BadRequest, code);
        }
    }

    public static string NotEmpty(string? value, string campo)
    {
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new BusinessRuleException($"El campo '{campo}' es requerido.");
        }

        return value.Trim();
    }

    public static void DateRange(DateOnly desde, DateOnly hasta)
    {
        if (desde > hasta)
        {
            throw new BusinessRuleException("La fecha inicial no debe ser mayor a la fecha final.");
        }
    }
}
