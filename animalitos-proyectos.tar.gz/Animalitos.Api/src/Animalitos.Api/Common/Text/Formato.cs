namespace Animalitos.Api.Common.Text;

/// <summary>Formatos de fecha y hora usados en tickets y mensajes.</summary>
public static class Formato
{
    /// <summary>Cultura es-VE (o invariante si el servidor no tiene datos ICU).</summary>
    public static readonly CultureInfo Venezuela = CrearCultura();

    private static readonly NumberFormatInfo FormatoMonto = new()
    {
        NumberDecimalSeparator = ",",
        NumberGroupSeparator = ".",
        NumberDecimalDigits = 2
    };

    public static string Fecha(DateTime? fecha)
        => fecha?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? string.Empty;

    /// <summary>Hora en formato 12 horas, ej. "10:00 AM".</summary>
    public static string Hora12(TimeSpan? hora)
        => hora is null ? string.Empty : DateTime.Today.Add(hora.Value).ToString("hh:mm tt", CultureInfo.InvariantCulture);

    public static string Hora24(TimeSpan? hora)
        => hora?.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture) ?? string.Empty;

    /// <summary>Monto con separador de miles "." y decimal "," (formato del sistema original).</summary>
    public static string Monto(decimal monto) => monto.ToString("N2", FormatoMonto);

    private static CultureInfo CrearCultura()
    {
        try
        {
            return CultureInfo.GetCultureInfo("es-VE");
        }
        catch (CultureNotFoundException)
        {
            return CultureInfo.InvariantCulture;
        }
    }
}
