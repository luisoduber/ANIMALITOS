namespace Animalitos.Api.Common.Text;

/// <summary>Reglas de formato heredadas del sistema original.</summary>
public static class Codigos
{
    /// <summary>
    /// Normaliza el codigo de una jugada: "7" => "07", "0" se mantiene ("0" y "00" son
    /// animalitos distintos: Delfin y Ballena).
    /// </summary>
    public static string Normalizar(string? codigo)
    {
        var c = (codigo ?? string.Empty).Trim();
        if (c.Length == 1 && c != "0")
        {
            c = c.PadLeft(2, '0');
        }

        return c;
    }

    public static bool EsValido(string? codigo)
        => !string.IsNullOrWhiteSpace(codigo) && codigo.Trim().Length <= 3 && codigo.Trim().All(char.IsAsciiDigit);

    /// <summary>Valor numerico del codigo ("00" => 0) para compararlo con el codigo maximo de la loteria.</summary>
    public static int Valor(string codigo) => int.Parse(codigo, NumberStyles.None, CultureInfo.InvariantCulture);

    /// <summary>Primeras 3 letras en mayuscula del nombre del producto (formato del ticket).</summary>
    public static string Abreviar(string? nombre)
    {
        var n = (nombre ?? string.Empty).Trim().ToUpperInvariant();
        return n.Length > 3 ? n[..3] : n;
    }
}
