namespace Animalitos.Api.Common.Security;

/// <summary>
/// Perfiles del sistema original (tabla perfil / campo id_perfil):
/// 1 = Taquilla, 2 = Administrador de grupo, 3 = Super administrador.
/// </summary>
public static class Perfiles
{
    public const int Taquilla = 1;
    public const int AdminGrupo = 2;
    public const int SuperAdmin = 3;

    public const string RolTaquilla = "Taquilla";
    public const string RolAdminGrupo = "AdminGrupo";
    public const string RolSuperAdmin = "SuperAdmin";

    public static string Rol(int idPerfil) => idPerfil switch
    {
        AdminGrupo => RolAdminGrupo,
        SuperAdmin => RolSuperAdmin,
        _ => RolTaquilla
    };
}

public static class Politicas
{
    /// <summary>Administrador de grupo o super administrador.</summary>
    public const string Admin = "Admin";

    /// <summary>Solo super administrador.</summary>
    public const string SuperAdmin = "SuperAdmin";
}

/// <summary>Nombres de los claims que viajan en el JWT.</summary>
public static class AppClaims
{
    public const string Subject = "sub";
    public const string Name = "name";
    public const string Role = "role";
    public const string Perfil = "perfil";
    public const string Grupo = "grupo";
}

public static class ClaimsPrincipalExtensions
{
    public static int IdUsuario(this ClaimsPrincipal user) => ReadInt(user, AppClaims.Subject);

    public static int IdPerfil(this ClaimsPrincipal user) => ReadInt(user, AppClaims.Perfil);

    public static int IdGrupo(this ClaimsPrincipal user) => ReadInt(user, AppClaims.Grupo);

    public static string Nick(this ClaimsPrincipal user)
        => user.FindFirst(AppClaims.Name)?.Value
           ?? throw BusinessRuleException.Unauthorized("Sesion invalida.");

    public static bool EsSuperAdmin(this ClaimsPrincipal user) => user.IdPerfil() == Perfiles.SuperAdmin;

    public static bool EsAdmin(this ClaimsPrincipal user) => user.IdPerfil() is Perfiles.AdminGrupo or Perfiles.SuperAdmin;

    /// <summary>
    /// Grupo sobre el que puede operar el usuario: el super administrador puede indicar
    /// cualquier grupo; el resto solo el suyo.
    /// </summary>
    public static int ResolverGrupo(this ClaimsPrincipal user, int? idGrupoSolicitado)
    {
        if (idGrupoSolicitado is null or 0)
        {
            return user.IdGrupo();
        }

        if (user.EsSuperAdmin() || idGrupoSolicitado == user.IdGrupo())
        {
            return idGrupoSolicitado.Value;
        }

        throw BusinessRuleException.Forbidden("No tiene permisos sobre el grupo indicado.");
    }

    private static int ReadInt(ClaimsPrincipal user, string claim)
    {
        var value = user.FindFirst(claim)?.Value;
        return int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var id)
            ? id
            : throw BusinessRuleException.Unauthorized("Sesion invalida.");
    }
}
