using System.ComponentModel.DataAnnotations;
using System.Data;
using Microsoft.Extensions.Options;
using MySqlConnector;

namespace Animalitos.Api.Common.Data;

public sealed class DatabaseOptions
{
    public const string SectionName = "Database";

    /// <summary>Nombre de la cadena de conexion en la seccion ConnectionStrings.</summary>
    [Required]
    public string ConnectionStringName { get; set; } = "Loterias";

    /// <summary>Tiempo maximo (segundos) de cada comando.</summary>
    [Range(5, 600)]
    public int CommandTimeoutSeconds { get; set; } = 60;
}

/// <summary>Resultado crudo de un procedimiento: columnas + filas.</summary>
public sealed record SpResult(string[] Columns, IReadOnlyList<DbRow> Rows);

/// <summary>Operaciones sobre una conexion (con o sin transaccion).</summary>
public interface ISqlSession
{
    Task<SpResult> QueryResultAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default);

    Task<IReadOnlyList<DbRow>> QueryAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default);

    Task<DbRow?> QueryFirstAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default);

    Task<int> ExecuteAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default);
}

/// <summary>Sesion con transaccion abierta. Si no se confirma, se revierte al liberar.</summary>
public interface ISqlTransaction : ISqlSession, IAsyncDisposable
{
    Task CommitAsync(CancellationToken ct = default);

    Task RollbackAsync(CancellationToken ct = default);
}

/// <summary>
/// Ejecutor de procedimientos almacenados. Reemplaza a la clase clsMet: cada llamada abre
/// su conexion desde el pool, usa parametros (nunca concatenacion) y es 100% asincrona.
/// </summary>
public interface ISqlExecutor : ISqlSession
{
    Task<TablaDto> QueryTablaAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default);

    Task<ISqlTransaction> BeginTransactionAsync(CancellationToken ct = default);

    Task<bool> PingAsync(CancellationToken ct = default);
}

public sealed class MySqlExecutor : ISqlExecutor
{
    private readonly string _connectionString;
    private readonly int _commandTimeout;

    public MySqlExecutor(IConfiguration configuration, IOptions<DatabaseOptions> options)
    {
        var o = options.Value;
        _connectionString = configuration.GetConnectionString(o.ConnectionStringName)
            ?? throw new InvalidOperationException(
                $"No se encontro la cadena de conexion '{o.ConnectionStringName}'. Configurela con user-secrets o variables de entorno.");
        _commandTimeout = o.CommandTimeoutSeconds;
    }

    public async Task<SpResult> QueryResultAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
    {
        await using var connection = await OpenAsync(ct);
        return await SqlCommandRunner.QueryAsync(connection, null, procedure, parameters, _commandTimeout, ct);
    }

    public async Task<IReadOnlyList<DbRow>> QueryAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
        => (await QueryResultAsync(procedure, parameters, ct)).Rows;

    public async Task<DbRow?> QueryFirstAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
    {
        var rows = await QueryAsync(procedure, parameters, ct);
        return rows.Count > 0 ? rows[0] : null;
    }

    public async Task<int> ExecuteAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
    {
        await using var connection = await OpenAsync(ct);
        return await SqlCommandRunner.ExecuteAsync(connection, null, procedure, parameters, _commandTimeout, ct);
    }

    public async Task<TablaDto> QueryTablaAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
    {
        var result = await QueryResultAsync(procedure, parameters, ct);
        return TablaDto.From(result.Columns, result.Rows);
    }

    public async Task<ISqlTransaction> BeginTransactionAsync(CancellationToken ct = default)
    {
        var connection = await OpenAsync(ct);
        try
        {
            var transaction = await connection.BeginTransactionAsync(IsolationLevel.ReadCommitted, ct);
            return new MySqlSqlTransaction(connection, transaction, _commandTimeout);
        }
        catch
        {
            await connection.DisposeAsync();
            throw;
        }
    }

    public async Task<bool> PingAsync(CancellationToken ct = default)
    {
        await using var connection = await OpenAsync(ct);
        return await connection.PingAsync(ct);
    }

    private async Task<MySqlConnection> OpenAsync(CancellationToken ct)
    {
        var connection = new MySqlConnection(_connectionString);
        try
        {
            await connection.OpenAsync(ct);
            return connection;
        }
        catch
        {
            await connection.DisposeAsync();
            throw;
        }
    }

    private sealed class MySqlSqlTransaction(MySqlConnection connection, MySqlTransaction transaction, int commandTimeout) : ISqlTransaction
    {
        private bool _completed;

        public async Task<SpResult> QueryResultAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
            => await SqlCommandRunner.QueryAsync(connection, transaction, procedure, parameters, commandTimeout, ct);

        public async Task<IReadOnlyList<DbRow>> QueryAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
            => (await QueryResultAsync(procedure, parameters, ct)).Rows;

        public async Task<DbRow?> QueryFirstAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
        {
            var rows = await QueryAsync(procedure, parameters, ct);
            return rows.Count > 0 ? rows[0] : null;
        }

        public Task<int> ExecuteAsync(string procedure, SpParameters? parameters = null, CancellationToken ct = default)
            => SqlCommandRunner.ExecuteAsync(connection, transaction, procedure, parameters, commandTimeout, ct);

        public async Task CommitAsync(CancellationToken ct = default)
        {
            await transaction.CommitAsync(ct);
            _completed = true;
        }

        public async Task RollbackAsync(CancellationToken ct = default)
        {
            if (_completed)
            {
                return;
            }

            await transaction.RollbackAsync(ct);
            _completed = true;
        }

        public async ValueTask DisposeAsync()
        {
            try
            {
                if (!_completed)
                {
                    // Nunca se deja una transaccion colgada: si no se confirmo, se revierte.
                    await transaction.RollbackAsync(CancellationToken.None);
                }
            }
            catch
            {
                // La conexion puede estar rota; al liberarla MySQL revierte la transaccion.
            }
            finally
            {
                await transaction.DisposeAsync();
                await connection.DisposeAsync();
            }
        }
    }
}

internal static class SqlCommandRunner
{
    public static async Task<SpResult> QueryAsync(
        MySqlConnection connection,
        MySqlTransaction? transaction,
        string procedure,
        SpParameters? parameters,
        int commandTimeout,
        CancellationToken ct)
    {
        await using var command = Create(connection, transaction, procedure, parameters, commandTimeout);
        await using var reader = await command.ExecuteReaderAsync(ct);

        var columns = new string[reader.FieldCount];
        for (var i = 0; i < reader.FieldCount; i++)
        {
            columns[i] = reader.GetName(i);
        }

        var rows = new List<DbRow>();
        while (await reader.ReadAsync(ct))
        {
            var values = new object?[reader.FieldCount];
            for (var i = 0; i < reader.FieldCount; i++)
            {
                var value = reader.GetValue(i);
                values[i] = value is DBNull ? null : value;
            }

            rows.Add(new DbRow(columns, values));
        }

        // Se consumen los resultados adicionales que MySQL devuelve al final de un CALL.
        while (await reader.NextResultAsync(ct))
        {
        }

        return new SpResult(columns, rows);
    }

    public static async Task<int> ExecuteAsync(
        MySqlConnection connection,
        MySqlTransaction? transaction,
        string procedure,
        SpParameters? parameters,
        int commandTimeout,
        CancellationToken ct)
    {
        await using var command = Create(connection, transaction, procedure, parameters, commandTimeout);
        return await command.ExecuteNonQueryAsync(ct);
    }

    private static MySqlCommand Create(
        MySqlConnection connection,
        MySqlTransaction? transaction,
        string procedure,
        SpParameters? parameters,
        int commandTimeout)
    {
        var command = new MySqlCommand(procedure, connection, transaction)
        {
            CommandType = CommandType.StoredProcedure,
            CommandTimeout = commandTimeout
        };

        if (parameters is not null)
        {
            foreach (var (name, value) in parameters)
            {
                command.Parameters.AddWithValue(name, value ?? DBNull.Value);
            }
        }

        return command;
    }
}
