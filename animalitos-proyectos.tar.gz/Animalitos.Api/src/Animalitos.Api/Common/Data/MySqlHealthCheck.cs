using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Animalitos.Api.Common.Data;

/// <summary>Verifica que la base de datos responda (endpoint /health).</summary>
public sealed class MySqlHealthCheck(ISqlExecutor db) : IHealthCheck
{
    public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        try
        {
            return await db.PingAsync(cancellationToken)
                ? HealthCheckResult.Healthy("MySQL disponible.")
                : HealthCheckResult.Unhealthy("MySQL no respondio al ping.");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("No hay conexion con MySQL.", ex);
        }
    }
}
