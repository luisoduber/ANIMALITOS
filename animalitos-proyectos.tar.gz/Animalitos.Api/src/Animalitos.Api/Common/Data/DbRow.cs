namespace Animalitos.Api.Common.Data;

/// <summary>
/// Fila devuelta por un procedimiento almacenado. Permite leer por nombre de columna
/// (sin distinguir mayusculas, aceptando alias) o por posicion, igual que hacia el
/// sistema original con dr["columna"] y dtTabla.Rows[i][n].
/// </summary>
public sealed class DbRow
{
    private readonly string[] _columns;
    private readonly object?[] _values;
    private readonly Dictionary<string, int> _index;

    public DbRow(string[] columns, object?[] values)
    {
        _columns = columns;
        _values = values;
        _index = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < columns.Length; i++)
        {
            _index.TryAdd(columns[i], i);
        }
    }

    public IReadOnlyList<string> Columns => _columns;

    public IReadOnlyList<object?> Values => _values;

    public int Count => _values.Length;

    public bool Has(string column) => _index.ContainsKey(column);

    /// <summary>Valor de la primera columna existente entre los nombres indicados.</summary>
    public object? Get(params string[] columns)
    {
        foreach (var column in columns)
        {
            if (_index.TryGetValue(column, out var i))
            {
                return _values[i];
            }
        }

        return null;
    }

    public object? GetAt(int index) => index >= 0 && index < _values.Length ? _values[index] : null;

    public string GetString(params string[] columns) => DbConvert.ToText(Get(columns));

    public int GetInt32(params string[] columns) => DbConvert.ToInt32(Get(columns));

    public long GetInt64(params string[] columns) => DbConvert.ToInt64(Get(columns));

    public decimal GetDecimal(params string[] columns) => DbConvert.ToDecimal(Get(columns));

    public DateTime? GetDateTime(params string[] columns) => DbConvert.ToDateTime(Get(columns));

    public TimeSpan? GetTimeOfDay(params string[] columns) => DbConvert.ToTimeOfDay(Get(columns));

    public string GetStringAt(int index) => DbConvert.ToText(GetAt(index));

    public int GetInt32At(int index) => DbConvert.ToInt32(GetAt(index));

    public decimal GetDecimalAt(int index) => DbConvert.ToDecimal(GetAt(index));

    public DateTime? GetDateTimeAt(int index) => DbConvert.ToDateTime(GetAt(index));

    public TimeSpan? GetTimeOfDayAt(int index) => DbConvert.ToTimeOfDay(GetAt(index));

    /// <summary>Representacion como diccionario (columna => valor) apta para JSON.</summary>
    public Dictionary<string, object?> ToDictionary()
    {
        var dict = new Dictionary<string, object?>(_columns.Length, StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < _columns.Length; i++)
        {
            dict.TryAdd(_columns[i], DbConvert.ToJsonValue(_values[i]));
        }

        return dict;
    }
}

/// <summary>Parametros de un procedimiento almacenado (nombre exacto del parametro => valor).</summary>
public sealed class SpParameters : Dictionary<string, object?>
{
    public SpParameters() : base(StringComparer.OrdinalIgnoreCase)
    {
    }
}

/// <summary>
/// Resultado tabular generico (reemplaza a los DataTable del sistema original). Conserva el
/// orden y el nombre de las columnas tal como las devuelve el procedimiento.
/// </summary>
public sealed record TablaDto(IReadOnlyList<string> Columnas, IReadOnlyList<object?[]> Filas)
{
    public static TablaDto Vacia { get; } = new([], []);

    public static TablaDto From(string[] columns, IReadOnlyList<DbRow> rows)
    {
        var filas = new List<object?[]>(rows.Count);
        foreach (var row in rows)
        {
            var fila = new object?[row.Count];
            for (var i = 0; i < row.Count; i++)
            {
                fila[i] = DbConvert.ToJsonValue(row.GetAt(i));
            }

            filas.Add(fila);
        }

        return new TablaDto(columns, filas);
    }
}
