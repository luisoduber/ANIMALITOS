namespace Animalitos.Api.Common.Data;

/// <summary>
/// Conversiones tolerantes de los valores que devuelven los procedimientos almacenados.
/// El sistema original convertia todo a string y luego con Convert.ToXxx usando la cultura
/// del equipo (es-VE); aqui se convierte siempre de forma explicita e invariante.
/// </summary>
public static class DbConvert
{
    private static readonly string[] FormatosFecha =
    [
        "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd H:mm:ss", "yyyy-MM-ddTHH:mm:ss", "yyyy-MM-dd",
        "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd", "dd/MM/yyyy HH:mm:ss", "dd/MM/yyyy hh:mm:ss tt",
        "dd/MM/yyyy", "dd-MM-yyyy", "MM/dd/yyyy HH:mm:ss", "MM/dd/yyyy hh:mm:ss tt"
    ];

    private static readonly string[] FormatosHora =
    [
        @"hh\:mm\:ss", @"h\:mm\:ss", @"hh\:mm", @"h\:mm"
    ];

    public static bool IsNull(object? value) => value is null || value is DBNull;

    public static string ToText(object? value)
    {
        if (IsNull(value))
        {
            return string.Empty;
        }

        return value switch
        {
            string s => s.Trim(),
            DateTime d => d.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
            TimeSpan t => t.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture),
            IFormattable f => f.ToString(null, CultureInfo.InvariantCulture).Trim(),
            _ => value!.ToString()?.Trim() ?? string.Empty
        };
    }

    public static long ToInt64(object? value, long defaultValue = 0)
    {
        if (IsNull(value))
        {
            return defaultValue;
        }

        switch (value)
        {
            case long l: return l;
            case int i: return i;
            case short s: return s;
            case byte b: return b;
            case sbyte sb: return sb;
            case ulong ul: return unchecked((long)ul);
            case uint ui: return ui;
            case ushort us: return us;
            case bool bo: return bo ? 1 : 0;
            case decimal d: return (long)decimal.Truncate(d);
            case double db: return (long)Math.Truncate(db);
            case float f: return (long)Math.Truncate(f);
        }

        var text = ToText(value);
        if (long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
        {
            return parsed;
        }

        return TryParseDecimal(text, out var dec) ? (long)decimal.Truncate(dec) : defaultValue;
    }

    public static int ToInt32(object? value, int defaultValue = 0)
    {
        var l = ToInt64(value, defaultValue);
        return l is > int.MaxValue or < int.MinValue ? defaultValue : (int)l;
    }

    public static decimal ToDecimal(object? value, decimal defaultValue = 0m)
    {
        if (IsNull(value))
        {
            return defaultValue;
        }

        switch (value)
        {
            case decimal d: return d;
            case double db: return (decimal)db;
            case float f: return (decimal)f;
            case long l: return l;
            case int i: return i;
            case short s: return s;
            case byte b: return b;
            case ulong ul: return ul;
            case uint ui: return ui;
        }

        return TryParseDecimal(ToText(value), out var parsed) ? parsed : defaultValue;
    }

    /// <summary>
    /// Interpreta montos con punto o coma decimal ("1234.50", "1.234,50", "1,234.50", "10,5").
    /// El separador que aparece de ultimo se toma como separador decimal.
    /// </summary>
    public static bool TryParseDecimal(string? text, out decimal result)
    {
        result = 0m;
        if (string.IsNullOrWhiteSpace(text))
        {
            return false;
        }

        var t = text.Trim().Replace(" ", string.Empty);
        var lastDot = t.LastIndexOf('.');
        var lastComma = t.LastIndexOf(',');

        if (lastDot >= 0 && lastComma >= 0)
        {
            t = lastComma > lastDot
                ? t.Replace(".", string.Empty).Replace(',', '.')
                : t.Replace(",", string.Empty);
        }
        else if (lastComma >= 0)
        {
            t = t.Replace(',', '.');
        }

        return decimal.TryParse(t, NumberStyles.Number, CultureInfo.InvariantCulture, out result);
    }

    public static DateTime? ToDateTime(object? value)
    {
        if (IsNull(value))
        {
            return null;
        }

        switch (value)
        {
            case DateTime d: return d;
            case DateTimeOffset o: return o.DateTime;
            case DateOnly dateOnly: return dateOnly.ToDateTime(TimeOnly.MinValue);
        }

        var text = ToText(value);
        if (DateTime.TryParseExact(text, FormatosFecha, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var exact))
        {
            return exact;
        }

        if (DateTime.TryParse(text, Formato.Venezuela, DateTimeStyles.AllowWhiteSpaces, out var es))
        {
            return es;
        }

        return DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.AllowWhiteSpaces, out var inv) ? inv : null;
    }

    /// <summary>Obtiene la hora del dia (TIME, DATETIME o texto "10:00 AM", "22:00:00").</summary>
    public static TimeSpan? ToTimeOfDay(object? value)
    {
        if (IsNull(value))
        {
            return null;
        }

        switch (value)
        {
            case TimeSpan t: return t;
            case DateTime d: return d.TimeOfDay;
            case TimeOnly to: return to.ToTimeSpan();
        }

        var text = ToText(value);
        if (TimeSpan.TryParseExact(text, FormatosHora, CultureInfo.InvariantCulture, out var ts) && ts < TimeSpan.FromDays(1))
        {
            return ts;
        }

        if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.NoCurrentDateDefault | DateTimeStyles.AllowWhiteSpaces, out var dt))
        {
            return dt.TimeOfDay;
        }

        return DateTime.TryParse(text, Formato.Venezuela, DateTimeStyles.NoCurrentDateDefault | DateTimeStyles.AllowWhiteSpaces, out var es)
            ? es.TimeOfDay
            : null;
    }

    /// <summary>Normaliza un valor para devolverlo en JSON (tablas genericas).</summary>
    public static object? ToJsonValue(object? value) => value switch
    {
        null => null,
        DBNull => null,
        TimeSpan t => t.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture),
        DateOnly d => d.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
        TimeOnly t => t.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
        byte[] bytes => Convert.ToBase64String(bytes),
        _ => value
    };
}
