namespace Animalitos.Api.Features.Auth;

/// <summary>Acceso a los procedimientos de usuario (antes: verfLogUsu, busClavUsu, cambClavUsuario).</summary>
public sealed class UsuarioRepository(ISqlExecutor db)
{
    /// <summary>SPverfLog: datos completos del usuario por nick.</summary>
    public async Task<UsuarioPerfil?> ObtenerPorNickAsync(string nick, CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("SPverfLog", new SpParameters { ["prmUsu"] = nick }, ct);
        if (row is null)
        {
            return null;
        }

        return new UsuarioPerfil(
            IdUsuario: row.GetInt32("id_usuario"),
            Nick: row.GetString("nick"),
            ClaveAlmacenada: DbConvert.IsNull(row.Get("clave")) ? string.Empty : Convert.ToString(row.Get("clave"), CultureInfo.InvariantCulture) ?? string.Empty,
            IdEstado: row.GetInt32("id_status"),
            IdPerfil: row.GetInt32("id_perfil"),
            NombrePerfil: row.GetString("nomb_perfil"),
            IdGrupo: row.GetInt32("id_grupo"),
            Divisa: row.GetString("nombDivisa"),
            Limites: new LimitesVentaDto(
                MontoMaxJugada: row.GetDecimal("monto_max_jug"),
                MontoMaxTripleta: row.GetDecimal("mMaxTrip"),
                MontoMaxTicket: row.GetDecimal("monto_max_ticket"),
                MontoPorUnidad: row.GetDecimal("monto_Xunidad"),
                MontoMultiploJugada: row.GetDecimal("monto_multiplo_jug"),
                MontoMinJugada: row.GetDecimal("monto_min_jug")),
            Impresora: new ConfigImpresoraDto(
                Nombre: row.GetString("nomb_impresora"),
                Ancho: row.GetString("ancho_ticket"),
                TamanoLetra: row.GetString("num_letra")));
    }

    /// <summary>SP_verf_cambio_clave: clave almacenada del usuario.</summary>
    public async Task<string?> ObtenerClaveAsync(int idUsuario, CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("SP_verf_cambio_clave", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);
        var value = row?.Get("clave");
        return DbConvert.IsNull(value) ? null : Convert.ToString(value, CultureInfo.InvariantCulture);
    }

    /// <summary>SP_act_cambio_clave: guarda la clave (texto plano o hash segun configuracion).</summary>
    public Task<int> ActualizarClaveAsync(int idUsuario, string claveAGuardar, CancellationToken ct)
        => db.ExecuteAsync("SP_act_cambio_clave", new SpParameters
        {
            ["prm_id_usuario"] = idUsuario,
            ["prm_clave"] = claveAGuardar
        }, ct);
}
