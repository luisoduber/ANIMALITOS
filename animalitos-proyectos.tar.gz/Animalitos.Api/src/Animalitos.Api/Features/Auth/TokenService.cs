using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

namespace Animalitos.Api.Features.Auth;

public sealed record TokenEmitido(string Token, DateTimeOffset ExpiraEn);

/// <summary>Emision de JWT firmados (HMAC-SHA256) para el proyecto Web.</summary>
public sealed class TokenService(IOptions<JwtOptions> options, TimeProvider time)
{
    private readonly JsonWebTokenHandler _handler = new();

    public TokenEmitido Emitir(UsuarioPerfil usuario)
    {
        var o = options.Value;
        var ahora = time.GetUtcNow();
        var expira = ahora.AddMinutes(o.MinutosExpiracion);

        var claims = new Claim[]
        {
            new(AppClaims.Subject, usuario.IdUsuario.ToString(CultureInfo.InvariantCulture)),
            new(AppClaims.Name, usuario.Nick),
            new(AppClaims.Role, Perfiles.Rol(usuario.IdPerfil)),
            new(AppClaims.Perfil, usuario.IdPerfil.ToString(CultureInfo.InvariantCulture)),
            new(AppClaims.Grupo, usuario.IdGrupo.ToString(CultureInfo.InvariantCulture)),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString("N"))
        };

        var identity = new ClaimsIdentity(claims, "jwt", AppClaims.Name, AppClaims.Role);

        var descriptor = new SecurityTokenDescriptor
        {
            Issuer = o.Emisor,
            Audience = o.Audiencia,
            Subject = identity,
            IssuedAt = ahora.UtcDateTime,
            NotBefore = ahora.UtcDateTime,
            Expires = expira.UtcDateTime,
            SigningCredentials = new SigningCredentials(CrearClave(o.ClaveFirma), SecurityAlgorithms.HmacSha256)
        };

        return new TokenEmitido(_handler.CreateToken(descriptor), expira);
    }

    public static SymmetricSecurityKey CrearClave(string claveFirma)
        => new(Encoding.UTF8.GetBytes(claveFirma));
}
