using System.ComponentModel.DataAnnotations;

namespace Animalitos.Api.Features.Auth;

public sealed record LoginRequest(string Usuario, string Clave);

public sealed record CambiarClaveRequest(string ClaveActual, string ClaveNueva, string ConfirmarClave);

public sealed record LimitesVentaDto(
    decimal MontoMaxJugada,
    decimal MontoMaxTripleta,
    decimal MontoMaxTicket,
    decimal MontoPorUnidad,
    decimal MontoMultiploJugada,
    decimal MontoMinJugada);

public sealed record ConfigImpresoraDto(string Nombre, string Ancho, string TamanoLetra);

public sealed record UsuarioDto(
    int IdUsuario,
    string Nick,
    int IdPerfil,
    string NombrePerfil,
    string Rol,
    int IdGrupo,
    string Divisa,
    LimitesVentaDto Limites,
    ConfigImpresoraDto Impresora);

public sealed record LoginResponse(string AccessToken, DateTimeOffset ExpiraEn, UsuarioDto Usuario);

/// <summary>
/// Datos del usuario tal como los devuelve SPverfLog. La clave almacenada NUNCA sale de la API
/// (en el sistema original viajaba al equipo cliente y se comparaba alli).
/// </summary>
public sealed record UsuarioPerfil(
    int IdUsuario,
    string Nick,
    string ClaveAlmacenada,
    int IdEstado,
    int IdPerfil,
    string NombrePerfil,
    int IdGrupo,
    string Divisa,
    LimitesVentaDto Limites,
    ConfigImpresoraDto Impresora)
{
    public const int EstadoActivo = 1;

    public bool Activo => IdEstado == EstadoActivo;

    public UsuarioDto ToDto() => new(
        IdUsuario, Nick, IdPerfil, NombrePerfil, Perfiles.Rol(IdPerfil), IdGrupo, Divisa, Limites, Impresora);
}

public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    [Required]
    public string Emisor { get; set; } = "Animalitos.Api";

    [Required]
    public string Audiencia { get; set; } = "Animalitos.Web";

    /// <summary>Clave HMAC de al menos 32 caracteres. Configurar con user-secrets o variable de entorno.</summary>
    [Required, MinLength(32)]
    public string ClaveFirma { get; set; } = string.Empty;

    /// <summary>Duracion del token. Por defecto un turno de taquilla (12 horas).</summary>
    [Range(5, 1440)]
    public int MinutosExpiracion { get; set; } = 720;
}

public sealed class SecurityOptions
{
    public const string SectionName = "Seguridad";

    /// <summary>
    /// Formato con que se guardan las claves nuevas o cambiadas:
    /// "TextoPlano" (compatible con el sistema WinForms mientras siga en uso) o "Hash"
    /// (PBKDF2 de ASP.NET Core Identity). El login acepta ambos formatos siempre.
    /// </summary>
    public string AlmacenamientoClaves { get; set; } = "TextoPlano";

    /// <summary>
    /// Si es true, al iniciar sesion con una clave en texto plano se reemplaza por su hash.
    /// IMPORTANTE: requiere que la columna usuario.clave admita 100+ caracteres y que el
    /// sistema WinForms ya no se use (el WinForms compara en texto plano).
    /// </summary>
    public bool MigrarClavesAlIniciarSesion { get; set; }

    [Range(3, 20)]
    public int IntentosFallidosPermitidos { get; set; } = 5;

    [Range(1, 120)]
    public int MinutosBloqueo { get; set; } = 5;

    [Range(8, 64)]
    public int LongitudMinimaClave { get; set; } = 8;

    public bool GuardarComoHash => string.Equals(AlmacenamientoClaves, "Hash", StringComparison.OrdinalIgnoreCase);
}
