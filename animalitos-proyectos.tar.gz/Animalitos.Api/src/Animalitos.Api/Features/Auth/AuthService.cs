using Animalitos.Api.Features.Sistema;
using Microsoft.Extensions.Options;

namespace Animalitos.Api.Features.Auth;

/// <summary>
/// Inicio de sesion y cambio de clave (antes: frm_login y frm_cambio_clave).
/// La verificacion por MAC del equipo se elimino para la version web.
/// </summary>
public sealed class AuthService(
    UsuarioRepository usuarios,
    PasswordService passwords,
    LoginAttemptTracker intentos,
    TokenService tokens,
    IOptions<SecurityOptions> securityOptions,
    ILogger<AuthService> logger)
{
    private const string MensajeCredenciales = "Usuario o clave invalidos.";

    public async Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct)
    {
        var nick = Guard.NotEmpty(request.Usuario, "usuario");
        Guard.Against(string.IsNullOrEmpty(request.Clave), "Ingrese la clave del usuario.");

        if (intentos.TiempoBloqueoRestante(nick) is { } restante)
        {
            throw new BusinessRuleException(
                $"Usuario bloqueado temporalmente por intentos fallidos. Intente en {Math.Ceiling(restante.TotalMinutes)} minuto(s).",
                StatusCodes.Status429TooManyRequests,
                "usuario_bloqueado");
        }

        var usuario = await usuarios.ObtenerPorNickAsync(nick, ct);
        if (usuario is null)
        {
            intentos.RegistrarFallo(nick);
            throw BusinessRuleException.Unauthorized(MensajeCredenciales, "credenciales_invalidas");
        }

        var verificacion = passwords.Verificar(usuario.ClaveAlmacenada, request.Clave);
        if (!verificacion.Valida)
        {
            intentos.RegistrarFallo(nick);
            logger.LogWarning("Intento de inicio de sesion fallido para {Usuario}", nick);
            throw BusinessRuleException.Unauthorized(MensajeCredenciales, "credenciales_invalidas");
        }

        if (!usuario.Activo)
        {
            throw BusinessRuleException.Forbidden(
                "Usuario inactivo. Contacte con el administrador del sistema.", "usuario_inactivo");
        }

        intentos.Reiniciar(nick);

        if (verificacion.EstaEnTextoPlano && securityOptions.Value.MigrarClavesAlIniciarSesion)
        {
            await MigrarClaveAsync(usuario.IdUsuario, request.Clave, ct);
        }

        var token = tokens.Emitir(usuario);
        logger.LogInformation("Inicio de sesion de {Usuario} (perfil {Perfil})", usuario.Nick, usuario.IdPerfil);
        return new LoginResponse(token.Token, token.ExpiraEn, usuario.ToDto());
    }

    public async Task<UsuarioDto> ObtenerPerfilAsync(ClaimsPrincipal user, CancellationToken ct)
    {
        var usuario = await usuarios.ObtenerPorNickAsync(user.Nick(), ct)
                      ?? throw BusinessRuleException.Unauthorized("Sesion invalida.");

        if (usuario.IdUsuario != user.IdUsuario())
        {
            throw BusinessRuleException.Unauthorized("Sesion invalida.");
        }

        if (!usuario.Activo)
        {
            throw BusinessRuleException.Forbidden("Usuario inactivo. Contacte con el administrador del sistema.", "usuario_inactivo");
        }

        return usuario.ToDto();
    }

    public async Task CambiarClaveAsync(ClaimsPrincipal user, CambiarClaveRequest request, CancellationToken ct)
    {
        var minimo = securityOptions.Value.LongitudMinimaClave;
        Guard.Against(string.IsNullOrEmpty(request.ClaveActual), "Ingrese su clave actual.");
        Guard.Against(string.IsNullOrEmpty(request.ClaveNueva) || request.ClaveNueva.Length < minimo,
            $"La clave nueva debe tener minimo {minimo} caracteres.");
        Guard.Against(request.ClaveNueva != request.ConfirmarClave, "La clave nueva y su confirmacion no coinciden.");
        Guard.Against(request.ClaveActual == request.ClaveNueva, "La clave nueva debe ser diferente a la actual.");

        var idUsuario = user.IdUsuario();
        var almacenada = await usuarios.ObtenerClaveAsync(idUsuario, ct)
                         ?? throw BusinessRuleException.NotFound("Usuario no encontrado.");

        if (!passwords.Verificar(almacenada, request.ClaveActual).Valida)
        {
            throw new BusinessRuleException("La clave actual es incorrecta.", StatusCodes.Status400BadRequest, "clave_actual_invalida");
        }

        var filas = await usuarios.ActualizarClaveAsync(idUsuario, passwords.PrepararParaGuardar(request.ClaveNueva), ct);
        if (filas < 1)
        {
            throw BusinessRuleException.Conflict("No fue posible actualizar la clave.");
        }

        logger.LogInformation("Cambio de clave del usuario {IdUsuario}", idUsuario);
    }

    private async Task MigrarClaveAsync(int idUsuario, string clave, CancellationToken ct)
    {
        try
        {
            await usuarios.ActualizarClaveAsync(idUsuario, passwords.GenerarHash(clave), ct);
            logger.LogInformation("Clave del usuario {IdUsuario} migrada a hash", idUsuario);
        }
        catch (Exception ex)
        {
            // La migracion es opcional: si falla, el usuario sigue entrando con su clave actual.
            logger.LogWarning(ex, "No se pudo migrar la clave del usuario {IdUsuario}", idUsuario);
        }
    }
}
