namespace Animalitos.Api.Features.Auth;

public static class AuthEndpoints
{
    public const string LoginRateLimitPolicy = "login";

    public static IEndpointRouteBuilder MapAuthEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/auth").WithTags("Autenticacion");

        group.MapPost("/login", async (LoginRequest request, AuthService auth, CancellationToken ct)
                => await auth.LoginAsync(request, ct))
            .AllowAnonymous()
            .RequireRateLimiting(LoginRateLimitPolicy)
            .WithSummary("Inicia sesion y devuelve un JWT (sin verificacion de MAC).");

        group.MapGet("/me", async (ClaimsPrincipal user, AuthService auth, CancellationToken ct)
                => await auth.ObtenerPerfilAsync(user, ct))
            .RequireAuthorization()
            .WithSummary("Perfil, limites de venta e impresora del usuario autenticado.");

        group.MapPost("/cambiar-clave", async (CambiarClaveRequest request, ClaimsPrincipal user, AuthService auth, CancellationToken ct) =>
            {
                await auth.CambiarClaveAsync(user, request, ct);
                return Results.NoContent();
            })
            .RequireAuthorization()
            .WithSummary("Cambia la clave del usuario autenticado.");

        return app;
    }
}
