using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace Animalitos.Api.Features.Auth;

public sealed record VerificacionClave(bool Valida, bool EstaEnTextoPlano);

/// <summary>
/// Verificacion de claves. Acepta claves en texto plano (formato actual de la BD, usado por el
/// WinForms) y hashes PBKDF2 de ASP.NET Core Identity, para poder migrar sin cortar el servicio.
/// </summary>
public sealed class PasswordService(IOptions<SecurityOptions> options)
{
    private static readonly PasswordHasher<object> Hasher = new();
    private static readonly object Usuario = new();

    public static bool EsHash(string almacenada)
        => almacenada.Length >= 60 && almacenada.StartsWith("AQAAAA", StringComparison.Ordinal);

    public VerificacionClave Verificar(string almacenada, string proporcionada)
    {
        if (string.IsNullOrEmpty(almacenada) || string.IsNullOrEmpty(proporcionada))
        {
            return new VerificacionClave(false, false);
        }

        if (EsHash(almacenada))
        {
            var resultado = Hasher.VerifyHashedPassword(Usuario, almacenada, proporcionada);
            return new VerificacionClave(resultado != PasswordVerificationResult.Failed, false);
        }

        // Comparacion en tiempo constante (evita ataques de temporizacion).
        var ok = CryptographicOperations.FixedTimeEquals(
            Encoding.UTF8.GetBytes(almacenada),
            Encoding.UTF8.GetBytes(proporcionada));

        return new VerificacionClave(ok, true);
    }

    /// <summary>Valor a guardar en la BD segun Seguridad:AlmacenamientoClaves.</summary>
    public string PrepararParaGuardar(string clave)
        => options.Value.GuardarComoHash ? Hasher.HashPassword(Usuario, clave) : clave;

    public string GenerarHash(string clave) => Hasher.HashPassword(Usuario, clave);
}

/// <summary>Bloqueo temporal por usuario tras varios intentos fallidos de inicio de sesion.</summary>
public sealed class LoginAttemptTracker(IMemoryCache cache, IOptions<SecurityOptions> options, TimeProvider time)
{
    private sealed class Estado
    {
        public int Fallos;
        public DateTimeOffset? BloqueadoHasta;
    }

    public TimeSpan? TiempoBloqueoRestante(string nick)
    {
        if (!cache.TryGetValue(Clave(nick), out Estado? estado) || estado is null)
        {
            return null;
        }

        lock (estado)
        {
            var ahora = time.GetUtcNow();
            return estado.BloqueadoHasta is { } hasta && hasta > ahora ? hasta - ahora : null;
        }
    }

    public void RegistrarFallo(string nick)
    {
        var o = options.Value;
        var estado = cache.GetOrCreate(Clave(nick), entry =>
        {
            entry.SlidingExpiration = TimeSpan.FromMinutes(Math.Max(o.MinutosBloqueo, 15));
            return new Estado();
        })!;

        lock (estado)
        {
            estado.Fallos++;
            if (estado.Fallos >= o.IntentosFallidosPermitidos)
            {
                estado.BloqueadoHasta = time.GetUtcNow().AddMinutes(o.MinutosBloqueo);
                estado.Fallos = 0;
            }
        }
    }

    public void Reiniciar(string nick) => cache.Remove(Clave(nick));

    private static string Clave(string nick) => "login:" + nick.Trim().ToUpperInvariant();
}
