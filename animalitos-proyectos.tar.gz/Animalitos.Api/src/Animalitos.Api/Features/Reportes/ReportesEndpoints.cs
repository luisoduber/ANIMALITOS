using Animalitos.Api.Features.Sistema;

namespace Animalitos.Api.Features.Reportes;

public sealed record ResumenTotalesTaquillaDto(decimal Entradas, decimal Salidas, decimal Taquilla, decimal Utilidad);

public sealed record TotalesTaquillaDto(TablaDto Detalle, ResumenTotalesTaquillaDto Resumen);

public sealed record DesgloseDto(decimal Total, decimal Animalitos, decimal Tripletas);

/// <summary>Resumen de ventas (spVerfVentTaq / spVerfVentLot).</summary>
public sealed record ResumenVentasDto(DesgloseDto Ventas, DesgloseDto Premios, DesgloseDto Anulados, DesgloseDto Utilidad);

public static class ReportesEndpoints
{
    public static IEndpointRouteBuilder MapReportesEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/reportes").WithTags("Reportes").RequireAuthorization();

        // -------------------------------------------------- Taquilla (frm_totales_venta_taq)
        group.MapGet("/totales-taquilla", async (DateOnly? desde, DateOnly? hasta, ClaimsPrincipal user, ISqlExecutor db, SistemaRepository sistema, CancellationToken ct) =>
            {
                var idUsuario = user.IdUsuario();
                var hoy = DateOnly.FromDateTime(await sistema.ObtenerFechaHoraServidorAsync(ct));
                var ini = desde ?? hoy;
                var fin = hasta ?? hoy;
                Guard.DateRange(ini, fin);

                var filtro = new SpParameters
                {
                    ["prm_id_usuario"] = idUsuario,
                    ["prm_fecha_ini"] = Fecha(ini),
                    ["prm_fecha_fin"] = Fecha(fin)
                };

                var detalle = desde is null && hasta is null
                    ? await db.QueryTablaAsync("SP_bus_totales_taq", new SpParameters { ["prm_id_usuario"] = idUsuario }, ct)
                    : await db.QueryTablaAsync("SP_bus_totales_taq_Xfiltro", filtro, ct);

                var r = await db.QueryFirstAsync("SP_bus_totales_ventas_taq", filtro, ct);
                var resumen = new ResumenTotalesTaquillaDto(
                    r?.GetDecimal("monto_entrada") ?? 0m,
                    r?.GetDecimal("monto_salida") ?? 0m,
                    r?.GetDecimal("monto_taq") ?? 0m,
                    r?.GetDecimal("monto_utilidad") ?? 0m);

                return new TotalesTaquillaDto(detalle, resumen);
            })
            .WithSummary("Cuadre de la taquilla: detalle diario y resumen de entradas/salidas.");

        // -------------------------------------------------- Ventas por taquilla / loteria (frmVentLot)
        group.MapGet("/ventas", async (string? modo, int? idGrupo, int? idTaquilla, int? idLoteria, DateOnly? desde, DateOnly? hasta,
                ClaimsPrincipal user, ISqlExecutor db, SistemaRepository sistema, CancellationToken ct) =>
            {
                var hoy = DateOnly.FromDateTime(await sistema.ObtenerFechaHoraServidorAsync(ct));
                var ini = desde ?? hoy;
                var fin = hasta ?? hoy;
                Guard.DateRange(ini, fin);

                // La taquilla solo puede consultar sus propias ventas.
                var esTaquilla = user.IdPerfil() == Perfiles.Taquilla;
                var grupo = esTaquilla ? user.IdGrupo() : user.ResolverGrupo(idGrupo);
                var taquilla = esTaquilla ? user.IdUsuario() : idTaquilla ?? 0;

                var procedure = string.Equals(modo, "loteria", StringComparison.OrdinalIgnoreCase) ? "spVerfVentLot" : "spVerfVentTaq";
                var r = await db.QueryFirstAsync(procedure, new SpParameters
                {
                    ["prmIdGrup"] = grupo,
                    ["prmIdUsu"] = taquilla,
                    ["prmIdLot"] = idLoteria ?? 0,
                    ["prmFechIni"] = Fecha(ini),
                    ["prmFechFin"] = Fecha(fin)
                }, ct);

                DesgloseDto D(string total, string an, string trip) => new(
                    r?.GetDecimal(total) ?? 0m, r?.GetDecimal(an) ?? 0m, r?.GetDecimal(trip) ?? 0m);

                return new ResumenVentasDto(
                    D("prmMVent", "prmMVentAn", "prmMVentTrip"),
                    D("prmMPre", "prmMPreAn", "prmMPreTrip"),
                    D("prmMAn", "prmMAnAn", "prmMAnTrip"),
                    D("prmMUt", "prmMUtAn", "prmMUtTrip"));
            })
            .WithSummary("Ventas, premios, anulados y utilidad por taquilla (modo=taquilla) o por loteria (modo=loteria).");

        group.MapGet("/ventas/loterias", async (int? idTaquilla, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                var taquilla = user.IdPerfil() == Perfiles.Taquilla ? user.IdUsuario() : idTaquilla ?? user.IdUsuario();
                return await db.QueryTablaAsync("spListLotTod", new SpParameters { ["prmIdUsu"] = taquilla }, ct);
            })
            .WithSummary("Loterias de una taquilla para el filtro de ventas (spListLotTod).");

        // -------------------------------------------------- Administracion
        var admin = group.MapGroup("/admin").RequireAuthorization(Politicas.Admin);

        admin.MapGet("/cuadre-taquillas", async (int? idGrupo, int idTaquilla, int idDivisa, DateOnly desde, DateOnly hasta,
                ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                Guard.DateRange(desde, hasta);
                return await db.QueryTablaAsync("spBusTotGrupoTaqXDivisa", new SpParameters
                {
                    ["prmIdGrupo"] = user.ResolverGrupo(idGrupo),
                    ["prmIdUsuario"] = idTaquilla,
                    ["prmIdDivisa"] = idDivisa,
                    ["prmFechaIni"] = Fecha(desde),
                    ["prmFechaFin"] = Fecha(hasta)
                }, ct);
            })
            .WithSummary("Cuadre de taquillas por divisa (spBusTotGrupoTaqXDivisa).");

        admin.MapGet("/cuadre-general", async (int? idGrupo, int idDivisa, DateOnly desde, DateOnly hasta,
                ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                Guard.DateRange(desde, hasta);
                var todos = idGrupo is 0 && user.EsSuperAdmin();
                var grupo = todos ? 0 : user.ResolverGrupo(idGrupo);
                return await db.QueryTablaAsync(todos ? "SPBusTotGrupTod" : "SPBusTotGrup", new SpParameters
                {
                    ["prmIdgrup"] = grupo,
                    ["prmIdDiv"] = idDivisa,
                    ["prmFechIni"] = Fecha(desde),
                    ["prmFechFin"] = Fecha(hasta)
                }, ct);
            })
            .WithSummary("Cuadre general por grupo (SPBusTotGrup) o de todos los grupos (SPBusTotGrupTod, solo super administrador).");

        admin.MapGet("/totales-grupo", async (int? idGrupo, int? idTaquilla, DateOnly? desde, DateOnly? hasta,
                ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                var grupo = user.ResolverGrupo(idGrupo);
                if (desde is null || hasta is null)
                {
                    return await db.QueryTablaAsync("SP_bus_totales_grupo_taq", new SpParameters
                    {
                        ["prm_id_grupo"] = grupo,
                        ["prm_id_usuario"] = idTaquilla ?? 0
                    }, ct);
                }

                Guard.DateRange(desde.Value, hasta.Value);
                return await db.QueryTablaAsync("SP_bus_totales_grupo_taq_Xfiltro", new SpParameters
                {
                    ["prm_id_grupo"] = grupo,
                    ["prm_id_usuario"] = idTaquilla ?? 0,
                    ["prm_fecha_ini"] = Fecha(desde.Value),
                    ["prm_fecha_fin"] = Fecha(hasta.Value)
                }, ct);
            })
            .WithSummary("Totales de las taquillas del grupo (SP_bus_totales_grupo_taq / _Xfiltro).");

        admin.MapGet("/control-ventas/{idLoteria:int}", async (int idLoteria, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spContVentTaq", new SpParameters { ["prmIdLot"] = idLoteria }, ct))
            .WithSummary("Control de ventas por producto de una loteria (spContVentTaq).");

        admin.MapGet("/control-ventas/loterias/{idTaquilla:int}", async (int idTaquilla, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("splistLotContVent", new SpParameters { ["prmIdUsu"] = idTaquilla }, ct))
            .WithSummary("Loterias para el control de ventas (splistLotContVent).");

        admin.MapGet("/control-ventas/sorteos/{idLoteria:int}", async (int idLoteria, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spListSortContVentTod", new SpParameters { ["prmIdLot"] = idLoteria }, ct))
            .WithSummary("Sorteos para el control de ventas (spListSortContVentTod).");

        return app;
    }

    private static string Fecha(DateOnly fecha) => fecha.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
}
