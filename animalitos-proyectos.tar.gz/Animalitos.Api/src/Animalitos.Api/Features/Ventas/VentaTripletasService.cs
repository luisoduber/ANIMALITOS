using Animalitos.Api.Features.Auth;
using Animalitos.Api.Features.Catalogo;
using Animalitos.Api.Features.Sistema;

namespace Animalitos.Api.Features.Ventas;

/// <summary>
/// Venta de tripletas (migrado de frmTrip.btnImpTck_Click). Toda la venta ocurre en una sola
/// transaccion: SPgrdTckTrip (cabecera) + SPdetTckTrip por tripleta + spActMontTck si el monto
/// cambio por cupos.
/// </summary>
public sealed class VentaTripletasService(
    ISqlExecutor db,
    UsuarioRepository usuarios,
    SistemaRepository sistema,
    CatalogoRepository catalogo,
    ILogger<VentaTripletasService> logger)
{
    private const int MaximoTripletasPorTicket = 100;

    // Respuestas de SPdetTckTrip (prmValTrip)
    private const int CupoAgotado = 2;
    private const int CupoDisponible = 3;

    private sealed class Candidata(TripletaRequest origen, LoteriaTripletaDto loteria, string[] codigos, string[] productos, decimal monto)
    {
        public TripletaRequest Origen { get; } = origen;
        public LoteriaTripletaDto Loteria { get; } = loteria;
        public string[] Codigos { get; } = codigos;
        public string[] Productos { get; } = productos;
        public decimal Monto { get; set; } = monto;
    }

    public async Task<VentaTripletasResultadoDto> VenderAsync(ClaimsPrincipal user, VentaTripletasRequest request, CancellationToken ct)
    {
        Guard.Against(request?.Tripletas is null || request.Tripletas.Count == 0, "No hay tripletas para procesar.");
        Guard.Against(request!.Tripletas.Count > MaximoTripletasPorTicket, $"Un ticket admite maximo {MaximoTripletasPorTicket} tripletas.");

        var idUsuario = user.IdUsuario();
        var idGrupo = user.IdGrupo();

        var perfil = await usuarios.ObtenerPorNickAsync(user.Nick(), ct);
        if (perfil is null || perfil.IdUsuario != idUsuario)
        {
            throw BusinessRuleException.Unauthorized("Sesion invalida.");
        }

        if (!perfil.Activo || !(await sistema.ObtenerEstadoTaquillaAsync(idUsuario, ct)).Activa)
        {
            throw BusinessRuleException.Forbidden("Usuario inactivo. Contacte con el administrador del sistema.", "usuario_inactivo");
        }

        var limites = perfil.Limites;
        var loterias = (await catalogo.ListarLoteriasTripletaAsync(idUsuario, ct))
            .GroupBy(l => l.IdLoteria)
            .ToDictionary(g => g.Key, g => g.First());

        var productos = new Dictionary<(int, string), string>();
        foreach (var p in await catalogo.ListarProductosAsync(ct))
        {
            productos.TryAdd((p.IdLoteria, Codigos.Normalizar(p.Codigo)), p.Nombre.ToUpperInvariant());
        }

        var procesadas = new List<TripletaProcesadaDto>();
        var candidatas = new List<Candidata>();

        foreach (var t in request.Tripletas)
        {
            var codigos = new[] { Codigos.Normalizar(t.Codigo1), Codigos.Normalizar(t.Codigo2), Codigos.Normalizar(t.Codigo3) };
            loterias.TryGetValue(t.IdLoteria, out var loteria);
            var nombres = codigos.Select(c => productos.GetValueOrDefault((t.IdLoteria, c), string.Empty)).ToArray();

            string? motivo = null;
            if (loteria is null)
            {
                motivo = "La loteria no esta habilitada para tripletas.";
            }
            else if (codigos.Any(c => !Codigos.EsValido(c)))
            {
                motivo = "Los tres codigos son requeridos y deben ser numericos.";
            }
            else if (codigos.FirstOrDefault(c => Codigos.Valor(c) > loteria.CodigoMaximo) is { } invalido)
            {
                motivo = $"Codigo \"{invalido}\" invalido para la loteria \"{loteria.Nombre.ToUpperInvariant()}\".";
            }
            else if (codigos.Distinct(StringComparer.Ordinal).Count() != 3)
            {
                motivo = "Los tres animalitos de la tripleta deben ser diferentes.";
            }
            else if (nombres.Any(string.IsNullOrEmpty))
            {
                motivo = "Uno de los codigos no existe para la loteria seleccionada.";
            }
            else if (t.Monto <= 0 || t.Monto < limites.MontoMinJugada)
            {
                motivo = $"El monto minimo de la tripleta debe ser: {Formato.Monto(limites.MontoMinJugada)}.";
            }
            else if (limites.MontoMaxTripleta > 0 && t.Monto > limites.MontoMaxTripleta)
            {
                motivo = $"El maximo por tripleta debe ser: {Formato.Monto(limites.MontoMaxTripleta)}.";
            }

            if (motivo is not null)
            {
                procesadas.Add(Rechazada(t, loteria, codigos, nombres, t.Monto, motivo));
                continue;
            }

            var existente = candidatas.Find(c => c.Loteria.IdLoteria == t.IdLoteria && c.Codigos.SequenceEqual(codigos));
            if (existente is not null)
            {
                var suma = existente.Monto + t.Monto;
                existente.Monto = limites.MontoMaxTripleta > 0 ? Math.Min(suma, limites.MontoMaxTripleta) : suma;
            }
            else
            {
                candidatas.Add(new Candidata(t, loteria!, codigos, nombres, t.Monto));
            }
        }

        var mensajes = new List<string>();
        if (candidatas.Count == 0)
        {
            mensajes.Add("Ninguna tripleta es valida. No se genero ticket.");
            mensajes.AddRange(procesadas.Where(p => p.Mensaje is not null).Select(p => p.Mensaje!));
            return new VentaTripletasResultadoDto(false, null, procesadas, mensajes.Distinct().ToList());
        }

        var totalSolicitado = candidatas.Sum(c => c.Monto);

        await using var tx = await db.BeginTransactionAsync(ct);

        var cabecera = await tx.QueryFirstAsync("SPgrdTckTrip", new SpParameters
        {
            ["prmIdGrup"] = idGrupo,
            ["prmIdUsu"] = idUsuario,
            ["prmMont"] = totalSolicitado
        }, ct) ?? throw new InvalidOperationException("SPgrdTckTrip no devolvio la cabecera del ticket.");

        var nroTicket = cabecera.Get("prmNroTck");
        var idTicket = cabecera.Get("prmIdTck");
        var aceptadas = new List<(Candidata Tripleta, decimal Monto, string Desde, string Hasta)>();

        foreach (var c in candidatas)
        {
            var detalle = await tx.QueryFirstAsync("SPdetTckTrip", new SpParameters
            {
                ["prmNroTck"] = nroTicket,
                ["prmIdGrup"] = idGrupo,
                ["prmIdUsu"] = idUsuario,
                ["prmIdLot"] = c.Loteria.IdLoteria,
                ["prmCodJug1"] = c.Codigos[0],
                ["prmNombProd1"] = c.Productos[0],
                ["prmCodJug2"] = c.Codigos[1],
                ["prmNombProd2"] = c.Productos[1],
                ["prmCodJug3"] = c.Codigos[2],
                ["prmNombProd3"] = c.Productos[2],
                ["prmMont"] = c.Monto
            }, ct);

            var respuesta = detalle?.GetInt32("prmValTrip") ?? -1;
            var montoBd = detalle?.GetDecimal("prmMont") ?? 0m;
            var desde = detalle?.GetString("prmFechSortIni") ?? string.Empty;
            var hasta = detalle?.GetString("prmFechSortFin") ?? string.Empty;
            var descripcion = $"{c.Codigos[0]} - {c.Productos[0]} / {c.Codigos[1]} - {c.Productos[1]} / {c.Codigos[2]} - {c.Productos[2]}";
            var loteria = c.Loteria.Nombre.ToUpperInvariant();

            if (respuesta == CupoDisponible && montoBd > 0)
            {
                var ajustada = montoBd != c.Monto;
                procesadas.Add(new TripletaProcesadaDto(
                    c.Loteria.IdLoteria, c.Loteria.Nombre, c.Codigos[0], c.Codigos[1], c.Codigos[2], c.Productos,
                    c.Monto, montoBd, desde, hasta,
                    ajustada ? EstadosJugada.Ajustada : EstadosJugada.Aceptada,
                    ajustada ? $"El cupo disponible para la tripleta {descripcion} es de: {Formato.Monto(montoBd)} (loteria \"{loteria}\")." : null));
                aceptadas.Add((c, montoBd, desde, hasta));
            }
            else
            {
                var motivo = respuesta == CupoAgotado || respuesta == CupoDisponible
                    ? $"Cupo agotado para la tripleta {descripcion} (loteria \"{loteria}\")."
                    : $"La tripleta {descripcion} no pudo procesarse (respuesta {respuesta}).";
                procesadas.Add(Rechazada(c.Origen, c.Loteria, c.Codigos, c.Productos, c.Monto, motivo));
            }
        }

        mensajes.AddRange(procesadas.Where(p => p.Mensaje is not null).Select(p => p.Mensaje!));

        if (aceptadas.Count == 0)
        {
            await tx.RollbackAsync(ct);
            return new VentaTripletasResultadoDto(false, null, procesadas, mensajes.Distinct().ToList());
        }

        var total = aceptadas.Sum(a => a.Monto);
        if (total != totalSolicitado)
        {
            await tx.ExecuteAsync("spActMontTck", new SpParameters
            {
                ["prmIdTck"] = idTicket,
                ["prmMont"] = total
            }, ct);
        }

        await tx.CommitAsync(ct);

        var parametros = await sistema.ObtenerParametrosAsync(ct);
        var ahora = await sistema.ObtenerFechaHoraServidorAsync(ct);

        var ticket = new TicketImpresionDto(
            Tipo: TicketImpresionDto.TipoTripleta,
            Taquilla: perfil.Nick.ToUpperInvariant(),
            Divisa: perfil.Divisa.ToUpperInvariant(),
            NumeroTicket: DbConvert.ToText(nroTicket),
            Serial: cabecera.GetString("prmNroSer"),
            Fecha: Formato.Fecha(cabecera.GetDateTime("fechTck") ?? ahora),
            Hora: Formato.Hora12(cabecera.GetTimeOfDay("horTck") ?? ahora.TimeOfDay),
            Grupos: [],
            Tripletas: aceptadas
                .Select(a => new TicketTripletaDto(a.Tripleta.Loteria.Nombre.ToUpperInvariant(), a.Desde, a.Hasta, a.Tripleta.Productos, a.Monto))
                .ToList(),
            Total: total,
            DiasCaducidad: parametros.DiasCaducidadTicket,
            SorteosTripleta: parametros.SorteosTripleta,
            Nota: parametros.NotaTicket,
            Reimpresion: false);

        logger.LogInformation(
            "Ticket de tripletas {Ticket} vendido por {Usuario}: {Cantidad} tripletas, total {Total}",
            ticket.NumeroTicket, perfil.Nick, aceptadas.Count, total);

        return new VentaTripletasResultadoDto(true, ticket, procesadas, mensajes.Distinct().ToList());
    }

    private static TripletaProcesadaDto Rechazada(
        TripletaRequest t, LoteriaTripletaDto? loteria, string[] codigos, string[] productos, decimal monto, string motivo)
        => new(
            t.IdLoteria,
            loteria?.Nombre ?? string.Empty,
            codigos.ElementAtOrDefault(0) ?? string.Empty,
            codigos.ElementAtOrDefault(1) ?? string.Empty,
            codigos.ElementAtOrDefault(2) ?? string.Empty,
            productos,
            monto,
            0m,
            null,
            null,
            EstadosJugada.Rechazada,
            motivo);
}
