namespace Animalitos.Api.Features.Ventas;

public static class VentasEndpoints
{
    public static IEndpointRouteBuilder MapVentasEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/ventas").WithTags("Ventas").RequireAuthorization();

        group.MapPost("/animalitos", async (VentaAnimalitosRequest request, ClaimsPrincipal user, VentaAnimalitosService service, CancellationToken ct)
                => await service.VenderAsync(user, request, ct))
            .WithSummary("Registra un ticket de animalitos en una transaccion y devuelve los datos para imprimir.");

        group.MapPost("/tripletas", async (VentaTripletasRequest request, ClaimsPrincipal user, VentaTripletasService service, CancellationToken ct)
                => await service.VenderAsync(user, request, ct))
            .WithSummary("Registra un ticket de tripletas en una transaccion y devuelve los datos para imprimir.");

        group.MapGet("/totales-dia", async (ClaimsPrincipal user, VentasConsultasService service, CancellationToken ct)
                => await service.TotalesDiaAsync(user.IdUsuario(), ct))
            .WithSummary("Totales del dia de la taquilla: ventas, animalitos, tripletas, pagados, anulados, caja y ultimo ticket.");

        group.MapGet("/reimprimir", async (ClaimsPrincipal user, VentasConsultasService service, CancellationToken ct)
                => await service.ReimprimirUltimoAsync(user, ct))
            .WithSummary("Datos del ultimo ticket para reimprimir (si esta dentro del tiempo permitido).");

        group.MapPost("/repetir", async (RepetirTicketRequest request, ClaimsPrincipal user, VentasConsultasService service, CancellationToken ct)
                => await service.RepetirAsync(user, request, ct))
            .WithSummary("Carga las jugadas de un ticket anterior en los sorteos seleccionados.");

        return app;
    }
}
