using Animalitos.Api.Features.Auth;
using Animalitos.Api.Features.Catalogo;
using Animalitos.Api.Features.Sistema;

namespace Animalitos.Api.Features.Ventas;

/// <summary>Totales del dia, reimpresion y repeticion de tickets (pantalla de venta).</summary>
public sealed class VentasConsultasService(
    ISqlExecutor db,
    UsuarioRepository usuarios,
    SistemaRepository sistema,
    CatalogoRepository catalogo)
{
    /// <summary>SPbusCuadCajDia: panel de totales que se refresca con cada venta, pago o anulacion.</summary>
    public async Task<TotalesDiaDto> TotalesDiaAsync(int idUsuario, CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("SPbusCuadCajDia", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);
        if (row is null)
        {
            return new TotalesDiaDto(0, 0, 0, 0, 0, 0, string.Empty);
        }

        return new TotalesDiaDto(
            Ventas: row.GetDecimal("prmTotVent"),
            VentasAnimalitos: row.GetDecimal("prmTotVentAn"),
            VentasTripletas: row.GetDecimal("prmTotVentTrip"),
            Pagados: row.GetDecimal("prmTotPag"),
            Anulados: row.GetDecimal("prmTotTckAn"),
            TotalCaja: row.GetDecimal("prmTotCaj"),
            UltimoTicket: row.GetString("prmUltTck"));
    }

    /// <summary>
    /// Reimpresion del ultimo ticket del dia (SPinfReimpTck + SPreimpTck), respetando el tiempo
    /// maximo de reimpresion configurado en la BD.
    /// </summary>
    public async Task<TicketImpresionDto> ReimprimirUltimoAsync(ClaimsPrincipal user, CancellationToken ct)
    {
        var idUsuario = user.IdUsuario();
        var info = await db.QueryFirstAsync("SPinfReimpTck", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);

        if (info is null || info.GetInt32("prmCantTck") == 0)
        {
            throw BusinessRuleException.NotFound("No se ha procesado ningun ticket el dia de hoy para reimprimir.", "sin_tickets");
        }

        if (info.GetInt32("prmPermitReimp") == 0)
        {
            throw BusinessRuleException.Conflict(
                $"No se podra reimprimir el ultimo ticket. Tiempo maximo de reimpresion: {info.GetInt32("prmCantMinReimp")} minutos.",
                "reimpresion_vencida");
        }

        var nroTicket = info.GetString("prmNroTck");
        var detalle = await db.QueryAsync("SPreimpTck", new SpParameters
        {
            ["prmIdUsu"] = idUsuario,
            ["prmNroTck"] = nroTicket
        }, ct);

        var perfil = await usuarios.ObtenerPorNickAsync(user.Nick(), ct);
        var parametros = await sistema.ObtenerParametrosAsync(ct);

        var grupos = detalle
            .GroupBy(r => (IdLoteria: r.GetInt32("idLot"), IdSorteo: r.GetInt32("idSort")))
            .Select(g =>
            {
                var primero = g.First();
                return new TicketGrupoDto(
                    g.Key.IdLoteria,
                    g.Key.IdSorteo,
                    primero.GetString("nombLot").ToUpperInvariant(),
                    primero.GetString("nombSort").ToUpperInvariant(),
                    g.Select(r => new TicketJugadaDto(
                        Codigos.Normalizar(r.GetString("codJug")),
                        Codigos.Abreviar(r.GetString("nombProd")),
                        r.GetString("nombProd").ToUpperInvariant(),
                        r.GetDecimal("mont"))).ToList());
            })
            .ToList();

        return new TicketImpresionDto(
            Tipo: TicketImpresionDto.TipoAnimalitos,
            Taquilla: (perfil?.Nick ?? user.Nick()).ToUpperInvariant(),
            Divisa: (perfil?.Divisa ?? string.Empty).ToUpperInvariant(),
            NumeroTicket: nroTicket,
            Serial: info.GetString("prmNroSer"),
            Fecha: Formato.Fecha(info.GetDateTime("prmFech")),
            Hora: Formato.Hora12(info.GetTimeOfDay("prmHor")),
            Grupos: grupos,
            Tripletas: [],
            Total: info.GetDecimal("prmMtck"),
            DiasCaducidad: parametros.DiasCaducidadTicket,
            SorteosTripleta: parametros.SorteosTripleta,
            Nota: parametros.NotaTicket,
            Reimpresion: true);
    }

    /// <summary>
    /// Repetir ticket: carga las jugadas de un ticket anterior en los sorteos seleccionados
    /// (SP_verf_exist_repet_ticket + SP_bus_grd_det_ticket por sorteo + SP_bus_jugadas).
    /// Las jugadas NO se venden aqui: se devuelven para que la taquilla las revise e imprima.
    /// </summary>
    public async Task<IReadOnlyList<JugadaRepetidaDto>> RepetirAsync(ClaimsPrincipal user, RepetirTicketRequest request, CancellationToken ct)
    {
        var nroTicket = Guard.NotEmpty(request.NumeroTicket, "numeroTicket");
        Guard.Against(!long.TryParse(nroTicket, NumberStyles.None, CultureInfo.InvariantCulture, out var nro) || nro == 0,
            "Ingrese un numero de ticket valido y diferente de cero.");
        Guard.Against(request.Sorteos is null || request.Sorteos.Count == 0, "Elija una loteria y sorteo.");

        var idUsuario = user.IdUsuario();
        var existe = await db.QueryFirstAsync("SP_verf_exist_repet_ticket", new SpParameters
        {
            ["prm_id_usuario"] = idUsuario,
            ["prm_nro_ticket"] = nroTicket
        }, ct);

        if (existe is null || existe.GetInt32("exits_ticket") != 1)
        {
            throw BusinessRuleException.NotFound("El numero de ticket introducido no existe.", "ticket_no_existe");
        }

        // Los datos del sorteo se toman de la BD (no del cliente).
        var disponibles = (await catalogo.ListarSorteosVentaAsync(idUsuario, null, ct))
            .GroupBy(s => (s.IdLoteria, s.IdSorteo))
            .ToDictionary(g => g.Key, g => g.First());

        foreach (var seleccion in request.Sorteos!.DistinctBy(s => (s.IdLoteria, s.IdSorteo)))
        {
            if (!disponibles.TryGetValue((seleccion.IdLoteria, seleccion.IdSorteo), out var sorteo))
            {
                continue; // Sorteo cerrado o no disponible: se omite.
            }

            await db.QueryAsync("SP_bus_grd_det_ticket", new SpParameters
            {
                ["prm_nro_ticket"] = nroTicket,
                ["prm_id_loteria"] = sorteo.IdLoteria,
                ["prm_id_sorteo"] = sorteo.IdSorteo,
                ["prm_nomb_loteria"] = sorteo.NombreLoteria,
                ["prm_hora_sorteo"] = sorteo.HoraSorteo,
                ["prm_abrev_loteria"] = sorteo.AbreviaturaLoteria
            }, ct);
        }

        var jugadas = await db.QueryAsync("SP_bus_jugadas", new SpParameters { ["prm_nro_ticket"] = nroTicket }, ct);
        return jugadas.Select(r => new JugadaRepetidaDto(
                IdLoteria: r.GetInt32("id_loteria", "idLot"),
                IdSorteo: r.GetInt32("id_sorteo", "idSort"),
                NombreLoteria: r.GetString("nomb_loteria", "nombLot"),
                AbreviaturaLoteria: r.GetString("abrev_loteria", "abLot"),
                HoraSorteo: Formato.Hora24(r.GetTimeOfDay("hora_sorteo", "horaSort")),
                Codigo: Codigos.Normalizar(r.GetString("codigo_jugada", "codJug")),
                Producto: r.GetString("nomb_product", "nombProd"),
                Monto: r.GetDecimal("monto")))
            .Where(j => disponibles.ContainsKey((j.IdLoteria, j.IdSorteo)))
            .ToList();
    }
}
