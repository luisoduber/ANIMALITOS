using Animalitos.Api.Features.Auth;
using Animalitos.Api.Features.Catalogo;
using Animalitos.Api.Features.Sistema;

namespace Animalitos.Api.Features.Ventas;

/// <summary>
/// Venta de animalitos. Migrado de frm_ventas.btn_imprimir_ticket_Click, con estas reglas de
/// seguridad aplicadas en el servidor (antes solo estaban en la pantalla):
///  - La hora de cada sorteo se toma de la BD, no del cliente.
///  - Toda jugada cuyo sorteo ya llego a su hora (segun la hora del servidor devuelta por
///    SPgrdTck) se rechaza, aunque el cliente la envie.
///  - Se validan codigo maximo, monto minimo/maximo por jugada y maximo por ticket.
///  - La transaccion se confirma ANTES de imprimir (antes quedaba abierta durante la impresion).
/// </summary>
public sealed class VentaAnimalitosService(
    ISqlExecutor db,
    UsuarioRepository usuarios,
    SistemaRepository sistema,
    CatalogoRepository catalogo,
    ILogger<VentaAnimalitosService> logger)
{
    private const int MaximoJugadasPorTicket = 300;
    private const int TipoTicketAnimalitos = 1;

    // Respuestas de SP_det_ticket (prmGrd)
    private const int SorteoBloqueado = 0;
    private const int ProductoBloqueado = 1;
    private const int CupoAgotado = 2;
    private const int CupoDisponible = 3;

    private sealed class Candidata(JugadaRequest origen, SorteoVentaDto sorteo, string codigo, string producto, decimal monto)
    {
        public JugadaRequest Origen { get; } = origen;
        public SorteoVentaDto Sorteo { get; } = sorteo;
        public string Codigo { get; } = codigo;
        public string Producto { get; } = producto;
        public decimal Monto { get; set; } = monto;
    }

    public async Task<VentaAnimalitosResultadoDto> VenderAsync(ClaimsPrincipal user, VentaAnimalitosRequest request, CancellationToken ct)
    {
        Guard.Against(request?.Jugadas is null || request.Jugadas.Count == 0, "No hay jugadas para procesar.");
        Guard.Against(request!.Jugadas.Count > MaximoJugadasPorTicket, $"Un ticket admite maximo {MaximoJugadasPorTicket} jugadas.");

        var idUsuario = user.IdUsuario();
        var idGrupo = user.IdGrupo();
        var perfil = await ObtenerPerfilActivoAsync(user, ct);
        var limites = perfil.Limites;

        var sorteos = await CargarSorteosAsync(idUsuario, request.Jugadas, ct);
        var productos = await CargarProductosAsync(ct);

        var procesadas = new List<JugadaProcesadaDto>();
        var mensajes = new List<string>();
        var candidatas = new List<Candidata>();

        // 1) Validaciones y consolidacion (misma jugada repetida => se suma, tope por jugada).
        foreach (var jugada in request.Jugadas)
        {
            var codigo = Codigos.Normalizar(jugada.Codigo);
            sorteos.TryGetValue((jugada.IdLoteria, jugada.IdSorteo), out var sorteo);
            var producto = productos.GetValueOrDefault((jugada.IdLoteria, codigo), string.Empty);

            string? motivo = null;
            if (!Codigos.EsValido(codigo))
            {
                motivo = $"Codigo '{jugada.Codigo}' invalido.";
            }
            else if (sorteo is null)
            {
                motivo = "El sorteo no esta disponible o ya cerro.";
            }
            else if (Codigos.Valor(codigo) > sorteo.CodigoMaximo)
            {
                motivo = $"Codigo \"{codigo}\" invalido para la loteria \"{sorteo.NombreLoteria.ToUpperInvariant()}\".";
            }
            else if (jugada.Monto <= 0 || jugada.Monto < limites.MontoMinJugada)
            {
                motivo = $"El monto minimo de la jugada debe ser: {Formato.Monto(limites.MontoMinJugada)}.";
            }
            else if (limites.MontoMaxJugada > 0 && jugada.Monto > limites.MontoMaxJugada)
            {
                motivo = $"El maximo por jugada debe ser: {Formato.Monto(limites.MontoMaxJugada)}.";
            }

            if (motivo is not null)
            {
                procesadas.Add(Rechazada(jugada, sorteo, codigo, producto, motivo));
                continue;
            }

            var existente = candidatas.Find(c =>
                c.Sorteo.IdLoteria == jugada.IdLoteria && c.Sorteo.IdSorteo == jugada.IdSorteo && c.Codigo == codigo);

            if (existente is not null)
            {
                var suma = existente.Monto + jugada.Monto;
                existente.Monto = limites.MontoMaxJugada > 0 ? Math.Min(suma, limites.MontoMaxJugada) : suma;
            }
            else
            {
                candidatas.Add(new Candidata(jugada, sorteo!, codigo, producto, jugada.Monto));
            }
        }

        var totalSolicitado = candidatas.Sum(c => c.Monto);
        if (limites.MontoMaxTicket > 0 && totalSolicitado > limites.MontoMaxTicket)
        {
            throw new BusinessRuleException($"El maximo por ticket es de: {Formato.Monto(limites.MontoMaxTicket)}.", code: "maximo_ticket");
        }

        if (candidatas.Count == 0)
        {
            mensajes.Add("Ninguna jugada es valida. No se genero ticket.");
            return new VentaAnimalitosResultadoDto(false, null, procesadas, mensajes, false);
        }

        // Mismo orden en que la pantalla original mostraba e imprimia las jugadas.
        candidatas = candidatas
            .OrderByDescending(c => c.Sorteo.Hora)
            .ThenBy(c => c.Sorteo.IdSorteo)
            .ThenBy(c => c.Codigo, StringComparer.Ordinal)
            .ToList();

        // 2) Transaccion: cabecera, detalle por jugada y monto final.
        await using var tx = await db.BeginTransactionAsync(ct);

        var cabecera = await tx.QueryFirstAsync("SPgrdTck", new SpParameters
        {
            ["prmIdGrup"] = idGrupo,
            ["prmIdUsu"] = idUsuario,
            ["prmIdTipTck"] = TipoTicketAnimalitos
        }, ct) ?? throw new InvalidOperationException("SPgrdTck no devolvio la cabecera del ticket.");

        var nroTicket = cabecera.Get("prmContTck");
        var idTicket = cabecera.Get("prmIdTck");
        var fechaHoraVerificacion = cabecera.GetDateTime("fechaHoraVerf")
                                    ?? await sistema.ObtenerFechaHoraServidorAsync(ct);

        var aceptadas = new List<(Candidata Jugada, decimal Monto)>();
        var haySorteosCerrados = false;

        foreach (var c in candidatas)
        {
            var cierre = fechaHoraVerificacion.Date + c.Sorteo.Hora;
            if (fechaHoraVerificacion >= cierre)
            {
                haySorteosCerrados = true;
                procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto, "Sorteo cerrado, jugada no procesada.", c.Monto));
                continue;
            }

            var detalle = await tx.QueryFirstAsync("SP_det_ticket", new SpParameters
            {
                ["prmNroTck"] = nroTicket,
                ["prmIdGrup"] = idGrupo,
                ["prmIdUsu"] = idUsuario,
                ["prmIdLot"] = c.Sorteo.IdLoteria,
                ["prmIdSort"] = c.Sorteo.IdSorteo,
                ["prmCodJug"] = c.Codigo,
                ["prmMonto"] = c.Monto
            }, ct);

            var respuesta = detalle?.GetInt32("prmGrd") ?? -1;
            var montoBd = detalle?.GetDecimal("prmMonto") ?? 0m;
            var loteria = c.Sorteo.NombreLoteria.ToUpperInvariant();
            var productoTxt = $"{c.Codigo} - {c.Producto}".ToUpperInvariant();

            switch (respuesta)
            {
                case SorteoBloqueado:
                    procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto,
                        $"El sorteo \"{loteria} {Formato.Hora12(c.Sorteo.Hora)}\" se encuentra bloqueado.", c.Monto));
                    break;

                case ProductoBloqueado:
                    procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto,
                        $"El producto \"{productoTxt}\" se encuentra bloqueado para la loteria \"{loteria}\".", c.Monto));
                    break;

                case CupoAgotado:
                    procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto,
                        $"El cupo para el producto \"{productoTxt}\" se encuentra agotado para la loteria \"{loteria}\".", c.Monto));
                    break;

                case CupoDisponible when montoBd > 0:
                    var ajustada = montoBd != c.Monto;
                    var mensaje = ajustada
                        ? $"El cupo disponible para el producto \"{productoTxt}\" es de: {Formato.Monto(montoBd)} para la loteria \"{loteria}\"."
                        : null;
                    procesadas.Add(new JugadaProcesadaDto(
                        c.Sorteo.IdLoteria, c.Sorteo.IdSorteo, c.Sorteo.NombreLoteria, c.Sorteo.HoraSorteo,
                        c.Codigo, c.Producto, c.Monto, montoBd,
                        ajustada ? EstadosJugada.Ajustada : EstadosJugada.Aceptada, mensaje));
                    aceptadas.Add((c, montoBd));
                    break;

                case CupoDisponible:
                    procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto,
                        $"Sin cupo disponible para el producto \"{productoTxt}\" en la loteria \"{loteria}\".", c.Monto));
                    break;

                default:
                    procesadas.Add(Rechazada(c.Origen, c.Sorteo, c.Codigo, c.Producto,
                        $"La jugada no pudo procesarse (respuesta {respuesta}).", c.Monto));
                    break;
            }
        }

        if (haySorteosCerrados)
        {
            mensajes.Add("Sorteos cerrados, jugadas no procesadas.");
        }

        mensajes.AddRange(procesadas.Where(p => p.Mensaje is not null).Select(p => p.Mensaje!));

        if (aceptadas.Count == 0)
        {
            await tx.RollbackAsync(ct);
            return new VentaAnimalitosResultadoDto(false, null, procesadas, mensajes.Distinct().ToList(), haySorteosCerrados);
        }

        var total = aceptadas.Sum(a => a.Monto);
        await tx.ExecuteAsync("spActMontTck", new SpParameters
        {
            ["prmIdTck"] = idTicket,
            ["prmMont"] = total
        }, ct);

        await tx.CommitAsync(ct);

        var parametros = await sistema.ObtenerParametrosAsync(ct);
        var ticket = new TicketImpresionDto(
            Tipo: TicketImpresionDto.TipoAnimalitos,
            Taquilla: perfil.Nick.ToUpperInvariant(),
            Divisa: perfil.Divisa.ToUpperInvariant(),
            NumeroTicket: DbConvert.ToText(nroTicket),
            Serial: cabecera.GetString("prmNroSer"),
            Fecha: Formato.Fecha(cabecera.GetDateTime("fecha_ticket") ?? fechaHoraVerificacion),
            Hora: Formato.Hora12(cabecera.GetTimeOfDay("hora_ticket") ?? fechaHoraVerificacion.TimeOfDay),
            Grupos: aceptadas
                .GroupBy(a => (a.Jugada.Sorteo.IdLoteria, a.Jugada.Sorteo.IdSorteo))
                .Select(g => new TicketGrupoDto(
                    g.Key.IdLoteria,
                    g.Key.IdSorteo,
                    g.First().Jugada.Sorteo.NombreLoteria.ToUpperInvariant(),
                    Formato.Hora12(g.First().Jugada.Sorteo.Hora),
                    g.Select(a => new TicketJugadaDto(a.Jugada.Codigo, Codigos.Abreviar(a.Jugada.Producto), a.Jugada.Producto.ToUpperInvariant(), a.Monto)).ToList()))
                .ToList(),
            Tripletas: [],
            Total: total,
            DiasCaducidad: parametros.DiasCaducidadTicket,
            SorteosTripleta: parametros.SorteosTripleta,
            Nota: parametros.NotaTicket,
            Reimpresion: false);

        logger.LogInformation(
            "Ticket {Ticket} vendido por {Usuario}: {Jugadas} jugadas, total {Total}",
            ticket.NumeroTicket, perfil.Nick, aceptadas.Count, total);

        return new VentaAnimalitosResultadoDto(true, ticket, procesadas, mensajes.Distinct().ToList(), haySorteosCerrados);
    }

    private async Task<UsuarioPerfil> ObtenerPerfilActivoAsync(ClaimsPrincipal user, CancellationToken ct)
    {
        var perfil = await usuarios.ObtenerPorNickAsync(user.Nick(), ct);
        if (perfil is null || perfil.IdUsuario != user.IdUsuario())
        {
            throw BusinessRuleException.Unauthorized("Sesion invalida.");
        }

        if (!perfil.Activo)
        {
            throw BusinessRuleException.Forbidden("Usuario inactivo. Contacte con el administrador del sistema.", "usuario_inactivo");
        }

        var estado = await sistema.ObtenerEstadoTaquillaAsync(perfil.IdUsuario, ct);
        if (!estado.Activa)
        {
            throw BusinessRuleException.Forbidden("Taquilla inactiva. Contacte con el administrador del sistema.", "usuario_inactivo");
        }

        return perfil;
    }

    private async Task<Dictionary<(int IdLoteria, int IdSorteo), SorteoVentaDto>> CargarSorteosAsync(
        int idUsuario, IReadOnlyList<JugadaRequest> jugadas, CancellationToken ct)
    {
        var resultado = new Dictionary<(int, int), SorteoVentaDto>();
        foreach (var s in await catalogo.ListarSorteosVentaAsync(idUsuario, null, ct))
        {
            resultado.TryAdd((s.IdLoteria, s.IdSorteo), s);
        }

        var loteriasFaltantes = jugadas
            .Where(j => !resultado.ContainsKey((j.IdLoteria, j.IdSorteo)))
            .Select(j => j.IdLoteria)
            .Where(id => id > 0)
            .Distinct()
            .ToList();

        foreach (var idLoteria in loteriasFaltantes)
        {
            foreach (var s in await catalogo.ListarSorteosVentaAsync(idUsuario, idLoteria, ct))
            {
                resultado.TryAdd((s.IdLoteria, s.IdSorteo), s);
            }
        }

        return resultado;
    }

    private async Task<Dictionary<(int IdLoteria, string Codigo), string>> CargarProductosAsync(CancellationToken ct)
    {
        var resultado = new Dictionary<(int, string), string>();
        foreach (var p in await catalogo.ListarProductosAsync(ct))
        {
            resultado.TryAdd((p.IdLoteria, Codigos.Normalizar(p.Codigo)), p.Nombre);
        }

        return resultado;
    }

    private static JugadaProcesadaDto Rechazada(
        JugadaRequest jugada, SorteoVentaDto? sorteo, string codigo, string producto, string motivo, decimal? monto = null)
        => new(
            jugada.IdLoteria,
            jugada.IdSorteo,
            sorteo?.NombreLoteria ?? string.Empty,
            sorteo?.HoraSorteo ?? string.Empty,
            codigo,
            producto,
            monto ?? jugada.Monto,
            0m,
            EstadosJugada.Rechazada,
            motivo);
}
