namespace Animalitos.Api.Features.Ventas;

// ----------------------------------------------------------------- Solicitudes

/// <summary>Jugada de animalitos. El monto es por sorteo seleccionado.</summary>
public sealed record JugadaRequest(int IdLoteria, int IdSorteo, string Codigo, decimal Monto);

public sealed record VentaAnimalitosRequest(IReadOnlyList<JugadaRequest> Jugadas);

public sealed record TripletaRequest(int IdLoteria, string Codigo1, string Codigo2, string Codigo3, decimal Monto);

public sealed record VentaTripletasRequest(IReadOnlyList<TripletaRequest> Tripletas);

public sealed record SorteoSeleccionadoRequest(int IdLoteria, int IdSorteo);

public sealed record RepetirTicketRequest(string NumeroTicket, IReadOnlyList<SorteoSeleccionadoRequest> Sorteos);

// ----------------------------------------------------------------- Respuestas

public static class EstadosJugada
{
    public const string Aceptada = "aceptada";
    public const string Ajustada = "ajustada";
    public const string Rechazada = "rechazada";
}

public sealed record JugadaProcesadaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreLoteria,
    string HoraSorteo,
    string Codigo,
    string Producto,
    decimal MontoSolicitado,
    decimal MontoAceptado,
    string Estado,
    string? Mensaje);

public sealed record TripletaProcesadaDto(
    int IdLoteria,
    string NombreLoteria,
    string Codigo1,
    string Codigo2,
    string Codigo3,
    IReadOnlyList<string> Productos,
    decimal MontoSolicitado,
    decimal MontoAceptado,
    string? SorteoDesde,
    string? SorteoHasta,
    string Estado,
    string? Mensaje);

public sealed record TicketJugadaDto(string Codigo, string Producto, string ProductoNombre, decimal Monto);

/// <summary>Jugadas de un mismo sorteo agrupadas (asi se imprimen en el ticket).</summary>
public sealed record TicketGrupoDto(int IdLoteria, int IdSorteo, string Loteria, string Sorteo, IReadOnlyList<TicketJugadaDto> Jugadas);

public sealed record TicketTripletaDto(string Loteria, string Desde, string Hasta, IReadOnlyList<string> Productos, decimal Monto);

/// <summary>Datos estructurados del ticket; el proyecto Web los convierte a ESC/POS o HTML.</summary>
public sealed record TicketImpresionDto(
    string Tipo,
    string Taquilla,
    string Divisa,
    string NumeroTicket,
    string Serial,
    string Fecha,
    string Hora,
    IReadOnlyList<TicketGrupoDto> Grupos,
    IReadOnlyList<TicketTripletaDto> Tripletas,
    decimal Total,
    int DiasCaducidad,
    int SorteosTripleta,
    string Nota,
    bool Reimpresion)
{
    public const string TipoAnimalitos = "ANIMALITOS";
    public const string TipoTripleta = "TRIPLETA";
}

public sealed record VentaAnimalitosResultadoDto(
    bool Procesado,
    TicketImpresionDto? Ticket,
    IReadOnlyList<JugadaProcesadaDto> Jugadas,
    IReadOnlyList<string> Mensajes,
    bool HaySorteosCerrados);

public sealed record VentaTripletasResultadoDto(
    bool Procesado,
    TicketImpresionDto? Ticket,
    IReadOnlyList<TripletaProcesadaDto> Tripletas,
    IReadOnlyList<string> Mensajes);

/// <summary>Panel de totales del dia (SPbusCuadCajDia).</summary>
public sealed record TotalesDiaDto(
    decimal Ventas,
    decimal VentasAnimalitos,
    decimal VentasTripletas,
    decimal Pagados,
    decimal Anulados,
    decimal TotalCaja,
    string UltimoTicket);

public sealed record JugadaRepetidaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreLoteria,
    string AbreviaturaLoteria,
    string HoraSorteo,
    string Codigo,
    string Producto,
    decimal Monto);
