namespace Animalitos.Api.Features.Admin;

public sealed record GrupoRequest(
    int IdGrupo,
    string Nombre,
    string RazonSocial,
    string Rif,
    string Telefono,
    string Direccion,
    string Email,
    int IdEstado);

/// <summary>
/// Alta o edicion de usuario (SP_grd_act_usuarios). Si Clave viene vacia al editar, se conserva
/// la clave actual. La MAC se mantiene solo por compatibilidad con el sistema WinForms.
/// </summary>
public sealed record UsuarioRequest(
    int IdGrupo,
    int IdUsuario,
    int IdDivisa,
    string Nick,
    string? Clave,
    string Email,
    int IdEstado,
    int IdPerfil,
    int IdPreguntaSeguridad,
    string RespuestaSeguridad,
    decimal PorcentajeTaquilla,
    decimal PorcentajeCasa,
    decimal PorcentajeSistema,
    decimal MontoMaxJugada,
    decimal MontoMaxTicket,
    decimal MontoPorUnidad,
    int IdTipoCuadre,
    decimal MultiploJugada,
    decimal MinimoJugada,
    decimal UnidadBase,
    int CierreSorteo,
    string? Mac);

public sealed record AsociarEquipoRequest(int IdGrupoUsuario, int IdUsuario, int IdMacNueva);

public sealed record EstadoRequest(int IdEstado);

public sealed record LimiteTaquillaRequest(int? IdGrupo, int IdTaquilla, decimal MontoMaximo);

public sealed record BloqueoProductoRequest(int? IdGrupo, int IdTaquilla, int IdLoteria, int IdSorteo, string Codigo, int IdEstado);

public sealed record BloqueoProductoTodosRequest(int? IdGrupo, int IdLoteria, string Codigo, int IdEstado);

public sealed record BloqueoSorteoRequest(int? IdGrupo, int IdTaquilla, int IdLoteria, int IdSorteo, int IdEstado);

public sealed record BloqueoLoteriaRequest(int IdEstado, decimal MontoAnimalitos, decimal MontoTripletas);

public sealed record OperacionDto(int FilasAfectadas, string Mensaje);
