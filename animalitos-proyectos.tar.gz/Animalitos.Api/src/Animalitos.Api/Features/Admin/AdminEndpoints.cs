using Animalitos.Api.Features.Auth;

namespace Animalitos.Api.Features.Admin;

/// <summary>
/// Endpoints administrativos (grupos, usuarios, equipos, limites y bloqueos). Migrados de
/// frm_grupos_usuarios, frmLimTaq, frmContVent, frmContSort y frmContLot. Las pantallas web de
/// estos modulos se construyen en la siguiente fase; la API ya queda disponible.
/// </summary>
public static class AdminEndpoints
{
    public static IEndpointRouteBuilder MapAdminEndpoints(this IEndpointRouteBuilder app)
    {
        var admin = app.MapGroup("/api/admin").WithTags("Administracion").RequireAuthorization(Politicas.Admin);

        MapGrupos(admin);
        MapUsuarios(admin);
        MapEquipos(admin);
        MapLimites(admin);
        MapBloqueos(admin);

        return app;
    }

    // ------------------------------------------------------------------ Grupos
    private static void MapGrupos(RouteGroupBuilder admin)
    {
        var grupos = admin.MapGroup("/grupos");

        grupos.MapGet("/", async (ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                var tabla = await db.QueryTablaAsync("spBusGrup", null, ct);
                return user.EsSuperAdmin() ? tabla : FiltrarPorGrupo(tabla, user.IdGrupo());
            })
            .WithSummary("Grupos (spBusGrup). El administrador de grupo solo ve el suyo.");

        grupos.MapGet("/todos", async (ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SPBusGrupTod", null, ct))
            .RequireAuthorization(Politicas.SuperAdmin)
            .WithSummary("Todos los grupos (SPBusGrupTod).");

        grupos.MapGet("/configuracion", async (int? idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spBusGrupConf", new SpParameters
                {
                    ["prmIdUsu"] = user.IdUsuario(),
                    ["prmIdPerf"] = user.IdPerfil(),
                    ["prmIdGrup"] = user.ResolverGrupo(idGrupo)
                }, ct))
            .WithSummary("Grupos visibles en la configuracion (spBusGrupConf).");

        grupos.MapGet("/buscar", async (string nombre, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_grupos_Xfiltro_nomb", new SpParameters { ["prm_nomb_grupo"] = nombre ?? string.Empty }, ct))
            .RequireAuthorization(Politicas.SuperAdmin)
            .WithSummary("Busqueda de grupos por nombre.");

        grupos.MapPost("/", async (GrupoRequest request, ISqlExecutor db, CancellationToken ct) =>
            {
                Guard.NotEmpty(request.Nombre, "nombre");
                var filas = await db.ExecuteAsync("SP_grd_act_grupos", new SpParameters
                {
                    ["prm_id_grupo"] = request.IdGrupo,
                    ["prm_nomb_grupo"] = request.Nombre.Trim(),
                    ["prm_razon_social"] = request.RazonSocial ?? string.Empty,
                    ["prm_rif"] = request.Rif ?? string.Empty,
                    ["prm_nro_telef"] = request.Telefono ?? string.Empty,
                    ["prm_direccion"] = request.Direccion ?? string.Empty,
                    ["prm_email"] = request.Email ?? string.Empty,
                    ["prm_id_status"] = request.IdEstado
                }, ct);
                return new OperacionDto(filas, "Grupo guardado.");
            })
            .RequireAuthorization(Politicas.SuperAdmin)
            .WithSummary("Crea o actualiza un grupo (SP_grd_act_grupos).");

        grupos.MapGet("/{idGrupo:int}/usuarios", async (int idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_bus_usuarios_grupos", new SpParameters { ["prm_id_grupo"] = user.ResolverGrupo(idGrupo) }, ct))
            .WithSummary("Usuarios de un grupo.");

        grupos.MapGet("/{idGrupo:int}/cantidad-usuarios", async (int idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                var row = await db.QueryFirstAsync("SP_bus_cant_usuario", new SpParameters { ["prm_id_grupo"] = user.ResolverGrupo(idGrupo) }, ct);
                return new { cantidad = row?.GetInt32("cant_usuarios_grupo") ?? 0 };
            })
            .WithSummary("Cantidad de usuarios del grupo.");

        grupos.MapGet("/{idGrupo:int}/taquillas", async (int idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SPbusGrupTaq", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo) }, ct))
            .WithSummary("Taquillas del grupo (SPbusGrupTaq).");

        grupos.MapGet("/{idGrupo:int}/taquillas-ventas", async (int idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spBusTaqContVent", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo) }, ct))
            .WithSummary("Taquillas del grupo para control de ventas (spBusTaqContVent).");
    }

    // ------------------------------------------------------------------ Usuarios
    private static void MapUsuarios(RouteGroupBuilder admin)
    {
        admin.MapPost("/usuarios", async (UsuarioRequest request, ISqlExecutor db, UsuarioRepository usuarios,
                PasswordService passwords, Microsoft.Extensions.Options.IOptions<SecurityOptions> seguridad, CancellationToken ct) =>
            {
                Guard.NotEmpty(request.Nick, "nick");
                var minimo = seguridad.Value.LongitudMinimaClave;
                string clave;

                if (string.IsNullOrEmpty(request.Clave))
                {
                    Guard.Against(request.IdUsuario == 0, $"La clave es requerida (minimo {minimo} caracteres).");
                    clave = await usuarios.ObtenerClaveAsync(request.IdUsuario, ct)
                            ?? throw BusinessRuleException.NotFound("Usuario no encontrado.");
                }
                else
                {
                    Guard.Against(request.Clave.Length < minimo, $"La clave debe tener minimo {minimo} caracteres.");
                    clave = passwords.PrepararParaGuardar(request.Clave);
                }

                var filas = await db.ExecuteAsync("SP_grd_act_usuarios", new SpParameters
                {
                    ["prm_id_grupo"] = request.IdGrupo,
                    ["prm_id_usuario"] = request.IdUsuario,
                    ["prmIdDivisa"] = request.IdDivisa,
                    ["prm_nomb_usuario"] = request.Nick.Trim(),
                    ["prm_clave"] = clave,
                    ["prm_email"] = request.Email ?? string.Empty,
                    ["prm_id_preg_seg"] = request.IdPreguntaSeguridad,
                    ["prm_resp_seg"] = request.RespuestaSeguridad ?? string.Empty,
                    ["prm_id_status"] = request.IdEstado,
                    ["prm_id_perfil"] = request.IdPerfil,
                    ["prm_porc_taquilla"] = request.PorcentajeTaquilla,
                    ["prm_porc_casa"] = request.PorcentajeCasa,
                    ["prm_porc_sist"] = request.PorcentajeSistema,
                    ["prm_monto_max_jug"] = request.MontoMaxJugada,
                    ["prm_monto_max_ticket"] = request.MontoMaxTicket,
                    ["prm_monto_xUnidad"] = request.MontoPorUnidad,
                    ["prm_id_tipo_cuadre"] = request.IdTipoCuadre,
                    ["prm_multiplo_jug"] = request.MultiploJugada,
                    ["prm_minimo_jug"] = request.MinimoJugada,
                    ["prm_unidad_base"] = request.UnidadBase,
                    ["prm_cierre_sorteo"] = request.CierreSorteo,
                    ["prmMac"] = request.Mac ?? string.Empty
                }, ct);

                return new OperacionDto(filas, "Usuario guardado.");
            })
            .RequireAuthorization(Politicas.SuperAdmin)
            .WithSummary("Crea o actualiza un usuario (SP_grd_act_usuarios).");
    }

    // ------------------------------------------------------------------ Equipos (MAC, solo WinForms)
    private static void MapEquipos(RouteGroupBuilder admin)
    {
        var equipos = admin.MapGroup("/equipos");

        equipos.MapGet("/", async (int? idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_bus_mac_adrress", new SpParameters
                {
                    ["prmIdPerf"] = user.IdPerfil(),
                    ["prmIdGrup"] = user.ResolverGrupo(idGrupo)
                }, ct))
            .WithSummary("Equipos (MAC) registrados. Solo aplica al sistema WinForms.");

        equipos.MapGet("/buscar", async (string? mac, int? idEstado, ISqlExecutor db, CancellationToken ct)
                => idEstado is not null
                    ? await db.QueryTablaAsync("SP_bus_mac_Xfiltro_status", new SpParameters { ["prm_id_status"] = idEstado }, ct)
                    : await db.QueryTablaAsync("SP_bus_mac_Xfiltro", new SpParameters { ["prm_dir_mac"] = mac ?? string.Empty }, ct))
            .WithSummary("Busca equipos por MAC o por estado.");

        equipos.MapGet("/nuevos", async (ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_bus_mac_address_nuevas", null, ct))
            .WithSummary("Equipos nuevos pendientes de asociar.");

        equipos.MapPost("/asociar", async (AsociarEquipoRequest request, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("SP_grd_act_mac_nueva", new SpParameters
                {
                    ["prm_id_grupo_usuario"] = request.IdGrupoUsuario,
                    ["prm_id_usuario"] = request.IdUsuario,
                    ["prm_id_mac_nueva"] = request.IdMacNueva
                }, ct), "Equipo asociado."))
            .WithSummary("Asocia un equipo nuevo a un usuario.");

        equipos.MapPut("/{idMac:int}/estado", async (int idMac, EstadoRequest request, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("SP_act_status_mac", new SpParameters
                {
                    ["prm_id_mac"] = idMac,
                    ["prm_id_status"] = request.IdEstado
                }, ct), "Estado del equipo actualizado."))
            .WithSummary("Cambia el estado de un equipo.");
    }

    // ------------------------------------------------------------------ Limites de taquilla
    private static void MapLimites(RouteGroupBuilder admin)
    {
        admin.MapGet("/limites", async (int? idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spListLimTaq", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo) }, ct))
            .WithSummary("Limites (cupo de animalitos) por taquilla del grupo.");

        admin.MapPut("/limites", async (LimiteTaquillaRequest request, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                Guard.Against(request.MontoMaximo < 0, "El monto no puede ser negativo.");
                var filas = await db.ExecuteAsync("spActLimTaq", new SpParameters
                {
                    ["prmIdGrup"] = user.ResolverGrupo(request.IdGrupo),
                    ["prmIdTaq"] = request.IdTaquilla,
                    ["prmMmaxAn"] = request.MontoMaximo
                }, ct);
                return new OperacionDto(filas, "Actualizacion realizada.");
            })
            .WithSummary("Actualiza el limite de una taquilla (spActLimTaq).");
    }

    // ------------------------------------------------------------------ Bloqueos
    private static void MapBloqueos(RouteGroupBuilder admin)
    {
        var bloqueos = admin.MapGroup("/bloqueos");

        bloqueos.MapGet("/productos", async (int? idGrupo, int idLoteria, int? idSorteo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => idSorteo is null or 0
                    ? await db.QueryTablaAsync("spListProdBloq", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo), ["prmIdLot"] = idLoteria }, ct)
                    : await db.QueryTablaAsync("spListProdBloqFilt", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo), ["prmIdLot"] = idLoteria, ["prmIdSort"] = idSorteo }, ct))
            .WithSummary("Productos bloqueados por loteria/sorteo.");

        bloqueos.MapPut("/productos", async (BloqueoProductoRequest request, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("spActStatProd", new SpParameters
                {
                    ["prmIdGrup"] = user.ResolverGrupo(request.IdGrupo),
                    ["prmIdUsu"] = request.IdTaquilla,
                    ["prmIdLot"] = request.IdLoteria,
                    ["prmIdSort"] = request.IdSorteo,
                    ["prmCodProd"] = Codigos.Normalizar(request.Codigo),
                    ["prmIdStat"] = request.IdEstado
                }, ct), "Estado del producto actualizado."))
            .WithSummary("Bloquea/desbloquea un producto en un sorteo (spActStatProd).");

        bloqueos.MapPut("/productos/todos", async (BloqueoProductoTodosRequest request, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("spActStatProdTod", new SpParameters
                {
                    ["prmIdGrup"] = user.ResolverGrupo(request.IdGrupo),
                    ["prmIdLot"] = request.IdLoteria,
                    ["prmCodProd"] = Codigos.Normalizar(request.Codigo),
                    ["prmIdStat"] = request.IdEstado
                }, ct), "Estado del producto actualizado en todos los sorteos."))
            .WithSummary("Bloquea/desbloquea un producto en todos los sorteos (spActStatProdTod).");

        bloqueos.MapGet("/sorteos", async (int? idGrupo, int idLoteria, int? idSorteo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => idSorteo is null or 0
                    ? await db.QueryTablaAsync("spListSortBloq", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo), ["prmIdLot"] = idLoteria }, ct)
                    : await db.QueryTablaAsync("spListSortBloqFilt", new SpParameters { ["prmIdGrup"] = user.ResolverGrupo(idGrupo), ["prmIdLot"] = idLoteria, ["prmIdSort"] = idSorteo }, ct))
            .WithSummary("Sorteos bloqueados por loteria.");

        bloqueos.MapPut("/sorteos", async (BloqueoSorteoRequest request, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("spActStatSort", new SpParameters
                {
                    ["prmIdGrup"] = user.ResolverGrupo(request.IdGrupo),
                    ["prmIdUsu"] = request.IdTaquilla,
                    ["prmIdLot"] = request.IdLoteria,
                    ["prmIdSort"] = request.IdSorteo,
                    ["prmIdStat"] = request.IdEstado
                }, ct), "Estado del sorteo actualizado."))
            .WithSummary("Bloquea/desbloquea un sorteo (spActStatSort).");

        bloqueos.MapGet("/loterias", async (int idTaquilla, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spListLotUsu", new SpParameters { ["prmIdUsu"] = idTaquilla }, ct))
            .WithSummary("Loterias de una taquilla con su estado y montos (spListLotUsu).");

        bloqueos.MapPut("/loterias/{idBloqueo:int}", async (int idBloqueo, BloqueoLoteriaRequest request, ISqlExecutor db, CancellationToken ct)
                => new OperacionDto(await db.ExecuteAsync("spActStatLot", new SpParameters
                {
                    ["prmIdBloqLot"] = idBloqueo,
                    ["prmIdStat"] = request.IdEstado,
                    ["prmMontBs"] = request.MontoAnimalitos,
                    ["prmMontTrip"] = request.MontoTripletas
                }, ct), "Loteria actualizada."))
            .WithSummary("Estado y montos de una loteria para la taquilla (spActStatLot).");
    }

    /// <summary>Deja solo las filas cuya primera columna de id de grupo coincide.</summary>
    private static TablaDto FiltrarPorGrupo(TablaDto tabla, int idGrupo)
    {
        var indice = -1;
        for (var i = 0; i < tabla.Columnas.Count; i++)
        {
            if (tabla.Columnas[i].Equals("idGrup", StringComparison.OrdinalIgnoreCase) ||
                tabla.Columnas[i].Equals("id_grupo", StringComparison.OrdinalIgnoreCase))
            {
                indice = i;
                break;
            }
        }

        if (indice < 0)
        {
            indice = 0;
        }

        var filas = tabla.Filas.Where(f => DbConvert.ToInt32(f.ElementAtOrDefault(indice)) == idGrupo).ToList();
        return new TablaDto(tabla.Columnas, filas);
    }
}
