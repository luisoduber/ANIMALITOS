namespace Animalitos.Api.Features.Tickets;

public static class TicketsEndpoints
{
    public static IEndpointRouteBuilder MapTicketsEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/tickets").WithTags("Tickets").RequireAuthorization();

        group.MapGet("/{numero}/estado", async (string numero, string serial, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.ConsultarEstadoAsync(user.IdUsuario(), numero, serial, ct))
            .WithSummary("Estado del ticket de la taquilla (SPVerfStatTck).");

        group.MapGet("/{numero}", async (string numero, string serial, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.ObtenerDetalleAsync(user, numero, serial, ct))
            .WithSummary("Verificar ticket: cabecera y jugadas.");

        group.MapPost("/{numero}/pagar", async (string numero, TicketOperacionRequest request, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.PagarAsync(user, numero, request.Serial, ct))
            .WithSummary("Paga un ticket ganador.");

        group.MapPost("/{numero}/anular", async (string numero, TicketOperacionRequest request, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.AnularAsync(user, numero, request.Serial, ct))
            .WithSummary("Anula un ticket pendiente sin jugadas en proceso.");

        group.MapGet("/movimientos", async (DateOnly? desde, DateOnly? hasta, int? idEstado, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.MovimientosAsync(user.IdUsuario(), desde, hasta, idEstado, ct))
            .WithSummary("Movimientos de tickets de la taquilla y sus totales (entradas, salidas, caja).");

        // ---------------------------------------------------------- Administracion
        var admin = group.MapGroup("/admin").RequireAuthorization(Politicas.Admin);

        admin.MapGet("/{numero}", async (string numero, int? idGrupo, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.ObtenerDetalleAdminAsync(user, idGrupo, numero, ct))
            .WithSummary("Consulta de ticket del grupo (SPbusInfTckAn).");

        admin.MapPost("/{numero}/anular", async (string numero, int? idGrupo, ClaimsPrincipal user, TicketsService service, CancellationToken ct)
                => await service.AnularAdminAsync(user, idGrupo, numero, ct))
            .WithSummary("Anulacion administrativa (SPAnTckAdm).");

        admin.MapGet("/jugadas-taquilla", async (int idLoteria, int idSorteo, int idTaquilla, DateOnly fecha, int? idGrupo, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SPBusJugTaq", new SpParameters
                {
                    ["prmIdGrup"] = user.ResolverGrupo(idGrupo),
                    ["prmIdLot"] = idLoteria,
                    ["prmIdSort"] = idSorteo,
                    ["prmIdTaq"] = idTaquilla,
                    ["prmFech"] = fecha.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                }, ct))
            .WithSummary("Jugadas de una taquilla por sorteo y fecha (SPBusJugTaq).");

        return app;
    }
}
