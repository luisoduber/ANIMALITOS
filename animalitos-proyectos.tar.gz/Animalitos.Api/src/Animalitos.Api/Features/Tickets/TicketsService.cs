using Animalitos.Api.Features.Auth;
using Animalitos.Api.Features.Sistema;
using Animalitos.Api.Features.Ventas;

namespace Animalitos.Api.Features.Tickets;

/// <summary>Pagar, anular, verificar y consultar tickets (antes en frm_ventas y sus ventanas emergentes).</summary>
public sealed class TicketsService(
    ISqlExecutor db,
    UsuarioRepository usuarios,
    SistemaRepository sistema,
    ILogger<TicketsService> logger)
{
    public async Task<EstadoTicketDto> ConsultarEstadoAsync(int idUsuario, string numeroTicket, string serial, CancellationToken ct)
    {
        var (nro, ser) = ValidarNumeros(numeroTicket, serial);
        var row = await db.QueryFirstAsync("SPVerfStatTck", new SpParameters
        {
            ["prmIdUsu"] = idUsuario,
            ["prmNroTck"] = nro,
            ["prmNroSer"] = ser
        }, ct);

        var estado = row?.GetInt32("idStat") ?? EstadosTicket.NoExiste;
        return new EstadoTicketDto(nro, ser, estado, EstadosTicket.Nombre(estado));
    }

    /// <summary>Pago de ticket ganador (SPVerfStatTck + SP_act_paga_ticket).</summary>
    public async Task<PagoTicketDto> PagarAsync(ClaimsPrincipal user, string numeroTicket, string serial, CancellationToken ct)
    {
        var idUsuario = user.IdUsuario();
        var estado = await ConsultarEstadoAsync(idUsuario, numeroTicket, serial, ct);

        switch (estado.IdEstado)
        {
            case EstadosTicket.NoExiste: throw BusinessRuleException.NotFound("Ticket / serial no existe.", "ticket_no_existe");
            case EstadosTicket.Pendiente: throw BusinessRuleException.Conflict("Ticket pendiente por procesar.", "ticket_pendiente");
            case EstadosTicket.Anulado: throw BusinessRuleException.Conflict("El ticket fue anulado.", "ticket_anulado");
            case EstadosTicket.Perdedor: throw BusinessRuleException.Conflict("Ticket perdedor.", "ticket_perdedor");
            case EstadosTicket.Pagado: throw BusinessRuleException.Conflict("Ticket ganador ya fue cobrado.", "ticket_pagado");
            case EstadosTicket.Ganador: break;
            default: throw BusinessRuleException.Conflict($"Estado de ticket no valido ({estado.IdEstado}).");
        }

        var row = await db.QueryFirstAsync("SP_act_paga_ticket", new SpParameters
        {
            ["prm_id_usuario"] = idUsuario,
            ["prm_nro_ticket"] = estado.NumeroTicket,
            ["prm_nro_serial"] = estado.Serial
        }, ct);

        if (row is null)
        {
            throw BusinessRuleException.Conflict("No fue posible registrar el pago del ticket.");
        }

        var monto = row.GetDecimal("monto_pagado");
        logger.LogInformation("Ticket {Ticket} pagado por {Usuario}: {Monto}", estado.NumeroTicket, idUsuario, monto);
        return new PagoTicketDto(estado.NumeroTicket, estado.Serial, monto, $"Ticket ganador. Monto a pagar: {Formato.Monto(monto)}");
    }

    /// <summary>Anulacion por la taquilla (SPVerfStatTck + SPDetTckAn). Solo tickets pendientes.</summary>
    public async Task<AnulacionTicketDto> AnularAsync(ClaimsPrincipal user, string numeroTicket, string serial, CancellationToken ct)
    {
        var idUsuario = user.IdUsuario();
        var estado = await ConsultarEstadoAsync(idUsuario, numeroTicket, serial, ct);

        switch (estado.IdEstado)
        {
            case EstadosTicket.NoExiste: throw BusinessRuleException.NotFound("Ticket / serial no existe.", "ticket_no_existe");
            case EstadosTicket.Anulado: throw BusinessRuleException.Conflict("El ticket fue anulado.", "ticket_anulado");
            case EstadosTicket.Perdedor: throw BusinessRuleException.Conflict("Ticket perdedor.", "ticket_perdedor");
            case EstadosTicket.Ganador: throw BusinessRuleException.Conflict("Ticket ganador. No cancelado.", "ticket_ganador");
            case EstadosTicket.Pagado: throw BusinessRuleException.Conflict("Ticket ganador ya fue cobrado.", "ticket_pagado");
            case EstadosTicket.Pendiente: break;
            default: throw BusinessRuleException.Conflict($"Estado de ticket no valido ({estado.IdEstado}).");
        }

        var row = await db.QueryFirstAsync("SPDetTckAn", new SpParameters { ["prmNroTck"] = estado.NumeroTicket }, ct);
        var resultado = row?.GetInt32("rsAnTck") ?? 0;
        if (resultado != 1)
        {
            throw BusinessRuleException.Conflict("El ticket ya tiene jugadas en proceso, no se podra anular.", "ticket_en_proceso");
        }

        logger.LogInformation("Ticket {Ticket} anulado por {Usuario}", estado.NumeroTicket, idUsuario);
        return new AnulacionTicketDto(estado.NumeroTicket, $"Ticket nro: {estado.NumeroTicket} fue anulado.");
    }

    /// <summary>Verificacion de ticket (frm_verf_ticket): cabecera + detalle de jugadas.</summary>
    public async Task<TicketDetalleDto> ObtenerDetalleAsync(ClaimsPrincipal user, string numeroTicket, string serial, CancellationToken ct)
    {
        var (nro, ser) = ValidarNumeros(numeroTicket, serial);
        var idUsuario = user.IdUsuario();

        var existe = await db.QueryFirstAsync("SP_verf_exists_mostrar_ticket", new SpParameters
        {
            ["prm_id_usuario"] = idUsuario,
            ["prm_nro_ticket"] = long.Parse(nro, CultureInfo.InvariantCulture),
            ["prm_nro_serial"] = long.Parse(ser, CultureInfo.InvariantCulture)
        }, ct);

        if (existe is null || existe.GetInt32("cant_ticket") < 1)
        {
            throw BusinessRuleException.NotFound("Ticket / serial no existe.", "ticket_no_existe");
        }

        var info = await db.QueryFirstAsync("SPInfTck", new SpParameters
        {
            ["prmNroTck"] = nro,
            ["prmNroSer"] = ser
        }, ct) ?? throw BusinessRuleException.NotFound("Ticket / serial no existe.", "ticket_no_existe");

        var tipo = info.GetInt32("idTipTck");
        var parametros = await sistema.ObtenerParametrosAsync(ct);
        var perfil = await usuarios.ObtenerPorNickAsync(user.Nick(), ct);

        IReadOnlyList<TicketGrupoDto> grupos = [];
        IReadOnlyList<TicketTripletaDto> tripletas = [];

        if (tipo == 2)
        {
            var filas = await db.QueryAsync("SPTckDetTrip", new SpParameters { ["prmNroTck"] = long.Parse(nro, CultureInfo.InvariantCulture) }, ct);
            tripletas = filas.Select(r => new TicketTripletaDto(
                    r.GetString("nombLot").ToUpperInvariant(),
                    r.GetString("fechaIni"),
                    r.GetString("fechaFin"),
                    new[] { r.GetString("nombProd").ToUpperInvariant() },
                    r.GetDecimal("mont")))
                .ToList();
        }
        else
        {
            var filas = await db.QueryAsync("SPTckDet", new SpParameters { ["prmNroTck"] = long.Parse(nro, CultureInfo.InvariantCulture) }, ct);
            grupos = AgruparDetalle(filas, "idLot", "idSort", "nombLot", "horaSort", "codJug", "nombProd", "monto");
        }

        return new TicketDetalleDto(
            NumeroTicket: nro,
            Serial: ser,
            TipoTicket: tipo,
            Taquilla: info.GetString("nick"),
            Estado: info.GetString("nombStatTck"),
            IdEstado: null,
            MontoTicket: info.GetDecimal("mTck"),
            MontoPagado: info.GetDecimal("mPag"),
            Fecha: Formato.Fecha(info.GetDateTime("fechReg")),
            Hora: Formato.Hora12(info.GetTimeOfDay("horaReg")),
            Divisa: (perfil?.Divisa ?? string.Empty).ToUpperInvariant(),
            Grupos: grupos,
            Tripletas: tripletas,
            DiasCaducidad: parametros.DiasCaducidadTicket,
            SorteosTripleta: parametros.SorteosTripleta,
            Nota: parametros.NotaTicket);
    }

    /// <summary>Movimientos de tickets de la taquilla (frm_verf_status_ticket).</summary>
    public async Task<MovimientosDto> MovimientosAsync(
        int idUsuario, DateOnly? desde, DateOnly? hasta, int? idEstado, CancellationToken ct)
    {
        var hoy = DateOnly.FromDateTime(await sistema.ObtenerFechaHoraServidorAsync(ct));
        var ini = desde ?? hoy;
        var fin = hasta ?? hoy;
        Guard.DateRange(ini, fin);

        var filtro = new SpParameters
        {
            ["prm_id_usuario"] = idUsuario,
            ["prm_fecha_ini"] = ini.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
            ["prm_fecha_fin"] = fin.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
            ["prm_id_status_ticket"] = idEstado ?? 0
        };

        var sinFiltro = desde is null && hasta is null && idEstado is null;
        var tickets = sinFiltro
            ? await db.QueryTablaAsync("SP_bus_mov_status_ticket", new SpParameters { ["prm_id_usuario"] = idUsuario }, ct)
            : await db.QueryTablaAsync("SP_bus_mov_status_ticket_Xfiltro", filtro, ct);

        var tot = await db.QueryFirstAsync("SP_bus_totales_mov_ventas", filtro, ct);
        var entradas = tot?.GetDecimal("monto_total_entrada") ?? 0m;
        var salidas = tot?.GetDecimal("monto_total_salida") ?? 0m;

        return new MovimientosDto(tickets, new TotalesMovimientosDto(
            tot?.GetInt32("cant_ticket") ?? 0, entradas, salidas, entradas - salidas));
    }

    // ------------------------------------------------------------------ Administracion

    /// <summary>Consulta de ticket por un administrador del grupo (SPbusInfTckAn + detalle).</summary>
    public async Task<TicketDetalleDto> ObtenerDetalleAdminAsync(ClaimsPrincipal user, int? idGrupo, string numeroTicket, CancellationToken ct)
    {
        var grupo = user.ResolverGrupo(idGrupo);
        var nro = ValidarNumero(numeroTicket, "numero de ticket");

        var info = await db.QueryFirstAsync("SPbusInfTckAn", new SpParameters
        {
            ["prmIdGrup"] = grupo,
            ["prmNroTck"] = nro
        }, ct) ?? throw BusinessRuleException.NotFound("El ticket no existe en el grupo.", "ticket_no_existe");

        var filas = await db.QueryAsync("SP_bus_mostrar_ticket_det_anular", new SpParameters
        {
            ["prm_nro_ticket"] = long.Parse(nro, CultureInfo.InvariantCulture)
        }, ct);

        var parametros = await sistema.ObtenerParametrosAsync(ct);

        return new TicketDetalleDto(
            NumeroTicket: nro,
            Serial: string.Empty,
            TipoTicket: 1,
            Taquilla: info.GetString("nick"),
            Estado: info.GetString("nombStatTck"),
            IdEstado: info.GetInt32("idStat"),
            MontoTicket: info.GetDecimal("mTck"),
            MontoPagado: info.GetDecimal("mPag"),
            Fecha: Formato.Fecha(info.GetDateTime("fechReg")),
            Hora: Formato.Hora12(info.GetTimeOfDay("horReg")),
            Divisa: string.Empty,
            Grupos: AgruparDetalle(filas, "id_loteria", "id_sorteo", "nomb_loteria", "hora_sorteo", "codigo_jugada", "nomb_product", "monto"),
            Tripletas: [],
            DiasCaducidad: parametros.DiasCaducidadTicket,
            SorteosTripleta: parametros.SorteosTripleta,
            Nota: parametros.NotaTicket);
    }

    /// <summary>Anulacion administrativa (SPAnTckAdm).</summary>
    public async Task<AnulacionTicketDto> AnularAdminAsync(ClaimsPrincipal user, int? idGrupo, string numeroTicket, CancellationToken ct)
    {
        var grupo = user.ResolverGrupo(idGrupo);
        var nro = ValidarNumero(numeroTicket, "numero de ticket");

        var filas = await db.ExecuteAsync("SPAnTckAdm", new SpParameters
        {
            ["prmIdGrup"] = grupo,
            ["prmNroTck"] = nro
        }, ct);

        if (filas < 1)
        {
            throw BusinessRuleException.Conflict("No fue posible anular el ticket (no existe o ya fue procesado).");
        }

        logger.LogWarning("Anulacion administrativa del ticket {Ticket} por {Usuario}", nro, user.Nick());
        return new AnulacionTicketDto(nro, $"Ticket nro: {nro} fue anulado.");
    }

    private static IReadOnlyList<TicketGrupoDto> AgruparDetalle(
        IReadOnlyList<DbRow> filas, string colLot, string colSort, string colNombLot, string colHora,
        string colCodigo, string colProducto, string colMonto)
        => filas
            .GroupBy(r => (IdLoteria: r.GetInt32(colLot), IdSorteo: r.GetInt32(colSort)))
            .Select(g => new TicketGrupoDto(
                g.Key.IdLoteria,
                g.Key.IdSorteo,
                g.First().GetString(colNombLot).ToUpperInvariant(),
                Formato.Hora12(g.First().GetTimeOfDay(colHora)),
                g.Select(r => new TicketJugadaDto(
                    Codigos.Normalizar(r.GetString(colCodigo)),
                    Codigos.Abreviar(r.GetString(colProducto)),
                    r.GetString(colProducto).ToUpperInvariant(),
                    r.GetDecimal(colMonto))).ToList()))
            .ToList();

    private static (string Numero, string Serial) ValidarNumeros(string numeroTicket, string serial)
        => (ValidarNumero(numeroTicket, "numero de ticket"), ValidarNumero(serial, "serial"));

    private static string ValidarNumero(string? valor, string campo)
    {
        var v = (valor ?? string.Empty).Trim();
        if (v.Length == 0 || v.Length > 18 || !v.All(char.IsAsciiDigit))
        {
            throw new BusinessRuleException($"Ingrese un {campo} valido.");
        }

        return v;
    }
}
