using Animalitos.Api.Features.Ventas;

namespace Animalitos.Api.Features.Tickets;

public sealed record TicketOperacionRequest(string Serial);

/// <summary>Estados de ticket del sistema original (SPVerfStatTck).</summary>
public static class EstadosTicket
{
    public const int NoExiste = 0;
    public const int Pendiente = 1;
    public const int Anulado = 2;
    public const int Perdedor = 3;
    public const int Ganador = 4;
    public const int Pagado = 5;

    public static string Nombre(int estado) => estado switch
    {
        Pendiente => "Pendiente",
        Anulado => "Anulado",
        Perdedor => "Perdedor",
        Ganador => "Ganador",
        Pagado => "Pagado",
        _ => "No existe"
    };
}

public sealed record EstadoTicketDto(string NumeroTicket, string Serial, int IdEstado, string Estado);

public sealed record PagoTicketDto(string NumeroTicket, string Serial, decimal MontoPagado, string Mensaje);

public sealed record AnulacionTicketDto(string NumeroTicket, string Mensaje);

public sealed record TicketDetalleDto(
    string NumeroTicket,
    string Serial,
    int TipoTicket,
    string Taquilla,
    string Estado,
    int? IdEstado,
    decimal MontoTicket,
    decimal MontoPagado,
    string Fecha,
    string Hora,
    string Divisa,
    IReadOnlyList<TicketGrupoDto> Grupos,
    IReadOnlyList<TicketTripletaDto> Tripletas,
    int DiasCaducidad,
    int SorteosTripleta,
    string Nota);

public sealed record TotalesMovimientosDto(int CantidadTickets, decimal Entradas, decimal Salidas, decimal TotalCaja);

public sealed record MovimientosDto(TablaDto Tickets, TotalesMovimientosDto Totales);
