namespace Animalitos.Api.Features.Catalogo;

/// <summary>Catalogos de loterias, sorteos y productos (animalitos).</summary>
public sealed class CatalogoRepository(ISqlExecutor db)
{
    /// <summary>spListLotTod: loterias habilitadas para el usuario (combo de la pantalla de venta).</summary>
    public async Task<IReadOnlyList<LoteriaDto>> ListarLoteriasAsync(int idUsuario, CancellationToken ct)
    {
        var rows = await db.QueryAsync("spListLotTod", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);
        return rows.Select(r => new LoteriaDto(
                r.GetInt32("idLot", "id_loteria"),
                r.GetString("nombLot", "nomb_loteria")))
            .ToList();
    }

    /// <summary>spListLotTodGrup: loterias de un grupo.</summary>
    public async Task<IReadOnlyList<LoteriaDto>> ListarLoteriasGrupoAsync(int idGrupo, CancellationToken ct)
    {
        var rows = await db.QueryAsync("spListLotTodGrup", new SpParameters { ["prmIdGrup"] = idGrupo }, ct);
        return rows.Select(r => new LoteriaDto(
                r.GetInt32("idLot", "id_loteria"),
                r.GetString("nombLot", "nomb_loteria")))
            .ToList();
    }

    /// <summary>SP_bus_lot_result: loterias para la consulta de resultados.</summary>
    public async Task<IReadOnlyList<LoteriaDto>> ListarLoteriasResultadosAsync(CancellationToken ct)
    {
        var rows = await db.QueryAsync("SP_bus_lot_result", null, ct);
        return rows.Select(r => new LoteriaDto(
                r.GetInt32("id_loteria", "idLot"),
                r.GetString("nomb_loteria", "nombLot")))
            .ToList();
    }

    /// <summary>SPbusLotTrip: loterias que venden tripletas.</summary>
    public async Task<IReadOnlyList<LoteriaTripletaDto>> ListarLoteriasTripletaAsync(int idUsuario, CancellationToken ct)
    {
        var rows = await db.QueryAsync("SPbusLotTrip", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);
        return rows.Select(r => new LoteriaTripletaDto(
                r.GetInt32("idLot", "id_loteria"),
                r.GetString("nombLot", "nomb_loteria"),
                r.GetString("abLot", "abrev_loteria"),
                r.GetInt32("codMaxProd", "codig_max_product")))
            .ToList();
    }

    /// <summary>
    /// Sorteos abiertos para la venta. Sin loteria: SPBusSort (todos los del usuario);
    /// con loteria: spListSortVentTod.
    /// </summary>
    public async Task<IReadOnlyList<SorteoVentaDto>> ListarSorteosVentaAsync(int idUsuario, int? idLoteria, CancellationToken ct)
    {
        var rows = idLoteria is null or 0
            ? await db.QueryAsync("SPBusSort", new SpParameters { ["prmIdUsu"] = idUsuario }, ct)
            : await db.QueryAsync("spListSortVentTod", new SpParameters { ["prmIdUsu"] = idUsuario, ["prmIdLot"] = idLoteria }, ct);

        return rows.Select(MapSorteo).ToList();
    }

    /// <summary>spBusNombProd: nombres de los productos por loteria (idLot, codigo, nombre).</summary>
    public async Task<IReadOnlyList<ProductoDto>> ListarProductosAsync(CancellationToken ct)
    {
        var rows = await db.QueryAsync("spBusNombProd", null, ct);

        // El sistema original leia esta tabla por posicion: [0] idLot, [1] codigo, [2] nombre.
        return rows.Select(r => new ProductoDto(
                r.GetInt32At(0),
                r.GetStringAt(1),
                r.GetStringAt(2)))
            .ToList();
    }

    /// <summary>SP_bus_producto: productos de una loteria.</summary>
    public Task<TablaDto> ProductosPorLoteriaAsync(int idLoteria, CancellationToken ct)
        => db.QueryTablaAsync("SP_bus_producto", new SpParameters { ["prm_id_loteria"] = idLoteria }, ct);

    /// <summary>spListSortTod: todos los sorteos de una loteria.</summary>
    public Task<TablaDto> SorteosPorLoteriaAsync(int idLoteria, CancellationToken ct)
        => db.QueryTablaAsync("spListSortTod", new SpParameters { ["prmIdLot"] = idLoteria }, ct);

    /// <summary>SP_bus_sorteos: sorteos de una loteria (version anterior).</summary>
    public Task<TablaDto> SorteosLoteriaAsync(int idLoteria, CancellationToken ct)
        => db.QueryTablaAsync("SP_bus_sorteos", new SpParameters { ["prm_id_loteria"] = idLoteria }, ct);

    /// <summary>Catalogos simples sin parametros (combos del sistema).</summary>
    public Task<TablaDto> CatalogoAsync(string procedure, CancellationToken ct)
        => db.QueryTablaAsync(procedure, null, ct);

    public static SorteoVentaDto MapSorteo(DbRow r)
    {
        var hora = r.GetTimeOfDay("hora_sorteo", "horaSort", "hora") ?? TimeSpan.Zero;
        return new SorteoVentaDto(
            IdLoteria: r.GetInt32("id_loteria", "idLot"),
            IdSorteo: r.GetInt32("id_sorteo", "idSort"),
            NombreSorteo: r.GetString("nomb_sorteo", "nombSort"),
            HoraSorteo: hora.ToString(@"hh\:mm\:ss", CultureInfo.InvariantCulture),
            CodigoMaximo: r.GetInt32("codig_max_product", "codMaxProd"),
            NombreLoteria: r.GetString("nomb_loteria", "nombLot"),
            AbreviaturaLoteria: r.GetString("abrev_loteria", "abLot", "abrevLot"));
    }
}
