namespace Animalitos.Api.Features.Catalogo;

public static class CatalogoEndpoints
{
    /// <summary>
    /// Catalogos simples expuestos por nombre. Lista blanca: solo estos procedimientos se pueden
    /// invocar por esta ruta.
    /// </summary>
    private static readonly IReadOnlyDictionary<string, string> CatalogosSimples =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["estados"] = "SP_bus_status",
            ["estados-ticket"] = "SP_bus_status_ticket_filtro",
            ["tipos-ticket"] = "spListTipTck",
            ["divisas"] = "spBusDivisa",
            ["tipos-cuadre"] = "SP_bus_tipo_cuadre",
            ["preguntas-seguridad"] = "SP_bus_preg_seguridad",
            ["letras-rif"] = "SP_bus_letra_rif",
            ["codigos-telefono"] = "SP_bus_cod_area_telf",
            ["anchos-ticket"] = "SP_bus_ancho_ticket",
            ["tamanos-letra"] = "SP_bus_num_letra",
            ["tipos-proceso"] = "sp_bus_tipo_proc_datos",
            ["estados-equipo"] = "SP_bus_status_mac",
            ["estados-equipo-filtro"] = "SP_bus_status_mac_filtro"
        };

    public static IEndpointRouteBuilder MapCatalogoEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/catalogo").WithTags("Catalogo").RequireAuthorization();

        group.MapGet("/loterias", async (ClaimsPrincipal user, CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarLoteriasAsync(user.IdUsuario(), ct))
            .WithSummary("Loterias habilitadas para el usuario (spListLotTod).");

        group.MapGet("/loterias/grupo/{idGrupo:int}", async (int idGrupo, ClaimsPrincipal user, CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarLoteriasGrupoAsync(user.ResolverGrupo(idGrupo), ct))
            .RequireAuthorization(Politicas.Admin)
            .WithSummary("Loterias de un grupo (spListLotTodGrup).");

        group.MapGet("/loterias/tripletas", async (ClaimsPrincipal user, CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarLoteriasTripletaAsync(user.IdUsuario(), ct))
            .WithSummary("Loterias que venden tripletas (SPbusLotTrip).");

        group.MapGet("/loterias/resultados", async (CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarLoteriasResultadosAsync(ct))
            .WithSummary("Loterias para consultar resultados (SP_bus_lot_result).");

        group.MapGet("/sorteos/venta", async (int? idLoteria, ClaimsPrincipal user, CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarSorteosVentaAsync(user.IdUsuario(), idLoteria, ct))
            .WithSummary("Sorteos abiertos para la venta (SPBusSort / spListSortVentTod).");

        group.MapGet("/sorteos/loteria/{idLoteria:int}", async (int idLoteria, CatalogoRepository repo, CancellationToken ct)
                => await repo.SorteosPorLoteriaAsync(idLoteria, ct))
            .WithSummary("Todos los sorteos de una loteria (spListSortTod).");

        group.MapGet("/sorteos/loteria/{idLoteria:int}/detalle", async (int idLoteria, CatalogoRepository repo, CancellationToken ct)
                => await repo.SorteosLoteriaAsync(idLoteria, ct))
            .WithSummary("Sorteos de una loteria (SP_bus_sorteos).");

        group.MapGet("/productos", async (CatalogoRepository repo, CancellationToken ct)
                => await repo.ListarProductosAsync(ct))
            .WithSummary("Nombres de los animalitos/productos por loteria (spBusNombProd).");

        group.MapGet("/productos/loteria/{idLoteria:int}", async (int idLoteria, CatalogoRepository repo, CancellationToken ct)
                => await repo.ProductosPorLoteriaAsync(idLoteria, ct))
            .WithSummary("Productos de una loteria (SP_bus_producto).");

        group.MapGet("/perfiles", async (ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("spBusPerf", new SpParameters { ["prmIdPerf"] = user.IdPerfil() }, ct))
            .RequireAuthorization(Politicas.Admin)
            .WithSummary("Perfiles que puede asignar el usuario (spBusPerf).");

        group.MapGet("/{nombre}", async (string nombre, CatalogoRepository repo, CancellationToken ct) =>
            {
                if (!CatalogosSimples.TryGetValue(nombre, out var procedure))
                {
                    throw BusinessRuleException.NotFound($"El catalogo '{nombre}' no existe.");
                }

                return await repo.CatalogoAsync(procedure, ct);
            })
            .WithSummary("Catalogos simples: " + string.Join(", ", CatalogosSimples.Keys));

        return app;
    }
}
