namespace Animalitos.Api.Features.Catalogo;

public sealed record LoteriaDto(int IdLoteria, string Nombre);

public sealed record LoteriaTripletaDto(int IdLoteria, string Nombre, string Abreviatura, int CodigoMaximo);

public sealed record ProductoDto(int IdLoteria, string Codigo, string Nombre)
{
    public string Abreviatura => Codigos.Abreviar(Nombre);
}

/// <summary>Sorteo disponible para la venta (columnas de SPBusSort / spListSortVentTod).</summary>
public sealed record SorteoVentaDto(
    int IdLoteria,
    int IdSorteo,
    string NombreSorteo,
    string HoraSorteo,
    int CodigoMaximo,
    string NombreLoteria,
    string AbreviaturaLoteria)
{
    public TimeSpan Hora => TimeSpan.TryParseExact(HoraSorteo, @"hh\:mm\:ss", CultureInfo.InvariantCulture, out var t) ? t : TimeSpan.Zero;
}
