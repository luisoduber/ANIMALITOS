using System.ComponentModel.DataAnnotations;

namespace Animalitos.Api.Features.Resultados;

/// <summary>Configuracion de las paginas de donde se leen los resultados (seccion "Resultados").</summary>
public sealed class ResultadosOptions
{
    public const string SectionName = "Resultados";

    [Required, Url]
    public string UrlTuAzarAnimalitos { get; set; } = "https://www.tuazar.com/loteria/animalitos/resultados/";

    [Required, Url]
    public string UrlTuAzarFrutas { get; set; } = "https://www.tuazar.com/loteria/frutas/resultados/";

    /// <summary>Base de las paginas por loteria: {base}{nombre-loteria}/resultados/</summary>
    [Required, Url]
    public string UrlLoteriaDeHoyBase { get; set; } = "https://loteriadehoy.com/animalito/";

    [Required, Url]
    public string UrlLottoResultados { get; set; } = "https://www.lottoresultados.com/resultados/animalitos";

    [Required, Url]
    public string UrlRuletaActiva { get; set; } = "https://www.ruletactiva.com.ve/";

    /// <summary>Loterias que se buscan en lottoresultados.com (igual que el sistema original).</summary>
    public int[] LoteriasLottoResultados { get; set; } = [1, 5, 11, 12, 13, 15, 17, 19, 21, 22, 23, 24, 25, 27, 28, 29, 30];

    /// <summary>A partir de esta hora del servidor se consulta lottoresultados.com.</summary>
    public string HoraInicioLottoResultados { get; set; } = "09:00";

    /// <summary>Id de la loteria "Ruleta Activa" (se lee de su pagina oficial).</summary>
    public int IdLoteriaRuletaActiva { get; set; } = 8;

    [Range(5, 120)]
    public int TimeoutSegundos { get; set; } = 20;

    /// <summary>Intervalo por defecto (ms) si spTmpProcRs no devuelve valores.</summary>
    public int IntervaloMinimoMs { get; set; } = 60_000;

    public int IntervaloMaximoMs { get; set; } = 120_000;
}
