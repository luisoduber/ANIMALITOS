namespace Animalitos.Api.Features.Resultados;

public sealed record ProcesoManualRequest(int IdLoteria, int IdSorteo, string Codigo, DateOnly? Fecha);

/// <summary>Sorteo pendiente de resultado (SPBusSortProcRsAut).</summary>
public sealed record SorteoPendiente(int IdLoteria, int IdSorteo, TimeSpan Hora, string NombreLoteria, TimeSpan HoraServidor)
{
    /// <summary>Hora del sorteo en formato "hh:mm" (12 horas sin AM/PM), como la comparaba el sistema original.</summary>
    public string HoraBusqueda => DateTime.Today.Add(Hora).ToString("hh:mm", CultureInfo.InvariantCulture);
}

/// <summary>Resultado leido de una pagina externa.</summary>
public sealed record ResultadoEncontrado(int IdLoteria, int IdSorteo, string Codigo, string Animal, string Loteria, string Fuente);

public sealed record ResultadoGuardadoDto(int IdLoteria, int IdSorteo, string Loteria, string Codigo, string Animal, string Fuente, bool Nuevo);

public sealed record ResumenJugadasDto(int Procesadas, int Ganadoras, int Perdedoras, int ConError);

public sealed record ProcesoResultadosDto(
    string Fecha,
    int SorteosPendientes,
    IReadOnlyList<ResultadoGuardadoDto> Resultados,
    ResumenJugadasDto Jugadas,
    IReadOnlyList<string> Mensajes,
    int ProximaEjecucionMs);

public sealed record SorteoProcesoDto(int IdLoteria, string Loteria, int CodigoMaximo, int IdSorteo, string Sorteo);

public sealed record IntervaloProcesoDto(int MinimoMs, int MaximoMs);
