namespace Animalitos.Api.Features.Resultados;

public static class ResultadosEndpoints
{
    public static IEndpointRouteBuilder MapResultadosEndpoints(this IEndpointRouteBuilder app)
    {
        // ---------------------------------------------------------- Consulta (todos los perfiles)
        var group = app.MapGroup("/api/resultados").WithTags("Resultados").RequireAuthorization();

        group.MapGet("/", async (int? idLoteria, DateOnly? fecha, ISqlExecutor db, CancellationToken ct) =>
            {
                if (idLoteria is null or 0 || fecha is null)
                {
                    return await db.QueryTablaAsync("SP_bus_result_lot", null, ct);
                }

                return await db.QueryTablaAsync("SP_bus_result_lot_Xfiltro", new SpParameters
                {
                    ["prm_id_loteria"] = idLoteria,
                    ["prm_fecha"] = fecha.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                }, ct);
            })
            .WithSummary("Resultados del dia (SP_bus_result_lot) o de una loteria y fecha (SP_bus_result_lot_Xfiltro).");

        // ---------------------------------------------------------- Procesamiento (administradores)
        var admin = app.MapGroup("/api/admin/resultados").WithTags("Resultados (proceso)").RequireAuthorization(Politicas.Admin);

        admin.MapPost("/automatico", async (ClaimsPrincipal user, ResultadosService service, CancellationToken ct)
                => await service.ProcesarAutomaticoAsync(user, ct))
            .WithSummary("Busca los resultados en las paginas publicas, los guarda y procesa las jugadas pendientes.");

        admin.MapPost("/manual", async (ProcesoManualRequest request, ClaimsPrincipal user, ResultadosService service, CancellationToken ct)
                => await service.ProcesarManualAsync(user, request, ct))
            .WithSummary("Registra manualmente el resultado de un sorteo y procesa sus jugadas.");

        admin.MapGet("/sorteos", async (int? idLoteria, ResultadosService service, CancellationToken ct)
                => await service.ListarSorteosAsync(idLoteria, ct))
            .WithSummary("Sorteos para cargar resultados manualmente.");

        admin.MapGet("/jugadas-pendientes", async (int? idTipoTicket, ClaimsPrincipal user, ResultadosService service, CancellationToken ct)
                => await service.JugadasPendientesAsync(user, idTipoTicket, ct))
            .WithSummary("Jugadas pendientes por procesar (SPBusJugPendProc / SPBusTipJugPendProc).");

        admin.MapGet("/jugadas-sorteo", async (int idSorteo, DateOnly fecha, ClaimsPrincipal user, ResultadosService service, CancellationToken ct)
                => await service.JugadasSorteoAsync(user, idSorteo, fecha, ct))
            .WithSummary("Jugadas de un sorteo y fecha (SPBusJugProcRsMan).");

        admin.MapGet("/intervalo", async (ResultadosService service, CancellationToken ct)
                => await service.ObtenerIntervaloAsync(ct))
            .WithSummary("Intervalo (ms) entre ejecuciones automaticas (spTmpProcRs).");

        return app;
    }
}
