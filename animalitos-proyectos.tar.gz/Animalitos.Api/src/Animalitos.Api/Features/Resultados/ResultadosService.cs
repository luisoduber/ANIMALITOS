using Animalitos.Api.Features.Resultados.Scraping;
using Animalitos.Api.Features.Sistema;
using Microsoft.Extensions.Options;

namespace Animalitos.Api.Features.Resultados;

/// <summary>
/// Procesamiento de resultados (migrado de frm_proc_result_loteria):
///  - Automatico: lee los resultados de las paginas publicas, los guarda (SPGrdActRsLot) y
///    procesa las jugadas pendientes (SPactRsLot / SPactRsLotTrip).
///  - Manual: el administrador indica el codigo ganador de un sorteo.
/// Solo se permite un proceso a la vez en toda la API.
/// </summary>
public sealed class ResultadosService(
    ISqlExecutor db,
    SistemaRepository sistema,
    ResultadosScraper scraper,
    IOptions<ResultadosOptions> options,
    ILogger<ResultadosService> logger)
{
    private static readonly SemaphoreSlim Candado = new(1, 1);

    // Posiciones de las columnas de SPBusJugProcRs / SPBusJugProcRsMan (el sistema original las leia por indice).
    private const int ColIdDetalle = 0;
    private const int ColIdLoteria = 1;
    private const int ColIdSorteo = 2;
    private const int ColTipoTicket = 3;
    private const int ColNroTicket = 4;
    private const int ColCodigoJugada = 9;
    private const int ColMonto = 11;
    private const int ColResultado = 14;
    private const int ColIdUsuario = 15;
    private const int ColEstadoTicket = 16;

    public async Task<ProcesoResultadosDto> ProcesarAutomaticoAsync(ClaimsPrincipal user, CancellationToken ct)
    {
        if (!await Candado.WaitAsync(TimeSpan.Zero, ct))
        {
            throw BusinessRuleException.Conflict("Ya se esta ejecutando un proceso de resultados. Espere a que termine.", "proceso_en_curso");
        }

        try
        {
            var mensajes = new List<string>();
            var fecha = DateOnly.FromDateTime(await sistema.ObtenerFechaHoraServidorAsync(ct));
            var fechaTexto = Fecha(fecha);

            var sorteos = (await db.QueryAsync("SPBusSortProcRsAut", null, ct))
                .Select(r => new SorteoPendiente(
                    IdLoteria: r.GetInt32At(0),
                    IdSorteo: r.GetInt32At(1),
                    Hora: r.GetTimeOfDayAt(2) ?? TimeSpan.Zero,
                    NombreLoteria: r.GetStringAt(3).Trim().ToLowerInvariant(),
                    HoraServidor: r.GetTimeOfDayAt(6) ?? TimeSpan.Zero))
                .ToList();

            var guardados = new List<ResultadoGuardadoDto>();
            if (sorteos.Count == 0)
            {
                mensajes.Add("No hay sorteos pendientes de resultado.");
            }
            else
            {
                var encontrados = await scraper.BuscarAsync(sorteos, ct);
                if (encontrados.Count == 0)
                {
                    mensajes.Add("No se ubicaron resultados.");
                }

                foreach (var r in encontrados)
                {
                    var codigo = Codigos.Normalizar(r.Codigo);
                    var filas = await db.ExecuteAsync("SPGrdActRsLot", new SpParameters
                    {
                        ["prmIdLot"] = r.IdLoteria,
                        ["prmIdSort"] = r.IdSorteo,
                        ["prmRsLot"] = codigo,
                        ["prmFechLot"] = fechaTexto,
                        ["prmAbPwLot"] = r.Fuente
                    }, ct);

                    guardados.Add(new ResultadoGuardadoDto(r.IdLoteria, r.IdSorteo, r.Loteria, codigo, r.Animal, r.Fuente, filas == 1));
                }
            }

            var jugadas = await db.QueryAsync("SPBusJugProcRs", new SpParameters
            {
                ["prmIdPerf"] = user.IdPerfil(),
                ["prmIdGrup"] = user.IdGrupo(),
                ["prmFech"] = fechaTexto
            }, ct);

            var resumen = await ProcesarJugadasAsync(jugadas, codigoManual: null, ct);
            var intervalo = await ObtenerIntervaloAsync(ct);
            var proxima = intervalo.MaximoMs > intervalo.MinimoMs
                ? Random.Shared.Next(intervalo.MinimoMs, intervalo.MaximoMs)
                : intervalo.MinimoMs;

            logger.LogInformation(
                "Proceso automatico de resultados por {Usuario}: {Sorteos} sorteos pendientes, {Resultados} resultados, {Jugadas} jugadas ({Ganadoras} ganadoras)",
                user.Nick(), sorteos.Count, guardados.Count, resumen.Procesadas, resumen.Ganadoras);

            return new ProcesoResultadosDto(fechaTexto, sorteos.Count, guardados, resumen, mensajes, proxima);
        }
        finally
        {
            Candado.Release();
        }
    }

    public async Task<ProcesoResultadosDto> ProcesarManualAsync(ClaimsPrincipal user, ProcesoManualRequest request, CancellationToken ct)
    {
        var codigo = Codigos.Normalizar(request.Codigo);
        Guard.Against(!Codigos.EsValido(codigo), "Ingrese un codigo valido.");

        var hoy = DateOnly.FromDateTime(await sistema.ObtenerFechaHoraServidorAsync(ct));
        var fecha = request.Fecha ?? hoy;
        Guard.Against(fecha > hoy, "La fecha no debe ser mayor a la fecha actual.");

        var sorteos = await ListarSorteosAsync(request.IdLoteria, ct);
        var sorteo = sorteos.FirstOrDefault(s => s.IdSorteo == request.IdSorteo)
                     ?? throw BusinessRuleException.NotFound("El sorteo indicado no existe para la loteria.");

        Guard.Against(sorteo.CodigoMaximo > 0 && Codigos.Valor(codigo) > sorteo.CodigoMaximo, "Codigo invalido para la loteria.");

        if (!await Candado.WaitAsync(TimeSpan.Zero, ct))
        {
            throw BusinessRuleException.Conflict("Ya se esta ejecutando un proceso de resultados. Espere a que termine.", "proceso_en_curso");
        }

        try
        {
            var fechaTexto = Fecha(fecha);
            var filas = await db.ExecuteAsync("SPGrdActRsLot", new SpParameters
            {
                ["prmIdLot"] = request.IdLoteria,
                ["prmIdSort"] = request.IdSorteo,
                ["prmRsLot"] = codigo,
                ["prmFechLot"] = fechaTexto,
                ["prmAbPwLot"] = string.Empty
            }, ct);

            var jugadas = await db.QueryAsync("SPBusJugProcRsMan", new SpParameters
            {
                ["prmIdPerf"] = user.IdPerfil(),
                ["prmIdGrup"] = user.IdGrupo(),
                ["prmIdSort"] = request.IdSorteo,
                ["prmFech"] = fechaTexto
            }, ct);

            var resumen = await ProcesarJugadasAsync(jugadas, codigo, ct);

            logger.LogWarning(
                "Resultado manual {Codigo} cargado por {Usuario} para loteria {Loteria} sorteo {Sorteo} ({Fecha})",
                codigo, user.Nick(), request.IdLoteria, request.IdSorteo, fechaTexto);

            return new ProcesoResultadosDto(
                fechaTexto,
                1,
                [new ResultadoGuardadoDto(request.IdLoteria, request.IdSorteo, sorteo.Loteria, codigo, string.Empty, "manual", filas == 1)],
                resumen,
                [$"Resultado Nro \"{codigo}\" procesado para {sorteo.Loteria} {sorteo.Sorteo}."],
                0);
        }
        finally
        {
            Candado.Release();
        }
    }

    /// <summary>Sorteos para el proceso manual (SP_bus_sorteos_proc_result o spListSortTod por loteria).</summary>
    public async Task<IReadOnlyList<SorteoProcesoDto>> ListarSorteosAsync(int? idLoteria, CancellationToken ct)
    {
        var rows = idLoteria is null or 0
            ? await db.QueryAsync("SP_bus_sorteos_proc_result", null, ct)
            : await db.QueryAsync("spListSortTod", new SpParameters { ["prmIdLot"] = idLoteria }, ct);

        // Mismo orden de columnas que usaba la grilla original: [0] idLot, [1] loteria, [2] codMax, [3] idSort, [5] sorteo.
        return rows.Select(r => new SorteoProcesoDto(
                r.GetInt32At(0),
                r.GetStringAt(1),
                r.GetInt32At(2),
                r.GetInt32At(3),
                r.Count > 5 ? r.GetStringAt(5) : r.GetStringAt(4)))
            .ToList();
    }

    public async Task<IntervaloProcesoDto> ObtenerIntervaloAsync(CancellationToken ct)
    {
        var o = options.Value;
        var row = await db.QueryFirstAsync("spTmpProcRs", null, ct);
        var min = row?.GetInt32("tmpMin") ?? 0;
        var max = row?.GetInt32("tmpMax") ?? 0;
        if (min <= 0)
        {
            min = o.IntervaloMinimoMs;
        }

        if (max < min)
        {
            max = Math.Max(min, o.IntervaloMaximoMs);
        }

        return new IntervaloProcesoDto(min, max);
    }

    public Task<TablaDto> JugadasPendientesAsync(ClaimsPrincipal user, int? idTipoTicket, CancellationToken ct)
        => idTipoTicket is null or 0
            ? db.QueryTablaAsync("SPBusJugPendProc", new SpParameters
            {
                ["prmIdPerf"] = user.IdPerfil(),
                ["prmIdGrup"] = user.IdGrupo()
            }, ct)
            : db.QueryTablaAsync("SPBusTipJugPendProc", new SpParameters
            {
                ["prmIdPerf"] = user.IdPerfil(),
                ["prmIdGrup"] = user.IdGrupo(),
                ["prmIdTipTck"] = idTipoTicket
            }, ct);

    public Task<TablaDto> JugadasSorteoAsync(ClaimsPrincipal user, int idSorteo, DateOnly fecha, CancellationToken ct)
        => db.QueryTablaAsync("SPBusJugProcRsMan", new SpParameters
        {
            ["prmIdPerf"] = user.IdPerfil(),
            ["prmIdGrup"] = user.IdGrupo(),
            ["prmIdSort"] = idSorteo,
            ["prmFech"] = Fecha(fecha)
        }, ct);

    /// <summary>Procesa cada jugada contra su resultado: 1 = ganadora, 0 = perdedora.</summary>
    private async Task<ResumenJugadasDto> ProcesarJugadasAsync(IReadOnlyList<DbRow> jugadas, string? codigoManual, CancellationToken ct)
    {
        int ganadoras = 0, perdedoras = 0, errores = 0;

        foreach (var j in jugadas)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                var tipo = j.GetInt32At(ColTipoTicket);
                var parametros = new SpParameters
                {
                    ["prmIdDetJug"] = j.GetInt32At(ColIdDetalle),
                    ["prmIdLot"] = j.GetInt32At(ColIdLoteria),
                    ["prmIdUsu"] = j.GetInt32At(ColIdUsuario),
                    ["prmIdStatTck"] = j.GetInt32At(ColEstadoTicket),
                    ["prmNroTck"] = j.GetStringAt(ColNroTicket),
                    ["prmMjugTck"] = j.GetDecimalAt(ColMonto),
                    ["prmCodJugTck"] = j.GetStringAt(ColCodigoJugada),
                    ["prmRsLot"] = codigoManual ?? j.GetStringAt(ColResultado)
                };

                string procedimiento;
                if (tipo == 2)
                {
                    procedimiento = "SPactRsLotTrip";
                }
                else
                {
                    procedimiento = "SPactRsLot";
                    parametros["prmIdSort"] = j.GetInt32At(ColIdSorteo);
                }

                var row = await db.QueryFirstAsync(procedimiento, parametros, ct);
                switch (row?.GetString("statTck"))
                {
                    case "1": ganadoras++; break;
                    case "0": perdedoras++; break;
                    default: errores++; break;
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                errores++;
                logger.LogError(ex, "Error procesando la jugada {IdDetalle}", j.GetStringAt(ColIdDetalle));
            }
        }

        return new ResumenJugadasDto(jugadas.Count, ganadoras, perdedoras, errores);
    }

    private static string Fecha(DateOnly fecha) => fecha.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
}
