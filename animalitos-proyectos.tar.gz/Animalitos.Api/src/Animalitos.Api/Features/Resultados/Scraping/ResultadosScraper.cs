using HtmlAgilityPack;
using Microsoft.Extensions.Options;

namespace Animalitos.Api.Features.Resultados.Scraping;

/// <summary>
/// Lectura de resultados desde paginas publicas. Es una migracion fiel de
/// frm_proc_result_loteria (rsTuAz, rsIndLotHoy, LottResult, result_grupo2): mismas fuentes,
/// mismo orden de busqueda y mismas reglas de comparacion por nombre de loteria y hora,
/// pero con resultados tipados (antes se concatenaban con "-" y "/", lo que fallaba si el
/// nombre del animal o la loteria contenia un guion).
/// </summary>
public sealed class ResultadosScraper(PaginaResultadosClient paginas, IOptions<ResultadosOptions> options, ILogger<ResultadosScraper> logger)
{
    private sealed class PaginasCompartidas
    {
        public HtmlDocument? TuAzarAnimalitos { get; init; }
        public HtmlDocument? TuAzarFrutas { get; init; }
        public HtmlDocument? LottoResultados { get; init; }
        public HtmlDocument? RuletaActiva { get; set; }
    }

    /// <summary>Busca el resultado de cada sorteo pendiente probando las fuentes en orden.</summary>
    public async Task<IReadOnlyList<ResultadoEncontrado>> BuscarAsync(IReadOnlyList<SorteoPendiente> sorteos, CancellationToken ct)
    {
        var encontrados = new List<ResultadoEncontrado>();
        if (sorteos.Count == 0)
        {
            return encontrados;
        }

        var o = options.Value;
        await paginas.CargarUserAgentsAsync(ct);

        var tareas = new[]
        {
            paginas.ObtenerHtmlAsync(o.UrlTuAzarAnimalitos, ct),
            paginas.ObtenerHtmlAsync(o.UrlTuAzarFrutas, ct),
            paginas.ObtenerHtmlAsync(o.UrlLottoResultados, ct)
        };
        var html = await Task.WhenAll(tareas);

        var compartidas = new PaginasCompartidas
        {
            TuAzarAnimalitos = Cargar(html[0]),
            TuAzarFrutas = Cargar(html[1]),
            LottoResultados = Cargar(html[2])
        };

        var horaInicioLotto = TimeSpan.TryParse(o.HoraInicioLottoResultados, CultureInfo.InvariantCulture, out var hi)
            ? hi
            : new TimeSpan(9, 0, 0);

        foreach (var sorteo in sorteos)
        {
            ct.ThrowIfCancellationRequested();

            var resultado =
                BuscarTuAzar(compartidas.TuAzarAnimalitos, sorteo, "tAz")
                ?? BuscarTuAzar(compartidas.TuAzarFrutas, sorteo, "tAzFr")
                ?? await BuscarLoteriaDeHoyAsync(sorteo, ct);

            if (resultado is null && sorteo.HoraServidor > horaInicioLotto && o.LoteriasLottoResultados.Contains(sorteo.IdLoteria))
            {
                resultado = BuscarLottoResultados(compartidas.LottoResultados, sorteo);
            }

            if (resultado is null && sorteo.IdLoteria == o.IdLoteriaRuletaActiva)
            {
                compartidas.RuletaActiva ??= Cargar(await paginas.ObtenerHtmlAsync(o.UrlRuletaActiva, ct));
                resultado = BuscarRuletaActiva(compartidas.RuletaActiva, sorteo);
            }

            if (resultado is not null)
            {
                logger.LogInformation(
                    "Resultado {Loteria} {Hora}: {Codigo} {Animal} ({Fuente})",
                    resultado.Loteria, sorteo.HoraBusqueda, resultado.Codigo, resultado.Animal, resultado.Fuente);
                encontrados.Add(resultado);
            }
        }

        return encontrados;
    }

    // ---------------------------------------------------------------- tuazar.com (rsTuAz)
    private ResultadoEncontrado? BuscarTuAzar(HtmlDocument? doc, SorteoPendiente sorteo, string fuente)
    {
        var nodos = doc?.DocumentNode.SelectNodes("//div[contains(@class, 'col-xs-6 col-sm-3')]");
        if (nodos is null)
        {
            return null;
        }

        foreach (var nodo in nodos)
        {
            try
            {
                var htmlNombre = nodo.SelectSingleNode("./div[1]")?.InnerHtml;
                var textoResultado = nodo.SelectSingleNode("./div[3]/span")?.InnerText;
                var textoHora = nodo.SelectSingleNode(".//div[contains(@class,'horario')]/span")?.InnerText;
                if (htmlNombre is null || textoResultado is null || textoHora is null)
                {
                    continue;
                }

                var partesNombre = htmlNombre.Replace("<br />", "-").Replace("<br/>", "-").Replace("<br>", "-").Split('-');
                if (partesNombre.Length < 2)
                {
                    continue;
                }

                var nombre = Limpiar(partesNombre[1]);
                var partesResultado = Limpiar(textoResultado.Replace("\n", " ")).Split('-');
                var codigo = partesResultado[0].Trim();
                var animal = partesResultado.Length > 1 ? partesResultado[1].Trim() : string.Empty;

                var hora = textoHora.Replace("AM", string.Empty).Replace("PM", string.Empty).Trim();
                if (hora.Length == 4)
                {
                    hora = "0" + hora;
                }

                if (nombre.ToLowerInvariant() == sorteo.NombreLoteria && hora == sorteo.HoraBusqueda && codigo.Length > 0)
                {
                    return new ResultadoEncontrado(sorteo.IdLoteria, sorteo.IdSorteo, codigo, animal, nombre, fuente);
                }
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Nodo de tuazar no interpretable");
            }
        }

        return null;
    }

    // ---------------------------------------------------------------- loteriadehoy.com (rsIndLotHoy)
    private async Task<ResultadoEncontrado?> BuscarLoteriaDeHoyAsync(SorteoPendiente sorteo, CancellationToken ct)
    {
        var o = options.Value;
        var nombreUrl = sorteo.IdLoteria switch
        {
            22 => sorteo.NombreLoteria.Replace(" ", "-"),
            26 => sorteo.NombreLoteria.Replace(" ", string.Empty).ToLowerInvariant(),
            _ => sorteo.NombreLoteria.Replace(" ", string.Empty)
        };

        var doc = Cargar(await paginas.ObtenerHtmlAsync($"{o.UrlLoteriaDeHoyBase}{nombreUrl}/resultados/", ct));
        var nodos = doc?.DocumentNode.SelectNodes("//div[contains(@class, 'circle-legend')]");
        if (nodos is null)
        {
            return null;
        }

        foreach (var nodo in nodos)
        {
            try
            {
                var h4 = nodo.SelectSingleNode("./h4")?.InnerText;
                var h5 = nodo.SelectSingleNode("./h5")?.InnerText;
                if (h4 is null || h5 is null)
                {
                    continue;
                }

                var an = Limpiar(h4).Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var lot = Limpiar(h5).Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (an.Length == 0 || lot.Length < 2)
                {
                    continue;
                }

                var codigo = an[0];
                var animal = string.Join(' ', an.Skip(1));

                string Parte(int i) => i < lot.Length ? lot[i] : string.Empty;

                (string nombre, string hora) = sorteo.IdLoteria switch
                {
                    10 => (Parte(0) + Parte(1), Parte(2)),
                    11 or 19 or 20 => ($"{Parte(0)} {Parte(1)} {Parte(2)}", Parte(3)),
                    14 => ($"{Parte(0)} {Parte(1)} {(Parte(2).Length >= 2 ? Parte(2)[..2] : Parte(2))}", Parte(3)),
                    21 => (Parte(0), Parte(1)),
                    22 => (Parte(0).Replace("-", " "), Parte(1)),
                    26 => ($"{Parte(0)} {Parte(1)} {Parte(2)} {Parte(3)}", Parte(4)),
                    _ => ($"{Parte(0)} {Parte(1)}", Parte(2))
                };

                if (nombre.Trim().ToLowerInvariant() == sorteo.NombreLoteria && hora == sorteo.HoraBusqueda && codigo.Length > 0)
                {
                    return new ResultadoEncontrado(sorteo.IdLoteria, sorteo.IdSorteo, codigo, animal, nombre.Trim(), "lotHoy");
                }
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Nodo de loteriadehoy no interpretable");
            }
        }

        return null;
    }

    // ---------------------------------------------------------------- lottoresultados.com (LottResult)
    private ResultadoEncontrado? BuscarLottoResultados(HtmlDocument? doc, SorteoPendiente sorteo)
    {
        var bloques = doc?.DocumentNode.SelectNodes("//div[starts-with(@id,'resultados-')]");
        if (bloques is null)
        {
            return null;
        }

        var nombreSistema = sorteo.IdLoteria == 19
            ? sorteo.NombreLoteria.Replace("el", string.Empty).Trim()
            : sorteo.NombreLoteria.Trim();

        foreach (var bloque in bloques)
        {
            var nombreBloque = bloque.GetAttributeValue("id", string.Empty)
                .Replace("resultados-", string.Empty)
                .Replace("animalitos-", string.Empty)
                .Replace("-hoy", string.Empty)
                .Replace("-", " ")
                .Trim();

            string nombrePagina;
            if (sorteo.IdLoteria == 28)
            {
                var partes = nombreBloque.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                nombrePagina = partes.Length >= 2 ? $"{partes[0]} {partes[1]}" : nombreBloque;
            }
            else
            {
                nombrePagina = nombreBloque;
            }

            if (!string.Equals(nombrePagina.Trim(), nombreSistema, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var items = bloque.SelectNodes(".//li[contains(@class, 'step-item')]");
            if (items is null)
            {
                continue;
            }

            foreach (var item in items)
            {
                var horaTexto = item.SelectSingleNode(".//h4")?.InnerText?.Trim();
                var resultadoTexto = item.SelectSingleNode(".//p[contains(@class,'step-text')]")?.InnerText?.Trim();
                if (string.IsNullOrEmpty(horaTexto) || string.IsNullOrEmpty(resultadoTexto))
                {
                    continue;
                }

                var horaNumeros = horaTexto.ToLowerInvariant().Replace("am", string.Empty).Replace("pm", string.Empty).Trim();
                var hora = DateTime.TryParse(horaNumeros, CultureInfo.InvariantCulture, DateTimeStyles.NoCurrentDateDefault, out var h)
                    ? h.ToString("HH:mm", CultureInfo.InvariantCulture)
                    : horaNumeros;

                if (hora != sorteo.HoraBusqueda)
                {
                    continue;
                }

                var partes = Limpiar(resultadoTexto).Split(' ', StringSplitOptions.RemoveEmptyEntries);
                var codigo = partes.Length > 0 ? partes[0] : string.Empty;
                var animal = partes.Length > 1 ? partes[1] : string.Empty;

                if (!int.TryParse(codigo, NumberStyles.None, CultureInfo.InvariantCulture, out var valor))
                {
                    return null; // Sorteo encontrado pero sin resultado aun.
                }

                if (codigo.Length == 1 && codigo != "0")
                {
                    codigo = valor.ToString("D2", CultureInfo.InvariantCulture);
                }

                return new ResultadoEncontrado(sorteo.IdLoteria, sorteo.IdSorteo, codigo, animal, nombrePagina, "LotRs");
            }
        }

        return null;
    }

    // ---------------------------------------------------------------- ruletactiva.com.ve (result_grupo2)
    private ResultadoEncontrado? BuscarRuletaActiva(HtmlDocument? doc, SorteoPendiente sorteo)
    {
        const string contenedor = "//div[@class='col-md-3 custom-sec-img animated fadeInDown']//div//div";
        var imagenes = doc?.DocumentNode.SelectNodes(contenedor + "/img");
        var horas = doc?.DocumentNode.SelectNodes(contenedor + "/h2");
        if (imagenes is null || horas is null)
        {
            return null;
        }

        for (var i = 0; i < horas.Count && i < imagenes.Count; i++)
        {
            var hora = Limpiar(horas[i].InnerText).Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
            if (hora != sorteo.HoraBusqueda)
            {
                continue;
            }

            var src = imagenes[i].GetAttributeValue("src", string.Empty);
            var archivo = src.Split('/', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? string.Empty;
            var codigo = Path.GetFileNameWithoutExtension(archivo).Trim();
            if (codigo.Length == 0)
            {
                return null;
            }

            return new ResultadoEncontrado(sorteo.IdLoteria, sorteo.IdSorteo, codigo, string.Empty, sorteo.NombreLoteria, "RA");
        }

        return null;
    }

    private static HtmlDocument? Cargar(string html)
    {
        if (string.IsNullOrWhiteSpace(html))
        {
            return null;
        }

        var doc = new HtmlDocument();
        doc.LoadHtml(html);
        return doc;
    }

    private static string Limpiar(string texto)
        => HtmlEntity.DeEntitize(texto).Replace('\u00A0', ' ').Trim();
}
