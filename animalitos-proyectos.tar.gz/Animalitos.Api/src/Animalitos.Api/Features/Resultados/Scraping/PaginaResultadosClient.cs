using System.Net.Http.Headers;

namespace Animalitos.Api.Features.Resultados.Scraping;

/// <summary>
/// Descarga de paginas de resultados con un User-Agent aleatorio por solicitud (lista de la
/// tabla spListUserAg o, si no hay, la lista fija de ListUserAg.cs del sistema original).
/// </summary>
public sealed class PaginaResultadosClient(HttpClient http, ISqlExecutor db, ILogger<PaginaResultadosClient> logger)
{
    public const string HttpClientName = "resultados";

    private static readonly string[] UserAgentsPorDefecto =
    [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.10 Safari/605.1.15",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 OPR/117.0.0.0"
    ];

    private string[]? _userAgents;

    /// <summary>Carga la lista de User-Agents (spListUserAg) una vez por proceso.</summary>
    public async Task CargarUserAgentsAsync(CancellationToken ct)
    {
        if (_userAgents is not null)
        {
            return;
        }

        try
        {
            var rows = await db.QueryAsync("spListUserAg", null, ct);
            var lista = rows.Select(r => r.GetString("nombUserAg")).Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
            _userAgents = lista.Length > 0 ? lista : UserAgentsPorDefecto;
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "No se pudo leer spListUserAg; se usa la lista por defecto.");
            _userAgents = UserAgentsPorDefecto;
        }
    }

    /// <summary>Devuelve el HTML de la pagina o cadena vacia si falla (el proceso continua con otras fuentes).</summary>
    public async Task<string> ObtenerHtmlAsync(string url, CancellationToken ct)
    {
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("text/html"));
            request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/xhtml+xml"));

            var agentes = _userAgents ?? UserAgentsPorDefecto;
            request.Headers.TryAddWithoutValidation("User-Agent", agentes[Random.Shared.Next(agentes.Length)]);

            using var response = await http.SendAsync(request, HttpCompletionOption.ResponseContentRead, ct);
            if (!response.IsSuccessStatusCode)
            {
                logger.LogInformation("Pagina de resultados {Url} respondio {Status}", url, (int)response.StatusCode);
                return string.Empty;
            }

            return await response.Content.ReadAsStringAsync(ct);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            logger.LogInformation("No se pudo leer {Url}: {Error}", url, ex.Message);
            return string.Empty;
        }
    }
}
