namespace Animalitos.Api.Features.Impresora;

public sealed record ConfiguracionImpresoraRequest(string NombreImpresora, string AnchoTicket, string TamanoLetra);

public sealed record ConfiguracionImpresoraDto(string NombreImpresora, string AnchoTicket, string TamanoLetra);

/// <summary>Configuracion de impresora por usuario (antes frm_config_impresora).</summary>
public static class ImpresoraEndpoints
{
    public static IEndpointRouteBuilder MapImpresoraEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/impresora").WithTags("Impresora").RequireAuthorization();

        group.MapGet("/", async (ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                var row = await db.QueryFirstAsync("SP_bus_config_impresora", new SpParameters { ["prm_id_usuario"] = user.IdUsuario() }, ct);
                return new ConfiguracionImpresoraDto(
                    row?.GetString("nomb_impresora") ?? string.Empty,
                    row?.GetString("ancho_ticket") ?? string.Empty,
                    row?.GetString("num_letra") ?? string.Empty);
            })
            .WithSummary("Configuracion de impresora del usuario.");

        group.MapPut("/", async (ConfiguracionImpresoraRequest request, ClaimsPrincipal user, ISqlExecutor db, CancellationToken ct) =>
            {
                Guard.NotEmpty(request.NombreImpresora, "nombreImpresora");
                var filas = await db.ExecuteAsync("SP_grd_act_config_imp", new SpParameters
                {
                    ["prm_id_usuario"] = user.IdUsuario(),
                    ["prm_nomb_imp"] = request.NombreImpresora.Trim(),
                    ["prm_ancho_ticket"] = request.AnchoTicket ?? string.Empty,
                    ["prm_num_letra"] = request.TamanoLetra ?? string.Empty
                }, ct);

                // El SP devolvia 1 (insercion) o 2 (actualizacion).
                if (filas < 1)
                {
                    throw BusinessRuleException.Conflict("No fue posible guardar la configuracion de la impresora.");
                }

                return Results.NoContent();
            })
            .WithSummary("Guarda la configuracion de impresora del usuario.");

        group.MapGet("/anchos", async (ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_bus_ancho_ticket", null, ct))
            .WithSummary("Anchos de ticket disponibles.");

        group.MapGet("/tamanos-letra", async (ISqlExecutor db, CancellationToken ct)
                => await db.QueryTablaAsync("SP_bus_num_letra", null, ct))
            .WithSummary("Tamanos de letra disponibles.");

        return app;
    }
}
