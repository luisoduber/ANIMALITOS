namespace Animalitos.Api.Features.Sistema;

public static class SistemaEndpoints
{
    public static IEndpointRouteBuilder MapSistemaEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/sistema").WithTags("Sistema").RequireAuthorization();

        group.MapGet("/hora", async (ClaimsPrincipal user, SistemaRepository repo, CancellationToken ct)
                => await repo.ObtenerHoraAsync(user.IdUsuario(), ct))
            .WithSummary("Hora del servidor y reloj de cierre del usuario (base del reloj interno de la taquilla).");

        group.MapGet("/parametros", async (SistemaRepository repo, CancellationToken ct)
                => await repo.ObtenerParametrosAsync(ct))
            .WithSummary("Parametros generales (dias de caducidad, nota del ticket, sorteos de tripleta).");

        group.MapGet("/estado-taquilla", async (ClaimsPrincipal user, SistemaRepository repo, CancellationToken ct)
                => await repo.ObtenerEstadoTaquillaAsync(user.IdUsuario(), ct))
            .WithSummary("Estado de la taquilla (spVerfStatTaq). Si esta inactiva el cliente debe cerrar la sesion.");

        return app;
    }
}
