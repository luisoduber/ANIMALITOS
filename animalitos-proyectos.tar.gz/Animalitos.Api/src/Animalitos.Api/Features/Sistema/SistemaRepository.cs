namespace Animalitos.Api.Features.Sistema;

public sealed record ParametrosGeneralesDto(
    int DiasCaducidadTicket,
    string NotaTicket,
    int IdTipoProcesoDatos,
    int SorteosTripleta);

/// <param name="FechaHoraServidor">Fecha y hora actual del servidor de BD (sp_busFechaHoraServ).</param>
/// <param name="HoraCierre">
/// Reloj de cierre del usuario (sp_bus_hora_servidor). Es la hora contra la que se comparan
/// los sorteos para retirarlos de la venta; puede incluir un adelanto configurado por usuario.
/// </param>
public sealed record HoraServidorDto(DateTime FechaHoraServidor, DateTime HoraCierre);

public sealed record EstadoTaquillaDto(int IdEstado, bool Activa);

/// <summary>Parametros y reloj del sistema (antes: busPrmGral, verfHoraServ, busFechHoraServ, VerfStatTaq).</summary>
public sealed class SistemaRepository(ISqlExecutor db, TimeProvider time)
{
    public async Task<ParametrosGeneralesDto> ObtenerParametrosAsync(CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("SPbusParamGral", null, ct);
        if (row is null)
        {
            return new ParametrosGeneralesDto(0, string.Empty, 0, 0);
        }

        return new ParametrosGeneralesDto(
            row.GetInt32("cantDiaCadTck"),
            row.GetString("ntMsjTck"),
            row.GetInt32("idTipProcDat"),
            row.GetInt32("cantSortTrip"));
    }

    public async Task<DateTime> ObtenerFechaHoraServidorAsync(CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("sp_busFechaHoraServ", null, ct);
        if (row is null)
        {
            return time.GetLocalNow().DateTime;
        }

        var fecha = row.GetDateTime("fechaAct");
        var hora = row.GetTimeOfDay("horaAct");
        if (fecha is null)
        {
            return time.GetLocalNow().DateTime;
        }

        return hora is null ? fecha.Value : fecha.Value.Date + hora.Value;
    }

    public async Task<DateTime> ObtenerHoraCierreAsync(int idUsuario, CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("sp_bus_hora_servidor", new SpParameters { ["prm_id_usuario"] = idUsuario }, ct);
        return row?.GetDateTime("fechaHoraServ") ?? await ObtenerFechaHoraServidorAsync(ct);
    }

    public async Task<HoraServidorDto> ObtenerHoraAsync(int idUsuario, CancellationToken ct)
    {
        var servidor = await ObtenerFechaHoraServidorAsync(ct);
        var cierre = await ObtenerHoraCierreAsync(idUsuario, ct);
        return new HoraServidorDto(servidor, cierre);
    }

    /// <summary>
    /// spVerfStatTaq: 1 = activa, 2 = inactiva. Igual que el sistema original, solo el estado 2
    /// se considera inactivo (cierra la sesion de la taquilla).
    /// </summary>
    public async Task<EstadoTaquillaDto> ObtenerEstadoTaquillaAsync(int idUsuario, CancellationToken ct)
    {
        var row = await db.QueryFirstAsync("spVerfStatTaq", new SpParameters { ["prmIdUsu"] = idUsuario }, ct);
        var estado = row?.GetInt32("idStat") ?? 0;
        return new EstadoTaquillaDto(estado, estado != EstadoInactivo);
    }

    public const int EstadoInactivo = 2;
}
