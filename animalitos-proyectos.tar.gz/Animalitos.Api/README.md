# Animalitos.Api

API REST en **.NET 10** que reemplaza a la clase `clsMet.cs` y a los accesos directos a MySQL que tenían los formularios del sistema WinForms `ventas_loteria`. Usa la **misma base de datos MySQL y los mismos procedimientos almacenados**: no requiere cambios en la BD.

## Arquitectura

```
src/Animalitos.Api
├── Program.cs                  Configuración: JWT, políticas, rate limit, ProblemDetails, OpenAPI, Serilog, health
├── Common
│   ├── Data                    ISqlExecutor (MySqlConnector, 100 % async, con transacciones), DbRow, DbConvert, TablaDto
│   ├── Errors                  BusinessRuleException + GlobalExceptionHandler (RFC 9457 ProblemDetails)
│   ├── Security                Perfiles, políticas y claims del JWT
│   └── Text                    Formato de códigos, montos y horas
└── Features                    Una carpeta por módulo (vertical slices), endpoints Minimal API
    ├── Auth                    Login (sin MAC), perfil, cambio de clave, JWT, bloqueo por intentos
    ├── Sistema                 Hora del servidor / reloj de cierre, parámetros, estado de taquilla
    ├── Catalogo                Loterías, sorteos, productos y catálogos
    ├── Ventas                  Venta de animalitos y tripletas (transaccional), totales, reimprimir, repetir
    ├── Tickets                 Pagar, anular, verificar, movimientos; anulación y consulta administrativa
    ├── Reportes                Cuadre de taquilla, ventas por lotería, cuadres de grupo
    ├── Resultados              Consulta, proceso automático (lectura de páginas) y manual
    ├── Impresora               Configuración de impresora por usuario
    └── Admin                   Grupos, usuarios, equipos (MAC, solo WinForms), límites y bloqueos
```

Buenas prácticas aplicadas:

- **Sin SQL concatenado**: todo va por procedimientos almacenados con parámetros.
- **Todo asíncrono** y con `CancellationToken`. Conexiones del pool por cada operación.
- **Venta en una sola transacción** (`SPgrdTck` + `SP_det_ticket` por jugada + `spActMontTck`) que se confirma **antes** de imprimir (el WinForms dejaba la transacción abierta mientras imprimía).
- **El servidor valida el cierre de sorteos**: la hora de cada sorteo sale de la BD y se compara con la hora del servidor (`fechaHoraVerf`). Aunque alguien manipule la pantalla, no se puede vender un sorteo cerrado.
- **La clave nunca sale de la API** (antes `SPverfLog` enviaba la clave al equipo y se comparaba allí). Comparación en tiempo constante y bloqueo temporal por intentos fallidos.
- JWT firmado (HMAC-SHA256), políticas por perfil (`Taquilla`, `AdminGrupo`, `SuperAdmin`), y el administrador de grupo solo opera sobre su grupo.
- Errores como **ProblemDetails**; detalles internos solo en Development. Logs estructurados con Serilog (consola + archivo diario).
- Opciones validadas al iniciar (`ValidateOnStart`), health check `/health` con ping a MySQL.

## Requisitos

- .NET SDK 10.0 (Visual Studio 2022 17.14+ o Visual Studio 2026).
- Acceso al servidor MySQL actual.

## Configuración (sin secretos en el código)

Desde la carpeta `src/Animalitos.Api`:

```bash
dotnet user-secrets set "ConnectionStrings:Loterias" "Server=SERVIDOR;Port=PUERTO;Database=loterias;Uid=USUARIO;Pwd=CLAVE;SslMode=Preferred;Pooling=true"
dotnet user-secrets set "Jwt:ClaveFirma" "UNA-CLAVE-ALEATORIA-DE-AL-MENOS-32-CARACTERES"
```

En producción se usan variables de entorno: `ConnectionStrings__Loterias` y `Jwt__ClaveFirma`.

> **Importante:** el archivo `ventas_loteria/frm_login.cs` del sistema WinForms tiene cadenas de conexión con usuario y clave de MySQL escritas en el código. Si ese repositorio se ha compartido o publicado, **cambie esas claves de MySQL** y cree para la API un usuario de BD con permiso solo de `EXECUTE` sobre los procedimientos.

### Sección `Seguridad`

| Clave | Valor por defecto | Descripción |
|---|---|---|
| `AlmacenamientoClaves` | `TextoPlano` | Cómo se guardan las claves nuevas o cambiadas. Mantener `TextoPlano` mientras el WinForms siga en uso. Luego cambiar a `Hash`. |
| `MigrarClavesAlIniciarSesion` | `false` | Si es `true`, al iniciar sesión convierte la clave en texto plano a hash PBKDF2. **Antes** amplíe la columna `usuario.clave` a `VARCHAR(255)` y deje de usar el WinForms. |
| `IntentosFallidosPermitidos` / `MinutosBloqueo` | 5 / 5 | Bloqueo temporal del usuario por intentos fallidos. |

El login acepta **ambos formatos** (texto plano y hash) siempre, así la migración de claves se puede hacer sin cortar el servicio.

## Ejecutar

```bash
cd src/Animalitos.Api
dotnet run --launch-profile https
```

- Documentación interactiva (solo Development): `https://localhost:7101/scalar/v1`
- Documento OpenAPI: `https://localhost:7101/openapi/v1.json`
- Salud: `https://localhost:7101/health`
- Ejemplos de llamadas: `Animalitos.Api.http` (Visual Studio / VS Code REST Client).

## Endpoints

| Módulo | Método y ruta | Procedimientos |
|---|---|---|
| Auth | `POST /api/auth/login` | SPverfLog (sin verificación de MAC) |
| | `GET /api/auth/me` | SPverfLog |
| | `POST /api/auth/cambiar-clave` | SP_verf_cambio_clave, SP_act_cambio_clave |
| Sistema | `GET /api/sistema/hora` | sp_busFechaHoraServ, sp_bus_hora_servidor |
| | `GET /api/sistema/parametros` | SPbusParamGral |
| | `GET /api/sistema/estado-taquilla` | spVerfStatTaq |
| Catálogo | `GET /api/catalogo/loterias` | spListLotTod |
| | `GET /api/catalogo/loterias/grupo/{idGrupo}` | spListLotTodGrup |
| | `GET /api/catalogo/loterias/tripletas` | SPbusLotTrip |
| | `GET /api/catalogo/loterias/resultados` | SP_bus_lot_result |
| | `GET /api/catalogo/sorteos/venta?idLoteria=` | SPBusSort / spListSortVentTod |
| | `GET /api/catalogo/sorteos/loteria/{id}` (`/detalle`) | spListSortTod (SP_bus_sorteos) |
| | `GET /api/catalogo/productos` (`/loteria/{id}`) | spBusNombProd (SP_bus_producto) |
| | `GET /api/catalogo/perfiles` | spBusPerf |
| | `GET /api/catalogo/{nombre}` | estados, estados-ticket, tipos-ticket, divisas, tipos-cuadre, preguntas-seguridad, letras-rif, codigos-telefono, anchos-ticket, tamanos-letra, tipos-proceso, estados-equipo(-filtro) |
| Ventas | `POST /api/ventas/animalitos` | SPgrdTck, SP_det_ticket, spActMontTck (una transacción) |
| | `POST /api/ventas/tripletas` | SPgrdTckTrip, SPdetTckTrip, spActMontTck (una transacción) |
| | `GET /api/ventas/totales-dia` | SPbusCuadCajDia |
| | `GET /api/ventas/reimprimir` | SPinfReimpTck, SPreimpTck |
| | `POST /api/ventas/repetir` | SP_verf_exist_repet_ticket, SP_bus_grd_det_ticket, SP_bus_jugadas |
| Tickets | `GET /api/tickets/{nro}/estado?serial=` | SPVerfStatTck |
| | `GET /api/tickets/{nro}?serial=` | SP_verf_exists_mostrar_ticket, SPInfTck, SPTckDet / SPTckDetTrip |
| | `POST /api/tickets/{nro}/pagar` | SPVerfStatTck, SP_act_paga_ticket |
| | `POST /api/tickets/{nro}/anular` | SPVerfStatTck, SPDetTckAn |
| | `GET /api/tickets/movimientos` | SP_bus_mov_status_ticket(_Xfiltro), SP_bus_totales_mov_ventas |
| | `GET /api/tickets/admin/{nro}` | SPbusInfTckAn, SP_bus_mostrar_ticket_det_anular |
| | `POST /api/tickets/admin/{nro}/anular` | SPAnTckAdm |
| | `GET /api/tickets/admin/jugadas-taquilla` | SPBusJugTaq |
| Reportes | `GET /api/reportes/totales-taquilla` | SP_bus_totales_taq(_Xfiltro), SP_bus_totales_ventas_taq |
| | `GET /api/reportes/ventas?modo=taquilla\|loteria` | spVerfVentTaq / spVerfVentLot |
| | `GET /api/reportes/ventas/loterias` | spListLotTod |
| | `GET /api/reportes/admin/cuadre-taquillas` | spBusTotGrupoTaqXDivisa |
| | `GET /api/reportes/admin/cuadre-general` | SPBusTotGrup / SPBusTotGrupTod |
| | `GET /api/reportes/admin/totales-grupo` | SP_bus_totales_grupo_taq(_Xfiltro) |
| | `GET /api/reportes/admin/control-ventas/...` | spContVentTaq, splistLotContVent, spListSortContVentTod |
| Resultados | `GET /api/resultados?idLoteria=&fecha=` | SP_bus_result_lot(_Xfiltro) |
| | `POST /api/admin/resultados/automatico` | SPBusSortProcRsAut, spListUserAg, SPGrdActRsLot, SPBusJugProcRs, SPactRsLot, SPactRsLotTrip |
| | `POST /api/admin/resultados/manual` | spListSortTod, SPGrdActRsLot, SPBusJugProcRsMan, SPactRsLot(Trip) |
| | `GET /api/admin/resultados/sorteos`, `jugadas-pendientes`, `jugadas-sorteo`, `intervalo` | SP_bus_sorteos_proc_result, SPBusJugPendProc, SPBusTipJugPendProc, SPBusJugProcRsMan, spTmpProcRs |
| Impresora | `GET/PUT /api/impresora`, `/anchos`, `/tamanos-letra` | SP_bus_config_impresora, SP_grd_act_config_imp, SP_bus_ancho_ticket, SP_bus_num_letra |
| Admin | `/api/admin/grupos...` | spBusGrup, SPBusGrupTod, spBusGrupConf, SP_grupos_Xfiltro_nomb, SP_grd_act_grupos, SP_bus_usuarios_grupos, SP_bus_cant_usuario, SPbusGrupTaq, spBusTaqContVent |
| | `POST /api/admin/usuarios` | SP_grd_act_usuarios |
| | `/api/admin/equipos...` | SP_bus_mac_adrress, SP_bus_mac_Xfiltro(_status), SP_bus_mac_address_nuevas, SP_grd_act_mac_nueva, SP_act_status_mac |
| | `GET/PUT /api/admin/limites` | spListLimTaq, spActLimTaq |
| | `/api/admin/bloqueos/productos\|sorteos\|loterias` | spListProdBloq(Filt), spActStatProd(Tod), spListSortBloq(Filt), spActStatSort, spListLotUsu, spActStatLot |

### Métodos de `clsMet` que no se migraron

Estos métodos no los usaba ningún formulario (código sin uso): `grd_jugada`, `dlt_jugada`, `bus_total_jug`, `verf_jug_imp_ticket`, `limpia_jug_pend`, `verf_jugadas_cerrada`, `grd_ticket_usuario`, `verf_exits_ticket`, `bus_repet_ultimo_ticket`, `SP_verf_exist_email`.

`verfMacTaq` (`SP_verifica_mac_equipo`) se eliminó a propósito: la versión web no valida la MAC.

## Tablas genéricas

Los procedimientos que el WinForms mostraba directamente en un `DataGridView` (sin columnas fijas en el código) se devuelven como `TablaDto { columnas, filas }`, respetando el nombre y el orden de columnas del procedimiento. Los flujos críticos (venta, tickets, totales, resultados) usan DTOs tipados.

## Publicación (IIS / Windows Server)

```bash
dotnet publish src/Animalitos.Api -c Release -o publish/api
```

Instale el *ASP.NET Core 10 Hosting Bundle*, cree el sitio en IIS apuntando a `publish/api` y defina las variables de entorno `ConnectionStrings__Loterias` y `Jwt__ClaveFirma` en el pool o en `web.config`. Si el Web y la API están en servidores distintos, agregue la IP del Web en `KnownProxies` (ForwardedHeaders) para que el límite de intentos use la IP real del cliente.
